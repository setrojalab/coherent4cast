"""Run the seven standalone native fixtures; no R or proprietary compiler needed."""
from pathlib import Path
import json, os, shutil, subprocess
root=Path(__file__).resolve().parent
compiler=os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
if not compiler:raise SystemExit('Put a C++17 GCC/Clang compiler on PATH, or set CXX.')
out=root/'output/native';out.mkdir(parents=True,exist_ok=True)
records=[]
for src in sorted((root/'native_tests').glob('*.cpp')):
    exe=out/(src.stem+('.exe' if os.name=='nt' else ''))
    cmd=[compiler,'-std=c++17','-Wall','-Wextra','-pedantic','-Wconversion','-Werror',
         '-I',str(root/'package/inst/include'),str(src),'-o',str(exe)]
    subprocess.run(cmd,check=True,cwd=root)
    args=[str(exe)]
    if src.stem=='test_sparse':args.append(str(out/'random_bounds.csv'))
    run=subprocess.run(args,check=True,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (out/(src.stem+'.txt')).write_text(run.stdout,encoding='utf-8')
    print(src.name,run.stdout)
    records.append({'fixture':src.name,'exit_code':run.returncode})
(out/'summary.json').write_text(json.dumps(records,indent=2))
