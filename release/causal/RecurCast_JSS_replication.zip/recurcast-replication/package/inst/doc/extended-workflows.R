## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse=TRUE,comment="#>")
library(recurcast)

## ----fit----------------------------------------------------------------------
d <- rc_simulate(100,horizon=2,seed=72,time_unit="years")
fit <- recurcast(~x,d,time_unit="years",
                 control=recurcast_control(history_cap=0,phi_fixed=.4))
fit$convergence$code
summary(fit)$frailty_diagnostics$null_variance_test

## ----alternative--------------------------------------------------------------
lnfit <- suppressWarnings(recurcast(~x,d,time_unit="years",frailty="lognormal",
  control=recurcast_control(history_cap=0,phi_fixed=.4)))
lnfit$audit$quadrature_refinement

## ----coarsening---------------------------------------------------------------
history <- data.frame(id=901,event_time_lower=.2,event_time_upper=.4,
                      event_type="1",terminal=0,followup=1,x=0)
fibre <- rc_coarsen_fibre(history,event_types=c("1","2"),
                         time_unit="years",nodes=4)
fibre$tie_audit
pred <- predict(fit,newdata=history,landmark=1,horizon=.5,type="all",
                newdata_observation="coarsened")
pred[,c("unit","target","estimate","series_error_bound")]

## ----schedule-----------------------------------------------------------------
schedule <- data.frame(id=901,time=1.25,x=1)
predict(fit,history,landmark=1,horizon=.5,type="risk",
        newdata_observation="coarsened",covariate_evolution="locf",
        newdata_future=schedule)

## ----targeting----------------------------------------------------------------
d$censored <- as.integer(d$event_type==0 & d$terminal==0 & d$stop<2)
targeted <- suppressWarnings(recurcast(~x,d,time_unit="years",targeting="continuous",
  control=recurcast_control(history_cap=1),
  targeting_spec=list(horizon=2,censor="censored",nfolds=3,grid=32)))
summary(targeted)$estimates
predict(targeted,draws=300)

## ----sparse-------------------------------------------------------------------
Q <- rc_generator_csr(3,from=c(1,1,2),to=c(2,3,3),rate=c(.3,.1,.2))
rc_propagate_sparse(c(1,0,0),Q,1,reward=c(1,1,0))
p <- rep(1/100,100)
region <- rc_bounds(p,numerator=seq(0,1,length.out=100),
                    kappa=2,recording_fraction=.7)
c(lower=region$lower,upper=region$upper)
region$method

