## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse=TRUE,comment="#>",fig.width=6,fig.height=4)
library("recurcast")

## ----data---------------------------------------------------------------------
data("sim_perinatal")
head(sim_perinatal)
trajectory <- as_trajectory(sim_perinatal, event_types=c("1","2"),
                            time_unit="months")
history <- build_history(trajectory, cap=2)
head(history$counts)

## ----fit----------------------------------------------------------------------
fit <- recurcast(~x, sim_perinatal, event_types=c("1","2"),
                time_unit="months")
print(fit)
glance(fit)
head(tidy(fit))

## ----predict------------------------------------------------------------------
one <- sim_perinatal[sim_perinatal$id == 1, ]
forecast <- predict(fit, newdata=one, landmark=0,
                    horizon=c(.25,.5,1), type="all")
forecast[, c("unit","horizon","target","estimate")]
plot(forecast, target="risk")

## ----quadrature---------------------------------------------------------------
q15 <- predict(fit, one, landmark=0, horizon=1, quadrature=15)
q30 <- predict(fit, one, landmark=0, horizon=1, quadrature=30)
abs(q15$estimate-q30$estimate)

## ----audit--------------------------------------------------------------------
fit$audit$assumptions
fit$audit$data_hash_algorithm
attr(forecast,"assumptions")

