#' ---
#' title: "recurcast 0.10.1: manuscript replication"
#' author: "Sunday A. Adetunji and Oluwatimileyin A. Adetunji"
#' date: "23 November 2026"
#' output: html_document
#' ---
#'
#' Run from this directory with `Rscript --vanilla code.R`.
#' Install the supplied source package first; see README.txt.
#' The default reconstructs the article using recorded experiments, reruns the
#' quickstart and sensitivity calculations, and checks the raw simulation
#' summaries. Use `Rscript --vanilla code.R --fresh-cases` to refit the five
#' applications. Runtime and memory measurements are host-specific observations.
options(width = 78, useFancyQuotes = FALSE)
requested_library <- Sys.getenv("RECURCAST_LIBRARY", "")
if (nzchar(requested_library)) .libPaths(c(requested_library, .libPaths()))
stopifnot(file.exists("paper/replication_script.R"))
for (p in c("recurcast", "jsonlite"))
  if (!requireNamespace(p, quietly = TRUE)) stop("Install required package: ", p)
stopifnot(as.character(utils::packageVersion("recurcast")) == "0.10.1")
dir.create("output", showWarnings = FALSE)
set.seed(20261123)

#' ## Check the recorded Monte Carlo results
#' All generated cohorts remain in the denominators, including failed
#' regularity checks. These checks recompute coverage from the recorded rows;
#' they do not pretend that the Monte Carlo experiment was rerun.
raw <- read.csv("reviews/P2_continuous_validation_replicates.csv")
reported <- read.csv("reviews/P2_continuous_validation_summary.csv")
stopifnot(nrow(raw) == 20000L, all(table(raw$cell) == 5000L))
calculated <- do.call(rbind, lapply(seq_len(nrow(reported)), function(i) {
  row <- reported[i, ]; z <- raw[raw$cell == row$cell, ]
  field <- if (row$method == "Wald") "joint_wald" else "joint_transform"
  coverage <- mean(z[[field]])
  mcse <- sqrt(coverage * (1 - coverage) / nrow(z))
  stopifnot(abs(coverage - row$coverage) < 1e-12,
            abs(mcse - row$MCSE) < 1e-12)
  data.frame(cell = row$cell, method = row$method, B = nrow(z),
             coverage = coverage, MCSE = mcse)
}))
print(calculated, row.names = FALSE)
write.csv(calculated, "output/recomputed_simulation_summary.csv", row.names = FALSE)

#' ## Optional fresh case fits
#' Uses public datasets from survival/frailtypack and the three bundled
#' synthetic datasets. It creates local fitted-object caches under output/.
#' Nothing is loaded from a private development repository.
fresh <- "--fresh-cases" %in% commandArgs(trailingOnly = TRUE)
case_path <- "replication/results/cases"
if (fresh) {
  case_path <- "output/fresh_cases"
  Sys.setenv(RECURCAST_CASE_OUTPUT = case_path,
             RECURCAST_CASE_CACHE = "output/fresh_case_fits",
             RECURCAST_REUSE_CASE_FITS = "0")
  source("replication/run_case_studies.R", local = new.env(parent = globalenv()))
}

#' ## Reconstruct the article
#' The materializer reruns the package quickstart and finite-support sensitivity
#' curve, then builds every generated table and all five vector figures. Saved
#' verification results retain their original software-version provenance.
Sys.setenv(RECURCAST_PAPER_OUTPUT = "output/paper",
           RECURCAST_CASE_OUTPUT = case_path)
source("paper/replication_script.R", local = new.env(parent = globalenv()))
tables <- list.files("output/paper/generated", pattern = "[.]tex$", full.names = TRUE)
comparison <- do.call(rbind, lapply(tables, function(p) {
  ref <- file.path("expected/paper/generated", basename(p))
  same <- file.exists(ref) && identical(readLines(p, warn = FALSE),
                                       readLines(ref, warn = FALSE))
  data.frame(file = basename(p), matches_recorded_table = same)
}))
print(comparison, row.names = FALSE)
write.csv(comparison, "output/table_reproduction.csv", row.names = FALSE)
if (!fresh && !all(comparison$matches_recorded_table))
  stop("Generated tables differ from the recorded article; inspect output/table_reproduction.csv")
stopifnot(all(file.exists(file.path("output/paper/figures", paste0(
  c("architecture", "sensitivity", "runtime", "cases", "continuous_coverage"), ".pdf")))))

#' ## Key output tables
for (name in c("quickstart.csv", "sensitivity.csv", "revision_verification.csv")) {
  cat("\n", name, "\n")
  print(read.csv(file.path("output/paper/generated", name)), row.names = FALSE)
}

#' ## Reconstructed figures
if (requireNamespace("knitr", quietly = TRUE) && knitr::is_html_output()) {
  knitr::include_graphics(file.path("output/paper/figures", paste0(
    c("architecture", "sensitivity", "runtime", "cases", "continuous_coverage"), ".png")))
}

#' ## Baseline-treatment causal extension (Supplement S12)
#' Freshly simulate and fit the causal example, retain joint arm EIF covariance,
#' compare time-grid refinements, and verify the analytic product remainder.
#' The population g-formula oracle is retained alongside its independent SciPy
#' matrix-exponential source. This does not rerun the historical primary grids.
causal_output <- system2(file.path(R.home("bin"), "Rscript"),
  c("--vanilla", "causal/run_causal.R"), stdout = TRUE, stderr = TRUE)
cat(paste(causal_output, collapse = "\n"), "\n")
if (!is.null(attr(causal_output, "status")) && attr(causal_output, "status") != 0L)
  stop("Causal extension replication failed.")
print(read.csv("causal/results/causal_contrasts.csv"), row.names = FALSE)

#' ## Run information
#' Timestamps, session information, plotting-device metadata and timings can
#' change between machines. Numerical assertions are evaluated separately.
writeLines(capture.output(sessionInfo()), "output/sessionInfo.txt")
sessionInfo()
cat("\nManuscript reconstruction completed.\n")
