"""Patient-separated application analyses; no invented disease-type labels."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import numpy as np,pandas as pd,json
from numba import njit
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from scipy.special import expit,logit
from scipy.optimize import minimize
from joint_model import JointGamma
ROOT=Path(__file__).resolve().parents[1]
BINS=np.array([0.,1.,3.,10.])

def load_data(name):
    patients=[];segments=[];notes=[]
    if name=='readmission':
        d=pd.read_csv(ROOT/'data/raw/readmission_colorectal.csv')
        for ident,g in d.groupby('id',sort=True):
            g=g.sort_values('t.start');base=g.iloc[0];last=g.iloc[-1]
            x=np.array([base.sex=='Female',base.chemo=='Treated',base.dukes=='C',base.dukes=='D',str(base.charlson)=='1-2',str(base.charlson)=='3'],float)
            pid=len(patients);nprev=0
            for _,row in g.iterrows():
                segments.append((pid,row['t.start']/365.25,row['t.stop']/365.25,int(row.event),int(row.death),nprev,x))
                nprev+=int(row.event)
            patients.append(dict(id=int(ident),time=last['t.stop']/365.25,death=int(last.death),x=x,events=g.loc[g.event==1,'t.stop'].to_numpy()/365.25))
        names=['female','chemotherapy','Dukes_C','Dukes_D','baseline_Charlson_1_2','baseline_Charlson_3']
        notes.append('Charlson is measured only at the first available interval for this forecast analysis; later values are not assumed available before their recorded interval.')
    else:
        d=pd.read_csv(ROOT/'data/raw/colon_trial.csv');excluded=[]
        for ident,g in d.groupby('id',sort=True):
            rec=g[g.etype==1].iloc[0];dead=g[g.etype==2].iloc[0]
            if rec.status==1 and dead.status==1 and rec.time==dead.time:
                excluded.append(int(ident));continue
            x=np.array([rec.rx=='Lev',rec.rx=='Lev+5FU',rec.sex,(rec.age-60)/10,rec.node4],float)
            end=dead.time;death=int(dead.status)
            if rec.status==0 and rec.time<end:end=rec.time;death=0
            pid=len(patients);rt=rec.time if rec.status==1 and rec.time<=end else None
            if rt is not None:
                segments.append((pid,0.,rt/365.25,1,0,0,x))
                if rt<end:segments.append((pid,rt/365.25,end/365.25,0,death,1,x))
            else:segments.append((pid,0.,end/365.25,0,death,0,x))
            patients.append(dict(id=int(ident),time=end/365.25,death=death,x=x,events=np.array([rt/365.25]) if rt else np.array([])))
        names=['Levamisole','Levamisole_5FU','male','age_per_10_years','node4']
        notes.append(f'Five recurrence/death date ties are retained in raw data and excluded from the exact-order primary model: {excluded}. No ordering is invented. General coarsened likelihood remains a required extension.')
        notes.append('Recurrence is a non-repeatable intermediate event. Follow-up stops if recurrence surveillance ends before mortality follow-up. node4 is retained as supplied; it is not silently reconciled with nodes.')
    return patients,segments,names,notes

def design(segments,name,selected=None,history=True):
    if selected is None:selected=sorted(set(s[0] for s in segments))
    mapping={int(a):i for i,a in enumerate(selected)};ids=[];dt=[];features=[];events=[]
    nx=len(segments[0][6]);p0=3+nx+int(history)
    for pid,start,stop,re,death,count,x in segments:
        if pid not in mapping:continue
        cuts=sorted(set([start,stop]+[v for v in BINS[1:-1] if start<v<stop]))
        for a,b in zip(cuts[:-1],cuts[1:]):
            for k in [0,1]:
                if k==0 and name=='colon' and count>0:continue
                z=np.zeros(2*p0);off=k*p0;z[off+min(2,np.searchsorted(BINS,a,side='right')-1)]=1
                z[off+3:off+3+nx]=x
                if history:z[off+p0-1]=min(count,3)
                ids.append(mapping[pid]);dt.append(b-a);features.append(z);events.append((re if k==0 else death) if b==stop else 0)
    X=np.array(features)
    # Recurrence is no longer eligible after cancer recurrence, so its own history
    # coefficient is structurally absent, not an estimable zero-variance column.
    active=np.any(X!=0,axis=0)
    return (np.array(ids),np.array(dt),X[:,active],np.array(events)),active,p0

def full_theta(fit,active,p0):
    full=np.zeros(len(active));full[active]=fit.theta[:np.sum(active)]
    return full.reshape(2,p0)

def integrated_A(patients,segments,pid,beta,s):
    A=0.;d=0
    for i,start,stop,re,death,count,x in segments:
        if i!=pid or start>=s:continue
        end=min(stop,s);cuts=sorted(set([start,end]+[v for v in BINS[1:-1] if start<v<end]))
        for a,b in zip(cuts[:-1],cuts[1:]):
            f=np.r_[np.eye(3)[min(2,np.searchsorted(BINS,a,side='right')-1)],x,min(count,3)]
            for k in range(2):
                if k==0 and len(x)==5 and count>0:continue
                A+=(b-a)*np.exp(beta[k]@f)
        if stop<=s:d+=re+death
    return A,d

@njit(cache=True)
def rollout(beta,shape,rate,x,count,s,h,nonrepeat,draws,seed):
    np.random.seed(seed);deaths=0.;burden=0.;alive_time=0.
    nx=len(x)
    for j in range(draws):
        z=np.random.gamma(shape,1/rate);t=s;c=count;dead=False;nr=0
        while t<s+h:
            b=0 if t<1 else (1 if t<3 else 2)
            l=np.zeros(2)
            for k in range(2):
                eta=beta[k,b]+beta[k,-1]*min(c,3)
                for q in range(nx):eta+=beta[k,3+q]*x[q]
                l[k]=z*np.exp(eta)
            if nonrepeat and c>0:l[0]=0
            waiting=np.random.exponential(1/l.sum())
            boundary=min(s+h,1 if t<1 else (3 if t<3 else s+h));end=min(t+waiting,boundary)
            alive_time+=end-t;t=end
            if t<boundary:
                if np.random.random()<l[0]/l.sum():c+=1;nr+=1
                else:dead=True;break
        deaths+=dead;burden+=nr
    return deaths/draws,burden/draws,alive_time/draws

def km_censor(patients,ids,s):
    sub=[patients[i] for i in ids if patients[i]['time']>s]
    times=sorted(set(p['time'] for p in sub));G=1.;out=[]
    for t in times:
        at=sum(p['time']>=t for p in sub);c=sum(p['time']==t and p['death']==0 for p in sub)
        out.append((t,G,G*(1-c/at)));G*=1-c/at
    def value(t,left=False):
        vals=[a[1] if left and a[0]==t else a[2] for a in out if a[0]<t or (a[0]==t and not left)]
        return vals[-1] if vals else 1.
    return value

def metrics(y,p,w):
    n=len(y);bs=np.sum(w*(y-p)**2)/n
    known=w>0
    auc=roc_auc_score(y[known],p[known],sample_weight=w[known]) if len(np.unique(y[known]))==2 else np.nan
    z=logit(np.clip(p,1e-6,1-1e-6))
    def loss(v):
        q=v[0]+v[1]*z
        return np.sum(w*(np.logaddexp(0,q)-y*q))/n
    cal=minimize(loss,[0,1],method='BFGS')
    if np.ptp(z)<1e-8:cal.x[:]=np.nan
    citl=minimize(lambda a:np.sum(w*(np.logaddexp(0,a[0]+z)-y*(a[0]+z)))/n,[0.],method='BFGS')
    # Calibration error based on five fixed risk bins; no claim this is a smooth ICI.
    err=0.;total=0.
    for lower,upper in zip(np.linspace(0,1,6)[:-1],np.linspace(0,1,6)[1:]):
        ix=(p>=lower)&(p<upper)&known
        if ix.sum():mass=w[ix].sum();err+=mass*abs(np.average(y[ix],weights=w[ix])-np.average(p[ix],weights=w[ix]));total+=mass
    return dict(n=n,events=int(y[known].sum()),Brier=bs,AUC=auc,CITL=float(citl.x[0]),calibration_intercept=float(cal.x[0]),calibration_slope=float(cal.x[1]),binned_calibration_error=err/total if total else np.nan,effective_weight_n=float(w.sum()**2/(w@w)),max_weight=float(w.max()))

def main():
    totals=[];estimates=[];perform=[];forecasts=[];statuses={}
    for name in ['readmission','colon']:
        pts,segs,names,notes=load_data(name);n=len(pts);rng=np.random.default_rng(20261122);order=rng.permutation(n);train=np.sort(order[:int(n*2/3)]);test=np.sort(order[int(n*2/3):])
        exported=[]
        for pid,start,stop,re,dead,count,x in segs:
            exported.append(dict(id=pts[pid]['id'],start=start,stop=stop,event=re,death=dead,prior_count=min(count,3),**dict(zip(names,x))))
        pd.DataFrame(exported).to_csv(ROOT/f'data/derived/{name}_analysis_intervals.csv',index=False)
        data,active,p0=design(segs,name,train);fit=JointGamma(*data).fit();beta=full_theta(fit,active,p0)
        statuses[name]=dict(n=n,train=len(train),test=len(test),fit=fit.status,phi=float(fit.phi),notes=notes)
        labels=[f'{kind}_{v}' for kind in ['recurrence','death'] for v in ['baseline_0_1','baseline_1_3','baseline_3_10']+names+['prior_count_capped_3']]
        selected_labels=np.array(labels)[active].tolist()+['log_frailty_variance']
        for j,label in enumerate(selected_labels):
            se=np.sqrt(max(0,fit.sandwich[j,j]));estimates.append(dict(dataset=name,term=label,estimate=fit.theta[j],SE=se,lower=fit.theta[j]-1.96*se,upper=fit.theta[j]+1.96*se))
        splits=pd.DataFrame([dict(dataset=name,id=p['id'],partition='training' if i in train else 'test',time=p['time'],death=p['death']) for i,p in enumerate(pts)])
        splits.to_csv(ROOT/f'data/derived/{name}_patient_split.csv',index=False)
        for s in [0.,1.]:
            h=1.;G=km_censor(pts,train,s);eligible=[i for i in test if pts[i]['time']>s];y=[];w=[];p=[];X=[]
            for i in eligible:
                pat=pts[i];A,d=integrated_A(pts,segs,i,beta,s);a=1/fit.phi;count=int(np.sum(pat['events']<=s));ph,burden,rmean=rollout(beta,a+d,a+A,pat['x'],count,s,h,name=='colon',10000,20261122+i+int(1000*s))
                yv=int(pat['death']==1 and pat['time']<=s+h)
                wt=1/max(G(pat['time'],True),.05) if yv else (1/max(G(s+h),.05) if pat['time']>s+h else 0.)
                y.append(yv);w.append(wt);p.append(ph);X.append(np.r_[pat['x'],count])
                forecasts.append(dict(dataset=name,id=pat['id'],landmark=s,horizon=h,predicted_death=ph,death_MCSE=np.sqrt(ph*(1-ph)/10000),predicted_recurrences=burden,restricted_survival=rmean,event=yv,weight=wt))
            y=np.array(y);w=np.array(w);p=np.array(p);perform.append(dict(dataset=name,model='history_joint_gamma',landmark=s,horizon=h,**metrics(y,p,w)))
            # Genuine landmarked nonlinear comparator with independently trained
            # fixed-horizon censoring weights; labelled RF, not RSF.
            tx=[];ty=[];tw=[]
            for i in train:
                pat=pts[i]
                if pat['time']<=s:continue
                yy=int(pat['death']==1 and pat['time']<=s+h)
                ww=1/max(G(pat['time'],True),.05) if yy else (1/max(G(s+h),.05) if pat['time']>s+h else 0.)
                if ww>0:tx.append(np.r_[pat['x'],np.sum(pat['events']<=s)]);ty.append(yy);tw.append(ww)
            forest=RandomForestClassifier(n_estimators=300,min_samples_leaf=15,max_features=1.0,random_state=20261122,n_jobs=1).fit(tx,ty,sample_weight=tw)
            rf=forest.predict_proba(np.array(X))[:,1];perform.append(dict(dataset=name,model='landmark_weighted_random_forest',landmark=s,horizon=h,**metrics(y,rf,w)))
            # Nonparametric marginal benchmark, same known endpoint and weights.
            base=np.average(ty,weights=tw);perform.append(dict(dataset=name,model='marginal_training_risk',landmark=s,horizon=h,**metrics(y,np.full(len(y),base),w)))
        totals.append(dict(dataset=name,patients=n,recurrent_events=sum(len(p['events']) for p in pts),deaths=sum(p['death'] for p in pts),training=len(train),test=len(test)))
    pd.DataFrame(totals).to_csv(ROOT/'results/application_counts.csv',index=False)
    pd.DataFrame(estimates).to_csv(ROOT/'results/application_coefficients.csv',index=False)
    pd.DataFrame(perform).to_csv(ROOT/'results/application_performance.csv',index=False)
    pd.DataFrame(forecasts).to_csv(ROOT/'results/application_forecasts.csv',index=False)
    (ROOT/'results/application_fit_status.json').write_text(json.dumps(statuses,indent=2))
    print(pd.DataFrame(totals).to_string(index=False));print(pd.DataFrame(perform).to_string(index=False));print(statuses)

if __name__=='__main__':main()
