"""Observed-information logdet regularization and nonlinear sandwich simulation.

This is a local positive-information-domain regularizer, not a general Firth
bias-reduced score. No finite-sample coverage or posterior interpretation is assumed.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,time,argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,pandas as pd
from scipy.optimize import minimize
from scipy.optimize._numdiff import approx_derivative
from scipy.special import logit,expit
from numba import njit
from joint_model import JointGamma,simulate,simulation_design,truth
from revision_bands import H,queries
ROOT=Path(__file__).resolve().parents[1]
P=json.loads((ROOT/'protocol/prespec_sparse_v2.json').read_text())

class PenalizedGamma:
    def __init__(self,model):self.m=model;self.dmax=int(model.d.max())
    def info(self,theta):
        m=self.m;v=m.dt*np.exp(m.X@theta[:m.p]);a=np.exp(-theta[-1]);dtype=np.result_type(theta,float)
        # bincount rejects complex weights; sum real and imaginary parts separately.
        def total(v):
            if np.iscomplexobj(v):return np.bincount(m.ids,weights=v.real,minlength=m.n)+1j*np.bincount(m.ids,weights=v.imag,minlength=m.n)
            return np.bincount(m.ids,weights=v,minlength=m.n)
        A=total(v);A1=np.column_stack([total(v*m.X[:,j]) for j in range(m.p)]);w=(a+m.d)/(a+A)
        bb=m.X.T@((v*w[m.ids])[:,None]*m.X)-A1.T@((w/(a+A))[:,None]*A1)
        dig=np.zeros(m.n,dtype=dtype);tri=np.zeros(m.n,dtype=dtype)
        for k in range(self.dmax):
            yes=m.d>k;dig[yes]+=1/(a+k);tri[yes]-=1/(a+k)**2
        ua=dig+np.log(a)+1-np.log(a+A)-(a+m.d)/(a+A)
        uaa=tri+1/a-1/(a+A)+(m.d-A)/(a+A)**2
        cross=np.sum((-a*(A-m.d)/(a+A)**2)[:,None]*A1,axis=0)
        mat=np.zeros((m.p+1,m.p+1),dtype=dtype);mat[:m.p,:m.p]=bb;mat[:m.p,-1]=cross;mat[-1,:m.p]=cross;mat[-1,-1]=np.sum(-a*ua-a*a*uaa)
        return (mat+mat.T)/2
    def value(self,b):
        val,grad=self.m.evaluate(b);I=self.info(b)
        sign,ld=np.linalg.slogdet(I)
        if sign<=0 or np.linalg.eigvalsh(I).min()<=1e-10:return 1e20,np.zeros(len(b))
        inv=np.linalg.inv(I);adjustment=self.penalty_score(b,inv)
        return val-.5*ld/self.m.n,grad-adjustment/self.m.n
    def penalty_score(self,b,inv):
        # Analytic trace contraction avoids forming 13 third-derivative matrices.
        m=self.m;a=np.exp(-b[-1]);v=m.dt*np.exp(m.X@b[:m.p])
        A=np.bincount(m.ids,weights=v,minlength=m.n)
        A1=np.column_stack([np.bincount(m.ids,weights=v*m.X[:,j],minlength=m.n) for j in range(m.p)])
        h=a+A;w=(a+m.d)/h;t=w/h;g=-a*(A-m.d)/h**2
        K=inv[:m.p,:m.p];k=inv[:m.p,-1];c=inv[-1,-1]
        s=np.sum((m.X@K)*m.X,axis=1);C=np.bincount(m.ids,weights=v*s,minlength=m.n)
        AK=A1@K;B=np.sum(AK*A1,axis=1);E=A1@k
        ga=-a/h**2+2*a*(A-m.d)/h**3;ha=a*(A-m.d)*(A-a)/h**3
        coef=-t*C+2*t*B/h+2*ga*E+c*ha
        rowterm=w[m.ids]*s-2*t[m.ids]*np.sum(m.X*AK[m.ids],axis=1)+2*g[m.ids]*(m.X@k)
        adj=np.empty(m.p+1);adj[:m.p]=.5*(A1.T@coef+m.X.T@(v*rowterm))
        dig=np.zeros(m.n);tri=np.zeros(m.n);tet=np.zeros(m.n)
        for j in range(self.dmax):
            yes=m.d>j;dig[yes]+=1/(a+j);tri[yes]-=1/(a+j)**2;tet[yes]+=2/(a+j)**3
        ua=dig+np.log(a)+1-np.log(h)-(a+m.d)/h
        uaa=tri+1/a-1/h+(m.d-A)/h**2
        uaaa=tet-1/a**2+1/h**2-2*(m.d-A)/h**3
        wa=(A-m.d)/h**2;ta=(A-a-2*m.d)/h**3;gga=(A-m.d)*(a-A)/h**3;hha=-ua-3*a*uaa-a*a*uaaa
        adj[-1]=-.5*a*np.sum(wa*C-ta*B+2*gga*E+c*hha)
        return adj
    def fit(self,start):
        opt=minimize(self.value,start,jac=True,method='L-BFGS-B',bounds=[(-12,8)]*self.m.p+[(-5,2.5)],options=dict(maxiter=120,ftol=1e-12,gtol=1e-7,maxls=30))
        val,g=self.value(opt.x)
        if val>=1e19:raise ValueError('Outside positive information domain')
        h=approx_derivative(lambda b:self.value(b)[1],opt.x,method='3-point')*self.m.n;h=(h+h.T)/2
        if np.linalg.eigvalsh(h).min()<=1e-8:raise ValueError('Nonpositive penalized curvature')
        inv=np.linalg.inv(h);_,score=self.m.evaluate(opt.x,individual=True);score=score-score.mean(axis=0);V=inv@score.T@score@inv
        ok=bool(opt.success and max(abs(g))<1e-5)
        boundary=bool(np.any(abs(opt.x[:-1]+12)<1e-4) or np.any(abs(opt.x[:-1]-8)<1e-4) or abs(opt.x[-1]+5)<1e-4 or abs(opt.x[-1]-2.5)<1e-4)
        return opt.x,V,ok,boundary,float(max(abs(g))),int(opt.nit)

@njit(cache=True)
def risk_draws(draws,horizons):
    out=np.zeros((len(draws),len(horizons)));massmax=0.;iterationsmax=0
    for d in range(len(draws)):
        b=draws[d];a=np.exp(-b[-1]);A=0.
        # Same complete history as forecast_verification: x=1, events at .2 and .8.
        for start,stop,c1,c2 in [(0.,.2,0,0),(.2,.8,1,0),(.8,1.,1,1)]:
            for k in range(3):
                h=c2 if k==0 else (c1 if k==1 else (c1+c2)/2.)
                A+=(stop-start)*np.exp(b[4*k]+b[4*k+2]+b[4*k+3]*h)
        shape=a+2;rate=a+A;Q=np.zeros((5,5))
        for c1 in range(1,3):
            for c2 in range(1,3):
                j=2*(c1-1)+(c2-1)
                for k in range(3):
                    h=c2 if k==0 else (c1 if k==1 else (c1+c2)/2.)
                    r=np.exp(b[4*k+1]+b[4*k+2]+b[4*k+3]*h)
                    target=2*(min(c1+1,2)-1)+c2-1 if k==0 else (2*(c1-1)+min(c2+1,2)-1 if k==1 else 4)
                    if target!=j:Q[j,target]+=r;Q[j,j]-=r
        nu=max(-np.diag(Q));P0=np.eye(5)+Q/nu
        for j,h in enumerate(horizons):
            ratio=nu*h/(rate+nu*h);weight=np.exp(shape*np.log1p(-ratio));total=weight;row=np.zeros(5);row[0]=1;ans=weight*row
            for k in range(1,10000):
                row=row@P0;weight*=((shape+k-1)/k)*ratio;ans+=weight*row;total+=weight
                if 1-total<1e-12:break
            if k==9999:out[d,j]=np.nan
            else:out[d,j]=ans[4]
            massmax=max(massmax,abs(1-ans.sum()));iterationsmax=max(iterationsmax,k)
    return out,massmax,iterationsmax

def bands(b,V,seed):
    e,v=np.linalg.eigh((V+V.T)/2)
    if e.min()<-1e-8:raise ValueError('Indefinite sandwich covariance')
    draws=b+np.random.default_rng(seed).standard_normal((1000,len(b)))@(v*np.sqrt(np.maximum(e,0))).T
    p,mass,it=risk_draws(draws,H);point=risk_draws(b[None,:],H)[0][0]
    if np.any(~np.isfinite(p)) or np.any(p<=0) or np.any(p>=1):raise ValueError('Invalid/saturated forecast draw; no clipping or resampling')
    z=logit(p);center=logit(point);sd=z.std(axis=0,ddof=1)
    if np.any(sd<=0):raise ValueError('Degenerate logit spread')
    critical=np.quantile(np.max(abs(z-center)/sd,axis=1),.95);lo=expit(center-critical*sd);hi=expit(center+critical*sd)
    return lo,hi,point,float(mass),int(it),float(critical),bool(np.all(np.diff(p,axis=1)>=-1e-12)),bool(np.all(lo>0)&np.all(hi<1))

def batch(items):
    out=[]
    for item in items:
        cell,n,s,rep,seed,start,oracle=item;t=time.time()
        row=dict(cell=cell,n=n,scenario=s,replicate=rep,seed=seed,valid=False,coverage=False)
        try:
            m=JointGamma(*simulation_design(simulate(n,seed,s)));pen=PenalizedGamma(m);b,V,ok,bd,g,nit=pen.fit(start)
            lo,hi,p,mass,it,c,mono,inside=bands(b,V,seed+90000000)
            row.update(valid=ok,coverage=bool(ok and np.all((lo<=oracle)&(oracle<=hi))),boundary=bd,gradient=g,iterations=nit,mass_error=mass,uniformization_iterations=it,critical=c,all_draws_monotone=mono,strict_interior=inside)
            for j in range(4):row.update({f'lower_{j}':lo[j],f'upper_{j}':hi[j],f'width_{j}':hi[j]-lo[j],f'risk_{j}':p[j]})
        except Exception as exc:row['error']=repr(exc)
        row['seconds']=time.time()-t;out.append(row)
    return out

def checks():
    b=truth();m=JointGamma(*simulation_design(simulate(80,99273)));pen=PenalizedGamma(m);fd=approx_derivative(lambda a:np.array([pen.value(a)[0]]),b).ravel()
    out=dict(information_agreement=float(max(abs((pen.info(b)-m.information(b)).ravel()))),penalty_gradient_error=float(max(abs(fd-pen.value(b)[1]))),fast_risk_agreement=float(max(abs(risk_draws(b[None,:],H)[0][0]-queries(b)))),scope='Positive information fixture; observed-information regularization, not automatic Firth bias correction')
    out['requested_score_gate_pass']=out['penalty_gradient_error']<1e-10
    inv=np.linalg.inv(pen.info(b));complex_score=[]
    for k in range(len(b)):
        z=b.astype(complex);z[k]+=1e-20j;di=np.imag(pen.info(z))/1e-20;complex_score.append(.5*np.trace(inv@di))
    out['analytic_trace_vs_complex_step']=float(max(abs(pen.penalty_score(b,inv)-complex_score)))
    assert out['analytic_trace_vs_complex_step']<1e-8
    assert out['information_agreement']<1e-8 and out['fast_risk_agreement']<1e-10
    (ROOT/'results/sparse_continuous_checks.json').write_text(json.dumps(out,indent=2));print(out,flush=True)

def main(workers):
    path=ROOT/'results/sparse_continuous_replicates.csv'
    if path.exists():raise FileExistsError(path)
    checks();old=pd.read_csv(ROOT/'results/revision_band_replicates.csv');items=[]
    # Saved raw rows define the exact cohorts. Starting estimates are deterministic refits.
    # They were not stored in the band table, so refit once rather than infer coefficients.
    for r in old.itertuples():items.append((int(r.cell),int(r.n),int(r.scenario),int(r.replicate),int(r.seed)))
    start=time.time();rows=[]
    with ProcessPoolExecutor(workers) as pool:
        for f in as_completed([pool.submit(refit_batch,items[a:a+10]) for a in range(0,len(items),10)]):
            rows.extend(f.result())
            if len(rows)%500==0:print('continuous sparse',len(rows),round(time.time()-start,1),'seconds',flush=True)
    d=pd.DataFrame(rows).sort_values(['cell','replicate']);d.to_csv(path,index=False);summary=[]
    for (cell,n,s),g in d.groupby(['cell','n','scenario']):
        cv=g.coverage.fillna(False).mean();ok=g.valid.fillna(False)
        for j in range(4):summary.append(dict(cell=cell,n=n,scenario=s,query=j,B=len(g),valid=int(ok.sum()),coverage=cv,MCSE=np.sqrt(cv*(1-cv)/len(g)),median_width=g.loc[ok,f'width_{j}'].median(),passes_two_MCSE=abs(cv-.95)<=2*np.sqrt(cv*(1-cv)/len(g))))
    pd.DataFrame(summary).to_csv(ROOT/'results/sparse_continuous_summary.csv',index=False)
    (ROOT/'results/sparse_continuous_run.json').write_text(json.dumps(dict(B=5000,cells=4,seconds=time.time()-start,parameter_draws=1000,paired_rows=len(d)),indent=2))

def refit_batch(rows):
    items=[];failed=[]
    for cell,n,s,rep,seed in rows:
        try:
            fit=JointGamma(*simulation_design(simulate(n,seed,s))).fit()
            items.append((cell,n,s,rep,seed,fit.theta,queries(truth(s))))
        except Exception as exc:failed.append(dict(cell=cell,n=n,scenario=s,replicate=rep,seed=seed,valid=False,coverage=False,error=repr(exc)))
    return failed+batch(items)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=4);p.add_argument('--checks-only',action='store_true');args=p.parse_args();checks() if args.checks_only else main(args.workers)
