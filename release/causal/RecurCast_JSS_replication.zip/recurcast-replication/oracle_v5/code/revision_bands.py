"""Prespecified finite-query band experiment. Every failed fit remains in the denominator."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import json,time,argparse
import numpy as np,pandas as pd
from scipy.optimize._numdiff import approx_derivative
from joint_model import JointGamma,simulate,simulation_design,truth
from forecast_verification import risk
ROOT=Path(__file__).resolve().parents[1]
PROTOCOL=json.loads((ROOT/'protocol/revision_protocol.json').read_text())
H=np.array(PROTOCOL['band_query']['horizons'])
NORMAL=np.random.default_rng(972034).standard_normal((PROTOCOL['gaussian_draws'],len(H)))
def queries(b):return np.array([risk(b,1,(1,1),float(h)) for h in H])
def bands(fit):
    p=queries(fit.theta);J=approx_derivative(queries,fit.theta,method='3-point')
    V=J@fit.sandwich@J.T;V=(V+V.T)/2;se=np.sqrt(np.diag(V))
    if not np.all(se>0):raise ValueError('Nonpositive query variance')
    C=V/np.outer(se,se);e,v=np.linalg.eigh((C+C.T)/2)
    if e.min()<-1e-8:raise ValueError('Indefinite query covariance')
    draws=NORMAL@(v*np.sqrt(np.maximum(e,0))).T
    critical=np.quantile(abs(draws).max(axis=1),.95)
    return p,se,critical,J
def batch(job):
    cell,n,s,lo,hi=job;rows=[];oracle=queries(truth(s))
    for rep in range(lo,hi):
        seed=PROTOCOL['base_seed']+cell*1000000+rep
        row=dict(cell=cell,n=n,scenario=s,replicate=rep,seed=seed,valid=False,simultaneous_cover=False,pointwise_joint_cover=False)
        try:
            fit=JointGamma(*simulation_design(simulate(n,seed,s))).fit()
            row.update(fit.status)
            if fit.ok:
                p,se,critical,J=bands(fit)
                row.update(critical=float(critical),simultaneous_cover=bool(np.all(abs(p-oracle)<=critical*se)),pointwise_joint_cover=bool(np.all(abs(p-oracle)<=1.95996398454*se)),max_width=float(np.max(2*critical*se)),mean_width=float(np.mean(2*critical*se)))
                for j in range(4):row.update({f'risk_{j}':p[j],f'truth_{j}':oracle[j],f'se_{j}':se[j],f'pointwise_cover_{j}':bool(abs(p[j]-oracle[j])<=1.95996398454*se[j])})
                # Finite-family empirical IF; covariance identity is algebraic.
                IF=fit.scores@np.linalg.inv(fit.info).T*fit.n
                row['IF_sandwich_max_error']=float(np.max(abs(IF.T@IF/fit.n**2-fit.sandwich)))
        except Exception as exc:row.update(valid=False,error=repr(exc))
        rows.append(row)
    return rows
def summarize(df):
    rows=[]
    for (cell,n,s),g in df.groupby(['cell','n','scenario']):
        ok=g[g.valid];B=len(g)
        for method,col in [('max_t','simultaneous_cover'),('pointwise_joint','pointwise_joint_cover')]:
            p=g[col].fillna(False).mean();pv=ok[col].mean()
            rows.append(dict(cell=cell,n=n,scenario=s,method=method,B=B,valid=len(ok),failed=B-len(ok),coverage_all=p,coverage_valid=pv,MCSE_all=np.sqrt(p*(1-p)/B),mean_width=ok.mean_width.mean() if method=='max_t' else np.nan,mean_critical=ok.critical.mean(),boundary_fits=int(g.at_parameter_boundary.fillna(False).sum())))
    return pd.DataFrame(rows)
def main(B,workers):
    out=ROOT/'results/revision_band_replicates.csv'
    if out.exists():raise FileExistsError(out)
    jobs=[]
    for c,spec in enumerate(PROTOCOL['new_band_cells']):
        for lo in range(0,B,25):jobs.append((c,spec['n'],spec['scenario'],lo,min(B,lo+25)))
    start=time.time();done=0
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for f in as_completed([pool.submit(batch,j) for j in jobs]):
            r=f.result();pd.DataFrame(r).to_csv(out,index=False,mode='a' if out.exists() else 'w',header=not out.exists());done+=len(r)
            if done%500==0:print(f'{done}/{4*B} band fits, {time.time()-start:.1f} seconds',flush=True)
    d=pd.read_csv(out);d=d.sort_values(['cell','replicate']);d.to_csv(out,index=False)
    summary=summarize(d);summary.to_csv(ROOT/'results/revision_band_summary.csv',index=False)
    (ROOT/'results/revision_band_run.json').write_text(json.dumps(dict(B=B,cells=4,seconds=time.time()-start,workers=workers),indent=2))
    print(summary.to_string(index=False),flush=True)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--B',type=int,default=PROTOCOL['B']);a.add_argument('--workers',type=int,default=8);a=a.parse_args();main(a.B,a.workers)
