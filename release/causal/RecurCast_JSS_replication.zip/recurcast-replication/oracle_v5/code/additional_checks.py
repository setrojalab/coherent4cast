"""Independent Cox reproduction, estimated cross-fitting and validation precision."""
from pathlib import Path
import numpy as np,pandas as pd,json
from sklearn.metrics import roc_auc_score
from applications import metrics
ROOT=Path(__file__).resolve().parents[1]

def k0():
    d=pd.read_csv(ROOT/'data/raw/colon_trial.csv');d=d[d.etype==2]
    X=np.column_stack([d.sex,(d.age-60)/10,d.node4]);t=d.time.to_numpy();y=d.status.to_numpy();times=np.unique(t[y==1]);b=np.zeros(3)
    def stats(b):
        w=np.exp(X@b);score=np.zeros(3);info=np.zeros((3,3));jumps=[]
        for u in times:
            ix=t>=u;event=(t==u)&(y==1);dn=event.sum();s0=w[ix].sum();s1=(w[ix,None]*X[ix]).sum(axis=0);s2=(X[ix].T*w[ix])@X[ix]
            score+=X[event].sum(axis=0)-dn*s1/s0;info+=dn*(s2/s0-np.outer(s1,s1)/s0**2);jumps.append(dn/s0)
        return score,info,np.array(jumps)
    for _ in range(40):
        s,H,j=stats(b);step=np.linalg.solve(H,s);b+=step
        if abs(step).max()<1e-13:break
    ref=pd.read_csv(ROOT/'results/K0_R_coefficients.csv')['coef'].to_numpy();rr=pd.read_csv(ROOT/'results/K0_R_baseline.csv')
    H0=np.cumsum(stats(b)[2]);refH=np.interp(times,rr.time,rr.hazard);errcoef=abs(b-ref).max();errH=abs(H0-refH).max()
    assert errcoef<1e-8 and errH<1e-8
    return dict(coefficient_max_error=float(errcoef),Breslow_cumulative_hazard_max_error=float(errH),subjects=len(d),comparison='independent Python Newton score versus survival::coxph with Breslow ties')

def crossfit(B=2000,n=500):
    rng=np.random.default_rng(20261126);rows=[];score_example=None
    for rep in range(B):
        x=rng.binomial(1,.5,n);a=rng.binomial(1,.2+.6*x);r=rng.binomial(1,.9-.4*x);y=rng.binomial(1,.1+.15*a+.3*x+.2*a*x)
        fold=rng.permutation(n)%5;pred=np.zeros((3,2,n))
        for f in range(5):
            train=fold!=f;valid=~train
            for good in [0,1]:
                for xx in [0,1]:
                    base=train&((x==xx) if good else np.ones(n,bool));ix=valid&(x==xx)
                    # Jeffreys smoothing is prespecified to avoid zero cells.
                    pred[0,good,ix]=(np.sum(y[base&(a==1)&(r==1)])+.5)/(np.sum(base&(a==1)&(r==1))+1)
                    pred[1,good,ix]=(np.sum(a[base])+.5)/(base.sum()+1)
                    pred[2,good,ix]=(np.sum(r[base&(a==1)])+.5)/(np.sum(base&(a==1))+1)
        for cm in [0,1]:
            for ce in [0,1]:
                for cp in [0,1]:
                    m=pred[0,cm];e=pred[1,ce];pi=pred[2,cp];v=m+(a==1)*r/(e*pi)*(y-m);est=v.mean();D=v-est;se=np.std(D,ddof=1)/np.sqrt(n)
                    rows.append(dict(replicate=rep,outcome_correct=cm,treatment_correct=ce,recording_correct=cp,estimate=est,se=se,EIF_mean=D.mean(),EIF_variance=np.var(D,ddof=1),coverage=abs(est-.5)<=1.96*se))
                    if rep==0 and cm==ce==cp==1:score_example=pd.DataFrame(dict(subject=np.arange(n),fold=fold,x=x,treatment=a,recorded=r,outcome=np.where(r,y,np.nan),mu=m,propensity=e,recording_probability=pi,uncentered_score=v,EIF=D))
    d=pd.DataFrame(rows);d.to_csv(ROOT/'results/crossfit_replicates.csv',index=False);score_example.to_csv(ROOT/'data/derived/crossfit_EIF_example.csv',index=False)
    ans=d.groupby(['outcome_correct','treatment_correct','recording_correct']).agg(B=('replicate','size'),mean=('estimate','mean'),ESE=('estimate','std'),ASE=('se','mean'),coverage=('coverage','mean'),EIF_variance=('EIF_variance','mean')).reset_index()
    ans['bias']=ans['mean']-.5;ans['relative_bias']=ans.bias/.5;ans['bias_MCSE']=ans.ESE/np.sqrt(B);ans['ASE_ESE']=ans.ASE/ans.ESE
    ans['efficiency_ratio']=n*ans.ESE**2/(.8177083333333333)
    ans.to_csv(ROOT/'results/crossfit_summary.csv',index=False)

def application_validation():
    d=pd.read_csv(ROOT/'results/application_forecasts.csv');c=pd.read_csv(ROOT/'results/classical_predictions.csv');perf=pd.read_csv(ROOT/'results/application_performance.csv');extra=[];ci=[]
    rng=np.random.default_rng(20261127)
    for (nm,s),g in d.groupby(['dataset','landmark']):
        other=c[(c.dataset==nm)&(c.landmark==s)];g=g.merge(other[['id','prediction']],on='id',validate='one_to_one')
        y=g.event.to_numpy();w=g.weight.to_numpy();p=g.prediction.to_numpy();extra.append(dict(dataset=nm,model='frozen_history_Cox',landmark=s,horizon=1,**metrics(y,p,w)))
        for label,pv in [('history_joint_gamma',g.predicted_death.to_numpy()),('frozen_history_Cox',p)]:
            values=[]
            for b in range(2000):
                ix=rng.integers(0,len(g),len(g));known=w[ix]>0
                auc=roc_auc_score(y[ix][known],pv[ix][known],sample_weight=w[ix][known]) if len(np.unique(y[ix][known]))==2 else np.nan
                values.append((np.mean(w[ix]*(y[ix]-pv[ix])**2),auc))
            a=np.array(values)
            ci.append(dict(dataset=nm,landmark=s,model=label,B=2000,Brier_low=np.quantile(a[:,0],.025),Brier_high=np.quantile(a[:,0],.975),AUC_low=np.nanquantile(a[:,1],.025),AUC_high=np.nanquantile(a[:,1],.975),AUC_valid=int(np.isfinite(a[:,1]).sum()),scope='test-subject bootstrap conditional on fitted training models and censoring weights'))
    pd.concat([perf[perf.model!='frozen_history_Cox'],pd.DataFrame(extra)],ignore_index=True).to_csv(ROOT/'results/application_performance.csv',index=False)
    pd.DataFrame(ci).to_csv(ROOT/'results/application_validation_CI.csv',index=False)

def baseline_errors():
    d=pd.read_csv(ROOT/'results/simulation_replicates.csv');rows=[]
    for (s,n),g in d.groupby(['scenario','n']):
        for k,rate in enumerate([.65,.30,.16]):
            a=np.exp(g[f'est_{4*k}'])-rate;b=a+np.exp(g[f'est_{4*k+1}'])-1.25*rate;sup=np.maximum(abs(a),abs(b))
            rows.append(dict(scenario=s,n=n,event_type=k,B=len(g),mean_sup_error=sup.mean(),MCSE=sup.std()/np.sqrt(len(g)),scaled_sqrt_n=np.sqrt(n)*sup.mean()))
    pd.DataFrame(rows).to_csv(ROOT/'results/baseline_sup_errors.csv',index=False)

if __name__=='__main__':
    a=k0();(ROOT/'results/K0_independent_check.json').write_text(json.dumps(a,indent=2));print(a,flush=True)
    crossfit();print('Estimated five-fold EIF experiments complete.',flush=True)
    application_validation();baseline_errors();print('Validation intervals and baseline errors complete.',flush=True)
