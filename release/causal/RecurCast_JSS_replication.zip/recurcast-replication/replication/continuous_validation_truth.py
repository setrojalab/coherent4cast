from pathlib import Path
import numpy as np,pandas as pd
from scipy.linalg import expm
root=Path(__file__).resolve().parents[1];rows=[]
for sparse in [False,True]:
 values=[]
 for x in [0,1]:
  q=np.zeros((10,10));r=np.zeros((10,3))
  for state in range(9):
   c1,c2=divmod(state,3);rate=np.array([.7,.025 if sparse else .25,.006 if sparse else .12])*np.exp(-.25*x+np.array([.3*c2,.35*c1,.45*(c1+c2)/2]))
   dest=[3*min(c1+1,2)+c2,3*c1+min(c2+1,2),9]
   for k,d in enumerate(dest):
    if d!=state:q[state,d]+=rate[k]
   q[state,state]=-q[state].sum();r[state]=[rate[0],rate[1],1]
  augmented=np.zeros((13,13));augmented[:10,:10]=q;augmented[:10,10:]=r
  a=expm(augmented);values.append([a[0,10],a[0,11],a[0,9],a[0,12]])
 truth=np.mean(values,axis=0);rows.append(dict(sparse=int(sparse),burden1=truth[0],burden2=truth[1],risk=truth[2],rmst=truth[3]))
pd.DataFrame(rows).to_csv(root/'replication/continuous_validation_truth.csv',index=False)
print(pd.DataFrame(rows))
