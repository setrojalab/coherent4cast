"""Compare scientific tables, omitting measured runtime and device metadata."""
from pathlib import Path
import csv, json, math, hashlib
ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'replication/fresh_runs/run1/cases'
B=ROOT/'replication/fresh_runs/run2/cases'
for directory in (A, B):
    assert (directory.parent/'COMPLETED.txt').is_file(), (str(directory), 'fresh run incomplete')
    required={'case_summary.csv','heldout_metrics.csv','forecast_curve_summary.csv','colon_quadrature_audit.csv'}
    assert required.issubset({p.name for p in directory.glob('*.csv')}), (str(directory),'missing scientific tables')
assert {p.name for p in A.glob('*.csv')} == {p.name for p in B.glob('*.csv')}, 'table sets differ'
rows=[]
for first in sorted(A.glob('*.csv')):
    second=B/first.name
    with first.open(newline='') as f: aa=list(csv.DictReader(f))
    with second.open(newline='') as f: bb=list(csv.DictReader(f))
    assert len(aa)==len(bb) and len(aa)>0,(first.name,'row count')
    err=0.0
    for a,b in zip(aa,bb):
        assert a.keys()==b.keys()
        for k in a:
            if k in {'elapsed_seconds'}: continue
            try:
                x,y=float(a[k]),float(b[k])
                if math.isnan(x) and math.isnan(y):continue
                err=max(err,abs(x-y))
                assert math.isclose(x,y,rel_tol=1e-10,abs_tol=1e-10),(first.name,k,x,y)
            except ValueError:
                assert a[k]==b[k],(first.name,k,a[k],b[k])
    rows.append({'table':first.name,'rows':len(aa),'maximum_absolute_difference':err,'passed':True})
assert rows, 'No scientific tables were compared'
result={'comparison':'Two fresh same-platform fits, no cached models',
    'scope':'Scientific CSV values; wall time, PDF/PNG device metadata and session text are not equality targets',
    'tables':rows,'all_passed':all(x['passed'] for x in rows),
    'input_scripts_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'replication/run_case_studies.R',ROOT/'replication/reproduce_cases.R']}}
(ROOT/'reviews/fresh_replication_comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
