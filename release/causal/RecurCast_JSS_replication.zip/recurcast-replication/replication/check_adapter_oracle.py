"""Compare the R adapter with the frozen independent V5 path construction.

Run after exporting temporary adapter CSVs under build/. These files are local
verification inputs and are not bundled package data.
"""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "oracle_v5/code"))
from revision_coarsening import CoarsenedColon
from applications import design
from joint_model import JointGamma

oracle = CoarsenedColon(nodes=4)
data = pd.read_csv(ROOT / "build/p4_colon_adapter.csv")
weights = pd.read_csv(ROOT / "build/p4_colon_weights.csv")
segments = []
for row in data.itertuples(index=False):
    x = np.array([row.levamisole, row.levamisole_5fu, row.male,
                  row.age_per_10, row.node4], dtype=float)
    segments.append((row.id - 1, row.start, row.stop, int(row.event_type),
                     int(row.terminal), int(row.start > 0), x))
args, active, p0 = design(segments, "colon")
model = JointGamma(*args)
theta = np.linspace(-.6, .3, model.p + 1)
theta[-1] = np.log(.45)
left = model.evaluate(theta, True)
right = oracle.model.evaluate(theta, True)
report = dict(
    subjects=oracle.n, paths=oracle.model.n, same_day_ids=oracle.ties,
    owner_agreement=bool(np.array_equal(weights.owner.to_numpy() - 1, oracle.owner)),
    max_log_weight_error=float(np.max(np.abs(weights.log_weights - oracle.logweight))),
    max_path_loglik_error=float(np.max(np.abs(left[0] - right[0]))),
    max_path_score_error=float(np.max(np.abs(left[1] - right[1]))),
    scope="R canonical-data adapter compared with frozen V5 Python path construction at a fixed parameter vector; not clinical efficacy evidence")
assert report["owner_agreement"]
assert report["max_log_weight_error"] < 1e-10
assert report["max_path_loglik_error"] < 1e-10
assert report["max_path_score_error"] < 1e-10
(ROOT / "reviews/P4_adapter_oracle.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
