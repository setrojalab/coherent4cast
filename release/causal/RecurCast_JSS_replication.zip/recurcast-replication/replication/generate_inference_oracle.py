"""Generate small inference fixtures from the preserved V5 oracle, never alter it."""
from pathlib import Path
import sys,json
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'oracle_v5/code'))
import targeted_path_law as target
import expanded_verification as sensitivity
out=ROOT/'package/tests/testthat/fixtures';out.mkdir(exist_ok=True,parents=True)
x,path,r,fold=target.make_data(800,20261122,'low_recording_MAR')
fit=target.fit_law(x,path,r,fold)
pd.DataFrame(dict(path=np.where(r==1,path+1,np.nan),recorded=r,strata=x,fold=fold+1)).to_csv(out/'target_subjects.csv',index=False)
pd.DataFrame(target.F,columns=['recurrent_1','recurrent_2','terminal','restricted_time']).to_csv(out/'target_features.csv',index=False)
pd.DataFrame(dict(estimate=fit['psi'],se=fit['se'])).to_csv(out/'target_expected.csv',index=False)
pd.DataFrame(fit['D']).to_csv(out/'target_eif.csv',index=False)
pd.DataFrame(fit['q']).to_csv(out/'target_laws.csv',index=False)
rows=[]
for J in [3,5]:
 p=np.arange(J,0,-1,dtype=float);p/=p.sum()
 for k in [1,1.5,2,3]:
  lo,hi=sensitivity.lp(p,k)
  rows.append(dict(J=J,kappa=k,lower=lo,upper=hi))
pd.DataFrame(rows).to_csv(out/'bounds_expected.csv',index=False)
# Sample CP outer-projection fixtures, including highly sparse recorded supports.
rng=np.random.default_rng(20261122); rows=[]
from scipy.stats import beta
for J in [3,5]:
 for n in [25,250]:
  for k in [1,2,3]:
   p0=np.arange(J,0,-1,dtype=float);p0/=p0.sum(); counts=rng.multinomial(n,p0);p=counts/n
   lb=np.array([0 if v==0 else beta.ppf(.05/(2*J),v,n-v+1) for v in counts])*.7
   ub=np.array([1 if v==n else beta.ppf(1-.05/(2*J),v+1,n-v) for v in counts])*.7
   lo,hi=sensitivity.lp(p,k,list(zip(lb,ub)))
   rows.append(dict(J=J,n=n,kappa=k,counts=';'.join(map(str,counts)),lower=lo,upper=hi))
pd.DataFrame(rows).to_csv(out/'projection_expected.csv',index=False)
(out/'oracle_provenance.json').write_text(json.dumps({'origin':'preserved oracle_v5/code','seed':20261122,'target_n':800,'target_valid':fit['valid'],'scope':'Deterministic numerical parity fixtures; not a fresh simulation coverage claim'},indent=2))
print('Generated target, LP and 12 projection oracle fixtures')
