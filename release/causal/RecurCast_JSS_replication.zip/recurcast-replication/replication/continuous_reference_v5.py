"""Continuous event-time intensity targeting under independent right censoring.

Finite retained state, unbounded recurrent counts, exact event times. The numerical
fluctuation is piecewise constant in time; value propagation uses uniformization.
The martingale EIF is evaluated using cubic-Hermite value interpolation, audited
against exact within-interval propagation. This is not the 13-path experiment.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,argparse,time
import numpy as np,pandas as pd
from numba import njit
from concurrent.futures import ProcessPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parents[1]
TARGETS=['burden_1','burden_2','terminal_risk','restricted_survival']
NORMAL=np.random.default_rng(2026112303).standard_normal((4096,4))
NEXT=np.array([[3*min(q//3+1,2)+q%3,3*(q//3)+min(q%3+1,2),9] for q in range(9)],dtype=np.int64)

@njit(cache=True)
def true_rates(x):
    a=np.zeros((9,3));base=np.array([.7,.25,.12]);gamma=np.array([.3,.35,.45])
    for q in range(9):
        history=np.array([q%3,q//3,(q//3+q%3)/2])
        for k in range(3):a[q,k]=base[k]*np.exp(-.25*x+gamma[k]*history[k])
    return a

@njit(cache=True)
def simulate(n,seed):
    np.random.seed(seed);x=np.random.binomial(1,.5,n);fold=np.random.permutation(n)%5
    rows=np.zeros((n*80,7));r=0
    for i in range(n):
        lam=true_rates(x[i]);g=.35+.2*x[i];t=0.;q=0
        for jump in range(80):
            rate=lam[q].sum()+g;end=t+np.random.exponential(1/rate);event=-1
            if end<1:
                z=np.random.random()*rate;event=3
                for k in range(3):
                    z-=lam[q,k]
                    if z<=0:event=k;break
            else:end=1.
            rows[r]=np.array([i,x[i],fold[i],q,t,end,event]);r+=1
            if event==-1 or event>=2:break
            q=NEXT[q,event];t=end
        else:raise ValueError('Simulation row capacity exceeded')
    return rows[:r],x,fold

@njit(cache=True)
def Qvalue(lam,v,include_running=True):
    z=np.zeros((10,4))
    for q in range(9):
        for k in range(3):
            for j in range(4):z[q,j]+=lam[q,k]*(v[NEXT[q,k],j]-v[q,j])
        z[q,0]+=lam[q,0];z[q,1]+=lam[q,1]
        if include_running:z[q,3]+=1.
    return z

@njit(cache=True)
def propagate(lam,v,h):
    nu=lam.sum(axis=1).max();w=np.exp(-nu*h);total=w;term=v.copy();answer=w*term
    for m in range(1,200):
        term=term+Qvalue(lam,term)/nu;w*=nu*h/m;total+=w;answer+=w*term
        if 1-total<2e-15:break
    return answer

@njit(cache=True)
def integral_moments(u,a):
    out=np.zeros(4);weight=1.
    for m in range(15):
        for k in range(4):out[k]+=weight*u**(k+m+1)/(k+m+1)
        weight*=a/(m+1)
    return out

@njit(cache=True)
def construct(lam,g):
    L=lam.shape[2];h=1./L
    v=np.zeros((5,2,L+1,10,4));v[:,:,:,9,2]=1.
    poly=np.zeros((5,2,L,10,4,4));integ=np.zeros_like(poly);prefix=np.zeros_like(v)
    for f in range(5):
        for x in range(2):
            for b in range(L-1,-1,-1):
                v[f,x,b]=propagate(lam[f,x,b],v[f,x,b+1],h)
                d0=-h*Qvalue(lam[f,x,b],v[f,x,b]);d1=-h*Qvalue(lam[f,x,b],v[f,x,b+1])
                for q in range(10):
                    for j in range(4):
                        start=v[f,x,b,q,j];end=v[f,x,b+1,q,j]
                        poly[f,x,b,q,j,0]=start;poly[f,x,b,q,j,1]=d0[q,j]
                        poly[f,x,b,q,j,2]=3*(end-start)-2*d0[q,j]-d1[q,j]
                        poly[f,x,b,q,j,3]=2*(start-end)+d0[q,j]+d1[q,j]
                for q in range(9):
                    for k in range(3):
                        for j in range(4):
                            for power in range(4):integ[f,x,b,q,j,power]+=lam[f,x,b,q,k]*(poly[f,x,b,NEXT[q,k],j,power]-poly[f,x,b,q,j,power])
                    integ[f,x,b,q,0,0]+=lam[f,x,b,q,0];integ[f,x,b,q,1,0]+=lam[f,x,b,q,1]
            for b in range(L):
                moments=integral_moments(1.,g[f,x]*h)
                prefix[f,x,b+1]=prefix[f,x,b]
                for q in range(9):
                    for j in range(4):prefix[f,x,b+1,q,j]+=h*np.exp(g[f,x]*b*h)*np.dot(integ[f,x,b,q,j],moments)
    return v,poly,integ,prefix

@njit(cache=True)
def value_at(poly,f,x,q,t):
    L=poly.shape[2];b=min(int(t*L),L-1);u=t*L-b;out=np.zeros(4)
    for j in range(4):out[j]=poly[f,x,b,q,j,0]+u*(poly[f,x,b,q,j,1]+u*(poly[f,x,b,q,j,2]+u*poly[f,x,b,q,j,3]))
    return out

@njit(cache=True)
def cumulative_at(integ,prefix,g,f,x,q,t):
    L=integ.shape[2];b=min(int(t*L),L-1);u=t*L-b;moments=integral_moments(u,g[f,x]/L)
    out=prefix[f,x,b,q].copy()
    for j in range(4):out[j]+=np.exp(g[f,x]*b/L)/L*np.dot(integ[f,x,b,q,j],moments)
    return out

@njit(cache=True)
def evaluate(lam,g,rows,xs,fold,exposure):
    n=len(xs);L=lam.shape[2];v,poly,integ,prefix=construct(lam,g);D=np.zeros((n,4));psi=np.zeros(4)
    for i in range(n):D[i]=v[fold[i],xs[i],0,0];psi+=D[i]/n
    D-=psi
    for row in rows:
        i,x,f,q=int(row[0]),int(row[1]),int(row[2]),int(row[3]);a,b=row[4],row[5];k=int(row[6])
        D[i]-=cumulative_at(integ,prefix,g,f,x,q,b)-cumulative_at(integ,prefix,g,f,x,q,a)
        if k>=0 and k<3:
            jump=value_at(poly,f,x,NEXT[q,k],b)-value_at(poly,f,x,q,b)
            if k<2:jump[k]+=1.
            D[i]+=np.exp(g[f,x]*b)*jump
    info=np.zeros((4,4));clever=np.zeros((5,2,L,9,3,4))
    for f in range(5):
        for x in range(2):
            for b in range(L):
                t=(b+.5)/L
                for q in range(9):
                    before=value_at(poly,f,x,q,t)
                    for k in range(3):
                        H=value_at(poly,f,x,NEXT[q,k],t)-before
                        if k<2:H[k]+=1.
                        H*=np.exp(g[f,x]*t);clever[f,x,b,q,k]=H
                        info+=exposure[f,x,b,q]*lam[f,x,b,q,k]*np.outer(H,H)/n
    return psi,D,info,clever,v,poly

@njit(cache=True)
def nuisance(rows,L,correct):
    lam=np.zeros((5,2,L,9,3));g=np.zeros((5,2));exposure=np.zeros((5,2,L,9))
    for row in rows:
        x,f,q=int(row[1]),int(row[2]),int(row[3]);a,b=row[4],row[5]
        first=min(int(a*L),L-1);last=min(int(b*L),L-1)
        for h in range(first,last+1):exposure[f,x,h,q]+=max(0.,min(b,(h+1)/L)-max(a,h/L))
    for f in range(5):
        counts=np.zeros((2,3));denom=np.zeros((2,3));censors=np.zeros(2);time=np.zeros(2)
        for row in rows:
            if int(row[2])==f:continue
            x,q=int(row[1]),int(row[3]);d=row[5]-row[4];k=int(row[6]);time[x]+=d
            if k==3:censors[x]+=1
            if 0<=k<3:counts[x,k]+=1
            history=np.array([q%3,q//3,(q//3+q%3)/2]);gamma=np.array([.3,.35,.45])
            for j in range(3):denom[x,j]+=d*(np.exp(gamma[j]*history[j]) if correct else 1.)
        for x in range(2):
            g[f,x]=(censors[x]+.5)/(time[x]+1.) if correct else .35+.2*x
            for b in range(L):
                for q in range(9):
                    history=np.array([q%3,q//3,(q//3+q%3)/2]);gamma=np.array([.3,.35,.45])
                    for j in range(3):lam[f,x,b,q,j]=(counts[x,j]+.5)/(denom[x,j]+1.)*(np.exp(gamma[j]*history[j]) if correct else 1.)
    return lam,g,exposure

def estimate(rows,x,fold,correct,L=64):
    lam,g,expo=nuisance(rows,L,correct);initial=None;n=len(x);ok=False
    for iteration in range(61):
        psi,D,info,H,v,poly=evaluate(lam,g,rows,x,fold,expo)
        if initial is None:initial=psi.copy()
        score=D.mean(axis=0);error=max(abs(score))
        if error<1e-7/np.sqrt(n):ok=True;break
        if iteration==60:break
        step=np.linalg.pinv(info,rcond=1e-11)@score;delta=np.einsum('fxlqkj,j->fxlqk',H,step)
        scale=min(1.,.35/max(1e-12,max(abs(delta).ravel())))
        lam=lam*np.exp(scale*delta)
        if np.any(~np.isfinite(lam)) or lam.max()>1e4:break
    V=np.cov(D,rowvar=False,ddof=1)/n;se=np.sqrt(np.diag(V))
    return dict(estimate=psi,initial=initial,EIF=D,V=V,se=se,valid=ok and np.all(se>0),score=error,iterations=iteration,lam=lam,g=g,values=v,poly=poly)

def oracle():
    terminal=np.zeros((10,4));terminal[9,2]=1
    return (propagate(true_rates(0),terminal,1.)[0]+propagate(true_rates(1),terminal,1.)[0])/2

def batch(job):
    cell,n,correct,start,end=job;truth=oracle();out=[]
    for r in range(start,end):
        seed=1802611220+cell*100000+r;row=dict(cell=cell,n=n,correct_initial=correct,replicate=r,seed=seed,valid=False,joint_coverage=False)
        try:
            data,x,fold=simulate(n,seed);fit=estimate(data,x,fold,correct);se=fit['se'];corr=fit['V']/np.outer(se,se);ev,vec=np.linalg.eigh(corr);crit=np.quantile(np.max(abs(NORMAL@(vec*np.sqrt(np.maximum(ev,0))).T),axis=1),.95)
            row.update(valid=fit['valid'],joint_coverage=bool(fit['valid'] and np.all(abs(fit['estimate']-truth)<=crit*se)),score=fit['score'],iterations=fit['iterations'],max_rate=fit['lam'].max(),min_rate=fit['lam'].min(),critical=crit)
            for j in range(4):row.update({f'estimate_{j}':fit['estimate'][j],f'truth_{j}':truth[j],f'se_{j}':se[j],f'initial_{j}':fit['initial'][j],f'coverage_{j}':bool(fit['valid'] and abs(fit['estimate'][j]-truth[j])<=1.95996398454*se[j])})
        except Exception as e:row['error']=repr(e)
        out.append(row)
    return out

def checks():
    rows,x,fold=simulate(500,1702611220);t=time.time();fit=estimate(rows,x,fold,False,L=64);fine=estimate(rows,x,fold,False,L=128)
    maxerr=0.
    for f in [0,2,4]:
        for xx in [0,1]:
            for b in [0,15,39,63]:
                exact=propagate(fit['lam'][f,xx,b],fit['values'][f,xx,b+1],.63/64)
                for q in range(9):maxerr=max(maxerr,max(abs(exact[q]-value_at(fit['poly'],f,xx,q,(b+.37)/64))))
    check=dict(valid=fit['valid'],score=fit['score'],iterations=fit['iterations'],target_64_128_max_difference=float(max(abs(fit['estimate']-fine['estimate']))),interpolation_error=float(maxerr),seconds=time.time()-t,oracle=oracle().tolist(),scope='Continuous timestamps and right censoring; history-capped state with unbounded count rewards; no latent frailty in this validation DGP.')
    print(check,flush=True);(ROOT/'results/continuous_targeting_v3_checks.json').write_text(json.dumps(check,indent=2,default=lambda x:x.item()))
    pd.DataFrame(fit['EIF'],columns=TARGETS).to_csv(ROOT/'results/continuous_targeting_v3_EIF_demo.csv',index=False)
    assert fit['valid'] and maxerr<1e-6 and check['target_64_128_max_difference']<1e-5

def main(B,workers):
    out=ROOT/'results/continuous_targeting_v3_replicates.csv'
    if out.exists():raise FileExistsError(out)
    rows=[];start=time.time();jobs=[]
    for cell,(n,correct) in enumerate([(500,True),(1000,True),(500,False),(1000,False)]):
        jobs += [(cell,n,correct,a,min(a+10,B)) for a in range(0,B,10)]
    with ProcessPoolExecutor(workers) as pool:
        for f in as_completed([pool.submit(batch,j) for j in jobs]):
            rows.extend(f.result())
            if len(rows)%100==0:print('continuous targeting',len(rows),'/',4*B,round(time.time()-start,1),flush=True)
    d=pd.DataFrame(rows).sort_values(['cell','replicate']);d.to_csv(out,index=False);summary=[]
    for (cell,n,correct),g in d.groupby(['cell','n','correct_initial']):
        valid=g.valid.fillna(False);ok=g[valid];p=g.joint_coverage.fillna(False).mean()
        for j in range(4):
            cv=g[f'coverage_{j}'].fillna(False).mean();truth=g[f'truth_{j}'].iloc[0]
            summary.append(dict(cell=cell,n=n,correct_initial=correct,query=j,B=len(g),valid=int(valid.sum()),bias=ok[f'estimate_{j}'].mean()-truth,initial_bias=ok[f'initial_{j}'].mean()-truth,ESE=ok[f'estimate_{j}'].std(),ASE=ok[f'se_{j}'].mean(),coverage=cv,MCSE=np.sqrt(cv*(1-cv)/len(g)),joint_coverage=p,joint_MCSE=np.sqrt(p*(1-p)/len(g)),median_width=(2*ok.critical*ok[f'se_{j}']).median(),max_score=ok.score.max()))
    pd.DataFrame(summary).to_csv(ROOT/'results/continuous_targeting_v3_summary.csv',index=False)
    (ROOT/'results/continuous_targeting_v3_run.json').write_text(json.dumps(dict(B=B,cells=4,seconds=time.time()-start),indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--checks-only',action='store_true');p.add_argument('--B',type=int,default=5000);p.add_argument('--workers',type=int,default=4);a=p.parse_args();checks() if a.checks_only else main(a.B,a.workers)
