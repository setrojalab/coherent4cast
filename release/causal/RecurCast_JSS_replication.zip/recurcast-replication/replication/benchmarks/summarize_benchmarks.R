args<-commandArgs(trailingOnly=TRUE)
root<-if(length(args))normalizePath(args[1],winslash="/")else normalizePath(getwd(),winslash="/")
folder<-if(length(args)>=2L)args[2]else "benchmarks"
out<-file.path(root,"replication","results",folder)
memory_folder<-if(length(args)>=3L)args[3]else "benchmarks_memory_recheck"
paths<-file.path(out,paste0("timings_n",c(1000,10000,50000,250000),".csv"))
raw<-do.call(rbind,lapply(paths,read.csv))
keys<-unique(raw[c("n","component")])
summary<-do.call(rbind,lapply(seq_len(nrow(keys)),function(i){
  z<-raw[raw$n==keys$n[i]&raw$component==keys$component[i],]
  data.frame(n=keys$n[i],component=keys$component[i],repeats=nrow(z),median_seconds=median(z$elapsed_seconds),
    q25_seconds=unname(quantile(z$elapsed_seconds,.25)),q75_seconds=unname(quantile(z$elapsed_seconds,.75)),
    min_seconds=min(z$elapsed_seconds),max_seconds=max(z$elapsed_seconds),
    parameter_count=if(keys$component[i]=="highlevel_fit_fixed_phi")12L else if(keys$component[i]=="history_compilation")NA_integer_ else 4L,
    convergence_failures=if(all(is.na(z$convergence)))NA_integer_ else sum(z$convergence!=0),
    maximum_gradient=if(all(is.na(z$gradient)))NA_real_ else max(z$gradient))
}))
write.csv(summary,file.path(out,"benchmark_summary.csv"),row.names=FALSE)
slopes<-do.call(rbind,lapply(c("history_compilation","likelihood_and_score","core_likelihood_fit"),function(component){
  z<-summary[summary$component==component&summary$median_seconds>0,]
  if(nrow(z)<2L)return(data.frame(component=component,sizes_used=nrow(z),slope=NA_real_,r_squared=NA_real_,
    note="Insufficient timings above timer resolution to estimate a slope."))
  fit<-lm(log(median_seconds)~log(n),z)
  data.frame(component=component,sizes_used=nrow(z),slope=unname(coef(fit)[2]),r_squared=summary(fit)$r.squared,
    note="Empirical slope only; zero-resolution timings omitted. This is not a complexity proof.")
}))
write.csv(slopes,file.path(out,"runtime_slopes.csv"),row.names=FALSE)
memory<-read.csv(file.path(root,"replication","results",memory_folder,"memory.csv"))
stopifnot(all(memory$exit_code==0),nrow(memory)==4L)
write.csv(memory,file.path(out,"memory_corrected.csv"),row.names=FALSE)
qfile<-if(file.exists(file.path(out,"quadrature_stability_revision.csv")))"quadrature_stability_revision.csv"else "quadrature_stability.csv"
q<-read.csv(file.path(out,qfile))
qs<-aggregate(abs(q$difference_from_30),list(nodes=q$quadrature_nodes,target=q$target),max)
names(qs)[3]<-"maximum_absolute_difference_from_30"
write.csv(qs,file.path(out,"quadrature_summary.csv"),row.names=FALSE)

draw_runtime<-function(){
  cols<-c("#0072B2","#D55E00","#009E73");components<-c("history_compilation","core_likelihood_fit","likelihood_and_score")
  plot(NA,xlim=c(1000,250000),ylim=c(.005,max(summary$q75_seconds,na.rm=TRUE)*1.8),log="xy",
    xlab="Synthetic units (fixed workload pattern)",ylab="Elapsed seconds",xaxt="n",las=1)
  axis(1,at=c(1000,10000,50000,250000),labels=c("1,000","10,000","50,000","250,000"))
  for(k in seq_along(components)) {
    z<-summary[summary$component==components[k]&summary$median_seconds>0,]
    lines(z$n,z$median_seconds,type="b",pch=c(16,17,15)[k],lwd=1.5,col=cols[k])
    nonzero<-z$q75_seconds>pmax(.005,z$q25_seconds)
    if(any(nonzero))arrows(z$n[nonzero],pmax(.005,z$q25_seconds[nonzero]),z$n[nonzero],z$q75_seconds[nonzero],angle=90,code=3,length=.04,col=cols[k])
  }
  legend("topleft",c("History compilation","Core likelihood fit (4 parameters)","Likelihood and score"),col=cols,pch=c(16,17,15),lty=1,bty="n",cex=.9)
  mtext("Median and interquartile range of five runs; one worker; Windows / Ryzen 9 3900X",side=3,line=.4,cex=.78)
  mtext("Zero-resolution values omitted. Core timing excludes preprocessing.",side=1,line=5.5,cex=.7)
}
pdf(file.path(out,"runtime_scaling.pdf"),width=7.2,height=5.3,useDingbats=FALSE)
par(mar=c(7.5,6,2,1),mgp=c(4,1,0));draw_runtime();dev.off()
png(file.path(out,"runtime_scaling.png"),width=2160,height=1590,res=300)
par(mar=c(7.5,6,2,1),mgp=c(4,1,0));draw_runtime();dev.off()
draw_memory<-function(){
  plot(memory$n,memory$peak_working_set_bytes/1e9,type="b",pch=16,col="#0072B2",lwd=1.5,log="x",xaxt="n",
    ylim=c(0,max(1.6,memory$peak_working_set_bytes/1e9)),xlab="Synthetic units",ylab="Peak R-process working set (GB)",las=1)
  axis(1,at=memory$n,labels=c("1,000","10,000","50,000","250,000"))
  abline(h=1.5,lty=2,col="#D55E00")
  legend("topleft",c("Measured Windows process peak","Registered 1.5 GB target"),col=c("#0072B2","#D55E00"),pch=c(16,NA),lty=c(1,2),bty="n")
  mtext("Fresh process per size; includes data preparation and five repetitions",side=3,line=.4,cex=.8)
}
pdf(file.path(out,"memory_scaling.pdf"),width=7.2,height=4.8,useDingbats=FALSE);par(mar=c(5.5,6,2,1),mgp=c(4,1,0));draw_memory();dev.off()
png(file.path(out,"memory_scaling.png"),width=2160,height=1440,res=300);par(mar=c(5.5,6,2,1),mgp=c(4,1,0));draw_memory();dev.off()
print(summary);print(slopes);print(memory);print(qs)
