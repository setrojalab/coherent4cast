from pathlib import Path
import numpy as np,pandas as pd
root=Path(__file__).resolve().parents[1]
(root/'build').mkdir(exist_ok=True)
for cell in range(4):
 n=1000 if cell%2 else 250;sparse=cell>=2;rng=np.random.default_rng(2026112351+cell);x=rng.binomial(1,.5,n);fold=rng.permutation(n)%5+1;rows=[]
 for i in range(n):
  start=0.;count=np.zeros(2,dtype=int)
  for jump in range(1000):
   c1,c2=np.minimum(count,2);rate=np.array([.7,.025 if sparse else .25,.006 if sparse else .12])*np.exp(-.25*x[i]+np.array([.3*c2,.35*c1,.45*(c1+c2)/2]));censor=.35+.2*x[i];stop=start+rng.exponential(1/(rate.sum()+censor));event=-1
   if stop>=1:stop=1.
   else:event=rng.choice(4,p=np.r_[rate,censor]/(rate.sum()+censor))
   rows.append(dict(id=i+1,x=x[i],fold=fold[i],start=start,stop=stop,event_type=f'recurrent{event+1}' if event in [0,1] else 'none',terminal=int(event==2),censored=int(event==3)))
   if event<0 or event>=2:break
   count[event]+=1;start=stop
  else:raise RuntimeError('No trajectories silently truncated')
 pd.DataFrame(rows).to_csv(root/f'build/continuous_API_cell{cell}.csv',index=False)
print('Four representative cohorts generated for primary R API checks')
