RECURCAST 0.10.1: JSS COMPUTATIONAL SUPPLEMENT
Prepared 23 November 2026

START HERE

Unzip this directory. Install the separately supplied recurcast_0.10.1.tar.gz
using R CMD INSTALL or install.packages(..., repos=NULL, type="source"). A
C++17 toolchain is required for source installation. Windows users need the
Rtools version corresponding to their installed R version.

Required for the compact reconstruction: R, recurcast and jsonlite.
Additional fresh-case dependencies: survival, frailtypack and nlme.
HTML output uses knitr and rmarkdown; install these through CRAN if needed.
Python is optional and is used only for independent numerical references and
extended validation. The recorded validation environment is specified in
replication/requirements-validation.txt.

From this directory:

  Rscript --vanilla code.R

This reconstructs all 13 original generated table files and five figures, and freshly executes
the baseline-treatment causal example and its remainder check (Table 12). It
reruns the quickstart and sensitivity example and recomputes coverage from
the 20,000 recorded experiment rows. Other historical measured outputs are
read from the supplied snapshots, with their original version provenance.
This is reconstruction of recorded results, not a new run of every experiment.
The included code.html is a captured execution report, including sessionInfo().

To generate it again:

  Rscript --vanilla -e 'knitr::spin("code.R", knit=FALSE); rmarkdown::render("code.Rmd", output_file="code.html")'

FRESH FITS AND OPTIONAL EXPERIMENTS

  Rscript --vanilla code.R --fresh-cases

This refits the three synthetic datasets, the colorectal readmission cohort,
and all 929 colon-trial participants, including node4/nodes sensitivity and
separate training fits. It does not reuse fitted-object caches. Aggregate
outputs are placed in output/fresh_cases; fitted objects remain local in
output/fresh_case_fits and are excluded from the distributed supplement.
The fresh fit run performed during assembly reproduced all manuscript tables.
Wall-clock timings and PDF metadata can differ between computers.

  python run_native_tests.py

This compiles and runs seven standalone C++17 fixtures using GCC or Clang.
Put the compiler on PATH or set CXX to its executable.

For long experiments, make a working COPY of this directory first: some
original experiment interfaces overwrite reviews/ result snapshots.

  python full_experiments.py continuous --workers 2
  python full_experiments.py envelope
  python full_experiments.py frailty
  python full_experiments.py scaling

Continuous targeting uses 5,000 replications in each of four cells. The
separate envelope experiment uses 5,000 in each of three cells. These are
the original experiments, not additional runs claimed for this submission.
Fresh running times depend on the host. The longer experiments are not
required for the rapid code.R reconstruction. Windows process-memory
telemetry is in replication/benchmarks/run_benchmarks.ps1; memory and
runtime values cannot be expected to match a different machine exactly.

MANUSCRIPT MAP

Table 1: paper/replication_script.R (documented software comparison).
Table 2: rerun package quickstart, output/paper/generated/quickstart.csv.
Table 3: reporting contract in the manuscript; native field names are tested.
Table 4: numerical oracle records in reviews/, independent source in
         oracle_v5/code/, native_tests/ and replication/.
Table 5, Figure 3: replication/results/benchmarks_final/ and benchmarks/;
                  the benchmark source is replication/benchmarks/.
Table 6: validation/results/fibre_colon_parity.csv, reviews/P1/,
         reviews/root_validation/ and continuous oracle fixtures.
Table 7, Figure 4: reviews/P2_continuous_validation_replicates.csv;
                  summaries are recomputed and checked by code.R.
Tables 8, 9, 11, Figure 5: replication/run_case_studies.R;
                         default saved results or --fresh-cases refits.
Table 10: package/inst/benchmarks/frailty_future.R and
          validation/check_quadrature.R, validation/export_refinement.R.
Table 12: causal/run_causal.R and causal/results/causal_contrasts.csv.
          causal/causal_oracle.py independently computes the population
          g-formula with a dense matrix exponential (NumPy/SciPy).
          The supplied oracle CSV is used by code.R; Python is optional.
Figure 1: paper/revision_materials.R.
Figure 2: paper/replication_script.R, using rc_bounds().

Independent Python adapter checks first need locally exported clinical
inputs: run Rscript --vanilla prepare_reference_inputs.R, then
python replication/check_adapter_oracle.py. This export loads canonical
public data through installed R packages; no private file is required.

PROVENANCE AND INTERPRETATION

The original performance/case study outputs have predecessor provenance;
the 0.10.0 modules and 0.10.1 interface checks have separate records. The causal revision of 0.10.1 preserves the earlier prognostic kernels and
adds a separate treatment-weighted intensity-targeting kernel. Current check
records are in checks/causal_revision; earlier records retain their provenance.
Both arms are standardized over the same baseline population. The synthetic
example contains 1,600 subjects, two recurrent marks and an absorbing endpoint.
The separate remainder calculation uses 1,000,000 synthetic subjects across
four nuisance configurations; it is not a coverage simulation.

The original five case studies remain prognostic. The added causal API is
for a binary baseline treatment under consistency, conditional exchangeability,
treatment positivity and independent censoring. Its intervals are regular,
asymptotic intervals; incomplete observation and treatment confounding are
different identification problems. No time-varying treatment regime is fitted.
Synthetic results do not establish clinical benefit or regulatory certification.
Undefined metrics and failed regularity checks are retained.

The source code is GPL-3; see LICENSE.md. No private repository access is
required. Supplied check logs are historical execution evidence. The checks
directory is not a claim that CRAN or JSS has accepted the work.

OPTIONAL LIBRARY LOCATION

RECURCAST_LIBRARY selects an existing installed package library. Otherwise
the ordinary R library search path is used. No developer workstation path
is needed by the primary reconstruction or fresh-case entry points.
