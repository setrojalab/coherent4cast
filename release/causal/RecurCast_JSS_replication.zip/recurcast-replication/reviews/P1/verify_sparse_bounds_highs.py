"""Independent sparse Charnes--Cooper LP oracle for the C++ fixture cases.

Requires NumPy and SciPy. This script is verification-only; neither library is
an R package dependency. Run test_sparse.exe random_bounds.csv first.
"""
import csv
import json
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

HERE = Path(__file__).resolve().parent
rows = list(csv.DictReader((HERE / "random_bounds.csv").open()))
errors = []
for rep in sorted({int(x["rep"]) for x in rows}):
    block = [x for x in rows if int(x["rep"]) == rep]
    j = len(block)
    m = max(int(x["fibre"]) for x in block) + 1
    rho = float(block[0]["rho"])
    kappa = float(block[0]["kappa"])
    ratio = (1-rho)/rho
    numerator = np.array([float(x["num"]) for x in block])
    denominator = np.array([float(x["den"]) for x in block])
    ii, jj, vv, rhs = [], [], [], []
    def le(items, bound=0.):
        r = len(rhs)
        for k, v in items:
            ii.append(r); jj.append(k); vv.append(v)
        rhs.append(bound)
    for k in range(j):
        le([(j+k, 1), (k, -ratio*kappa)])
        le([(k, ratio/kappa), (j+k, -1)])
    for h in range(m):
        ids = [k for k,x in enumerate(block) if int(x["fibre"]) == h]
        lo = float(block[ids[0]]["lo"])
        hi = float(block[ids[0]]["hi"])
        le([(k, 1) for k in ids] + [(2*j, -hi)])
        le([(k, -1) for k in ids] + [(2*j, lo)])
    aub = coo_matrix((vv, (ii, jj)), shape=(len(rhs), 2*j+1)).tocsr()
    aeq = np.zeros((3, 2*j+1))
    aeq[0, :j] = 1; aeq[0, -1] = -rho
    aeq[1, j:2*j] = 1; aeq[1, -1] = -(1-rho)
    aeq[2, :j] = denominator; aeq[2, j:2*j] = denominator
    objective = np.r_[numerator, numerator, 0]
    values = []
    for sign in (1, -1):
        fit = linprog(sign*objective, A_ub=aub, b_ub=rhs, A_eq=aeq,
                      b_eq=[0, 0, 1], bounds=(0, None), method="highs",
                      options={"primal_feasibility_tolerance":1e-9,
                               "dual_feasibility_tolerance":1e-9})
        assert fit.success, (rep, fit.message)
        values.append(sign*fit.fun)
    error = max(abs(values[0]-float(block[0]["lower"])),
                abs(values[1]-float(block[0]["upper"])))
    errors.append(error)
    assert error < 1e-9, (rep, error)
result = {"independent_solver":"SciPy HiGHS sparse Charnes-Cooper LP",
          "cases":len(errors), "max_endpoint_difference":max(errors),
          "all_passed":True}
(HERE / "independent_highs_results.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))
