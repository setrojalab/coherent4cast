# Fresh R-source integration against the already installed native package.
# The coordinating package check separately verifies the installed artifact.
Sys.unsetenv("LC_ALL")
.libPaths(c("build/Rlib",file.path(old,"build/Rlib46"),file.path(old,"build/Rlib"),.libPaths()))
library(coherent4cast);library(testthat)
ns<-asNamespace("coherent4cast");e<-new.env(parent=.GlobalEnv)
for(n in ls(ns,all.names=TRUE))assign(n,get(n,envir=ns),envir=e)
for(f in c("coarsen_fibre.R","colon_fibre.R","covariate_evolution.R","forecast.R","predict_paths.R","predict_coarsened.R"))
  sys.source(file.path("package/R",f),envir=e)
registerS3method("predict","coherent4cast",e$predict.coherent4cast,envir=asNamespace("stats"))
tests<-testthat::test_file("package/tests/testthat/test-predict-coarsened.R",reporter="summary",env=e)
d<-as.data.frame(tests)
write.csv(d[,c("test","nb","failed","skipped","error","warning","passed")],"reviews/P4_prediction_source_tests.csv",row.names=FALSE)
stopifnot(!any(d$error),sum(d$failed)==0)
