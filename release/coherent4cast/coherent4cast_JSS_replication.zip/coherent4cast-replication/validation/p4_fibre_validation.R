source("validation/p4_fibre_check.R")
dir.create("validation/results",recursive=TRUE,showWarnings=FALSE)
time_old<-system.time(manual<-rc_colon(nodes=4))[["elapsed"]]
time_new<-system.time(automatic<-rc_colon_fibre(nodes=4))[["elapsed"]]
stopifnot(identical(manual$coarsening$owner,automatic$coarsening$owner))
parity<-data.frame(subjects=automatic$metadata$patients,paths=automatic$metadata$paths,
  same_day_pairs=length(automatic$metadata$same_day_ids),
  max_time_difference=max(abs(manual$data$start-automatic$data$start),abs(manual$data$stop-automatic$data$stop)),
  max_log_weight_difference=max(abs(manual$coarsening$log_weights-automatic$coarsening$log_weights)),
  manual_adapter_seconds=time_old,automatic_generator_seconds=time_new)
fitfile<-file.path(old,"build/case_fits/colon_node4.rds")
if(file.exists(fitfile)) {
  fit<-readRDS(fitfile)
  evaluate<-function(a) {
    d<-as_trajectory(a$data,event_types="1",time_unit="years",observation="coarsened")
    dd<-getFromNamespace(".rc_design","coherent4cast")(d,fit$formula,fit$breaks,fit$control$history_cap,
      fit$nonrecurrent,fit$design$terms,fit$design$xlevels,fit$design$contrasts)
    X<-dd$design[,fit$design$active,drop=FALSE]
    z<-rc_loglik(fit$coefficients,dd$unit,dd$exposure,X,dd$event,information=TRUE)
    rc_coarsen(z,owner=a$coarsening$owner,log_weights=a$coarsening$log_weights)
  }
  left<-evaluate(manual);right<-evaluate(automatic)
  parity$max_subject_loglik_difference<-max(abs(left$subject_loglik-right$subject_loglik))
  parity$max_subject_score_difference<-max(abs(left$scores-right$scores))
  parity$max_Louis_information_difference<-max(abs(left$information-right$information))
  stopifnot(parity$max_subject_loglik_difference<1e-10,parity$max_subject_score_difference<1e-10,
    parity$max_Louis_information_difference<1e-8)
}
write.csv(parity,"validation/results/fibre_colon_parity.csv",row.names=FALSE)
print(parity)

# Independent mathematical benchmark: six distinct event marks each in (0,1),
# no terminal event. Summing all 6! ordered simplexes gives total volume one.
# Repeated runs assess the actual sampler; they are not an estimator-coverage study.
q<-.rc_legendre_unit(4)
B<-200L;M<-2000L
est<-se<-numeric(B)
began<-proc.time()[["elapsed"]]
for(b in seq_len(B)) {
  v<-cpp_rc_coarsen_fibre(rep(0,6),rep(1,6),1:6,rep(FALSE,6),1,numeric(),q$x,q$w,
    max_perms=120L,draws=M,seed=10000+b,max_paths=100000L)
  est[b]<-v$volume;se[b]<-v$volume_mcse
}
experiment<-data.frame(replicate=seq_len(B),seed=10000+seq_len(B),volume_estimate=est,volume_mcse=se,truth=1)
write.csv(experiment,"validation/results/fibre_importance_raw.csv",row.names=FALSE)
report<-data.frame(replications=B,attempts_per_replication=M,true_volume=1,mean_estimate=mean(est),
  empirical_bias=mean(est)-1,mcse_of_mean=sd(est)/sqrt(B),empirical_sd=sd(est),
  mean_reported_integration_mcse=mean(se),maximum_absolute_error=max(abs(est-1)),
  elapsed_seconds=proc.time()[["elapsed"]]-began,
  scope="integration error only; not inferential coverage")
write.csv(report,"validation/results/fibre_importance_summary.csv",row.names=FALSE)
print(report)
capture.output(sessionInfo(),file="validation/results/fibre_session_info.txt")
