if(nzchar(Sys.getenv("COHERENT4CAST_LIBRARY"))) .libPaths(c(Sys.getenv("COHERENT4CAST_LIBRARY"),.libPaths()))
library(coherent4cast)
f<-readRDS("reviews/root_validation/readmission_frailty_fits.rds")$lognormal
write.csv(f$audit$quadrature_refinement,"reviews/root_validation/lognormal_fit_quadrature_audit.csv",row.names=FALSE)
print(f$audit$quadrature_refinement)
cat("Final nodes:",f$control$quadrature,"stable:",f$audit$quadrature_stable,"\n")
