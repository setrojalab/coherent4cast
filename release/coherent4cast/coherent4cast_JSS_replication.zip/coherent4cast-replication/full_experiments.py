"""Optional fresh experiments. Run inside a COPY of the replication directory.

Some original script interfaces write reviews/ snapshots; keep the delivered
archive unchanged. Long experiments are separate from the rapid code.R route.
"""
from pathlib import Path
import argparse, os, shutil, subprocess, sys
p=argparse.ArgumentParser()
p.add_argument('mode',choices=['continuous','envelope','frailty','scaling'])
p.add_argument('--workers',type=int,default=2)
args=p.parse_args()
if args.workers<1:raise SystemExit('workers must be positive.')
root=Path(__file__).resolve().parent
if os.environ.get('coherent4cast_LIBRARY'):
    os.environ['R_LIBS']=os.environ['coherent4cast_LIBRARY']+os.pathsep+os.environ.get('R_LIBS','')
r=shutil.which('Rscript')
if args.mode!='continuous' and not r:raise SystemExit('Put Rscript on PATH.')
(root/'build').mkdir(exist_ok=True)
if args.mode=='continuous':
    cxx=os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
    if not cxx:raise SystemExit('Put a C++17 compiler on PATH or set CXX.')
    exe=root/'build'/('continuous_validation.exe' if os.name=='nt' else 'continuous_validation')
    subprocess.run([cxx,'-std=c++17','-O3','-pthread','-Ipackage/inst/include',
        'replication/continuous_target_validation.cpp','-o',str(exe)],cwd=root,check=True)
    subprocess.run([str(exe),'reviews/P2_continuous_validation_replicates.csv',
        'replication/continuous_validation_truth.csv','5000',str(args.workers)],cwd=root,check=True)
    subprocess.run([sys.executable,'replication/summarize_continuous_validation.py'],cwd=root,check=True)
elif args.mode=='envelope':
    subprocess.run([r,'--vanilla','replication/check_observed_reward_envelope.R'],cwd=root,check=True)
elif args.mode=='frailty':
    env=os.environ.copy();env['coherent4cast_BENCHMARK_OUT']='reviews/root_validation'
    subprocess.run([r,'--vanilla','package/inst/benchmarks/frailty_future.R'],cwd=root,env=env,check=True)
    subprocess.run([r,'--vanilla','validation/check_quadrature.R'],cwd=root,env=env,check=True)
    subprocess.run([r,'--vanilla','validation/export_refinement.R'],cwd=root,env=env,check=True)
elif args.mode=='scaling':
    for n in [1000,10000,50000,250000]:
        subprocess.run([r,'--vanilla','replication/benchmarks/run_benchmarks.R',str(root),str(n),
            'output/benchmarks_fresh'],cwd=root,check=True)
    print('Fresh timings are in output/benchmarks_fresh. Peak memory uses the supplied Windows PowerShell driver.')
