# Optional local inputs for the independent Python adapter oracle.
# The canonical clinical records remain supplied by the public R packages.
requested_library <- Sys.getenv("COHERENT4CAST_LIBRARY", "")
if (nzchar(requested_library)) .libPaths(c(requested_library, .libPaths()))
library("coherent4cast")
env <- new.env()
data("colon", package = "survival", envir = env)
data("readmission", package = "frailtypack", envir = env)
dir.create("oracle_v5/data/raw", recursive = TRUE, showWarnings = FALSE)
dir.create("build", showWarnings = FALSE)
write.csv(env$colon, "oracle_v5/data/raw/colon_trial.csv", row.names = FALSE)
write.csv(env$readmission, "oracle_v5/data/raw/readmission_colorectal.csv", row.names = FALSE)
adapter <- rc_colon(nodes = 4L)
write.csv(adapter$data, "build/p4_colon_adapter.csv", row.names = FALSE)
write.csv(data.frame(owner = adapter$coarsening$owner,
                     log_weights = adapter$coarsening$log_weights),
          "build/p4_colon_weights.csv", row.names = FALSE)
cat("Reference inputs exported locally from the installed public source packages.\n")
