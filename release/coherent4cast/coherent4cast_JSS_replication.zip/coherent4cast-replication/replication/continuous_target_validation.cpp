#include <libcoherent4cast/continuous_target.hpp>
#include <array>
#include <atomic>
#include <chrono>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <numeric>
#include <random>
#include <sstream>
#include <string>
#include <thread>
using Vec=std::vector<double>;
struct Answer {int cell=0,n=0,rep=0,iterations=0;bool sparse=false,valid=false,transform_valid=false,joint_wald=false,joint_transform=false;double score=0;std::array<double,4> estimate{},se{},width_wald{},width_transform{};std::array<bool,4> point{};std::string error;};
inline double expit(double x){return x>=0?1/(1+std::exp(-x)):std::exp(x)/(1+std::exp(x));}
std::array<double,3> hazard(int state,int x,bool sparse){const double c1=state/3,c2=state%3;return {.7*std::exp(-.25*x+.3*c2),(sparse?.025:.25)*std::exp(-.25*x+.35*c1),(sparse?.006:.12)*std::exp(-.25*x+.45*(c1+c2)/2)};}
Answer run(int cell,int rep,const std::array<double,4>& truth){
 Answer out;out.cell=cell;out.rep=rep;out.n=(cell%2)?1000:250;out.sparse=cell>=2;const int n=out.n;constexpr std::size_t G=10,L=64,S=9,M=3,D=4;
 std::mt19937_64 rng(2026112300ULL+static_cast<unsigned long long>(cell)*100000ULL+static_cast<unsigned long long>(rep));std::uniform_real_distribution<double> unif(0,1);std::normal_distribution<double> normal;
 std::vector<int> x(static_cast<std::size_t>(n)),fold(static_cast<std::size_t>(n));std::vector<std::size_t> groups(static_cast<std::size_t>(n)),next(S*M);
 for(int i=0;i<n;++i){x[static_cast<std::size_t>(i)]=unif(rng)<.5?0:1;fold[static_cast<std::size_t>(i)]=i%5;}std::shuffle(fold.begin(),fold.end(),rng);
 for(std::size_t q=0;q<S;++q){next[q*M]=3*std::min(q/3+1,static_cast<std::size_t>(2))+q%3;next[q*M+1]=3*(q/3)+std::min(q%3+1,static_cast<std::size_t>(2));next[q*M+2]=S;}
 std::vector<coherent4cast::CTRecord> rows;std::array<double,10> time{},censor_count{};std::array<std::array<double,3>,10> counts{};
 for(int i=0;i<n;++i){const auto u=static_cast<std::size_t>(i);groups[u]=static_cast<std::size_t>(fold[u]*2+x[u]);double start=0;int state=0;
  for(int jump=0;jump<1000;++jump){auto rates=hazard(state,x[u],out.sparse);const double g=.35+.2*x[u],total=rates[0]+rates[1]+rates[2]+g;std::exponential_distribution<double> waiting(total);double stop=start+waiting(rng);int event=-1;
   if(stop>=1)stop=1;else{double z=unif(rng)*total;event=3;for(int k=0;k<3;++k){z-=rates[static_cast<std::size_t>(k)];if(z<=0){event=k;break;}}}
   rows.push_back({u,groups[u],static_cast<std::size_t>(state),start,stop,event});time[groups[u]]+=stop-start;if(event>=0&&event<3)counts[groups[u]][static_cast<std::size_t>(event)]+=1;if(event==3)censor_count[groups[u]]+=1;
   if(event<0||event>=2){break;}state=static_cast<int>(next[static_cast<std::size_t>(state)*M+static_cast<std::size_t>(event)]);start=stop;if(jump==999)throw std::runtime_error("simulation event budget");
  }
 }
 Vec initial(G*L*S*M),censor(G);
 for(std::size_t f=0;f<5;++f)for(std::size_t a=0;a<2;++a){const std::size_t g=f*2+a;double t=0,c=0;std::array<double,3> events{};
  for(std::size_t other=0;other<5;++other)if(other!=f){t+=time[other*2+a];c+=censor_count[other*2+a];for(std::size_t k=0;k<M;++k)events[k]+=counts[other*2+a][k];}
  censor[g]=(c+.5)/(t+1);for(std::size_t b=0;b<L;++b)for(std::size_t q=0;q<S;++q)for(std::size_t k=0;k<M;++k)initial[((g*L+b)*S+q)*M+k]=(events[k]+.5)/(t+1);
 }
 coherent4cast::ContinuousTarget model(G,L,S,M,1,next,groups,rows,censor);const auto z=model.fit(initial,60,1e-7/std::sqrt(static_cast<double>(n)));out.valid=z.converged;out.score=z.score;out.iterations=z.iterations;
 for(std::size_t j=0;j<D;++j){out.estimate[j]=z.estimate[j];out.se[j]=z.se[j];out.valid=out.valid&&std::isfinite(z.se[j])&&z.se[j]>0;out.point[j]=out.valid&&std::abs(z.estimate[j]-truth[j])<=1.959963984540054*z.se[j];}
 if(!out.valid){out.point.fill(false);return out;}
 std::array<double,16> chol{};for(std::size_t j=0;j<D;++j)for(std::size_t k=0;k<=j;++k){double value=z.covariance[j*D+k];for(std::size_t l=0;l<k;++l)value-=chol[j*D+l]*chol[k*D+l];if(j==k)chol[j*D+k]=std::sqrt(std::max(0.,value));else chol[j*D+k]=chol[k*D+k]>0?value/chol[k*D+k]:0;}
 Vec max_t(1000);for(double& draw:max_t){std::array<double,4> zz{};for(double& value:zz)value=normal(rng);draw=0;for(std::size_t j=0;j<D;++j){double value=0;for(std::size_t k=0;k<=j;++k)value+=chol[j*D+k]*zz[k];draw=std::max(draw,std::abs(value)/z.se[j]);}}
 std::sort(max_t.begin(),max_t.end());const double critical=max_t[949];out.joint_wald=true;out.joint_transform=true;out.transform_valid=true;
 for(std::size_t j=0;j<D;++j){const double mu=z.estimate[j],se=z.se[j];out.width_wald[j]=2*critical*se;out.joint_wald=out.joint_wald&&std::abs(mu-truth[j])<=critical*se;double lower=0,upper=0;
  if(j<2){if(mu<=0){out.transform_valid=false;continue;}const double logse=se/mu;lower=std::exp(std::log(mu)-critical*logse);upper=std::exp(std::log(mu)+critical*logse);}
  else{if(mu<=0||mu>=1){out.transform_valid=false;continue;}const double logse=se/(mu*(1-mu)),center=std::log(mu)-std::log1p(-mu);lower=expit(center-critical*logse);upper=expit(center+critical*logse);}
  out.width_transform[j]=upper-lower;out.joint_transform=out.joint_transform&&truth[j]>=lower&&truth[j]<=upper;
 }out.joint_transform=out.joint_transform&&out.transform_valid;return out;
}
int main(int argc,char** argv){
 if(argc<4){std::cerr<<"usage: ct_validation output.csv truth.csv B [workers]\n";return 2;}const int B=std::stoi(argv[3]),workers=argc>4?std::stoi(argv[4]):4;
 std::ifstream input(argv[2]);std::string line;std::getline(input,line);std::array<std::array<double,4>,2> truth{};
 for(std::size_t cell=0;cell<2;++cell){std::getline(input,line);std::stringstream stream(line);std::string value;std::getline(stream,value,',');for(double& z:truth[cell]){std::getline(stream,value,',');z=std::stod(value);}}
 std::vector<Answer> answers(static_cast<std::size_t>(4*B));std::atomic<int> index(0),completed(0);std::mutex output_mutex;std::vector<std::thread> threads;const auto start=std::chrono::steady_clock::now();
 for(int w=0;w<workers;++w)threads.emplace_back([&](){while(true){const int pos=index.fetch_add(1);if(pos>=4*B)break;const int cell=pos/B,rep=pos%B;try{answers[static_cast<std::size_t>(pos)]=run(cell,rep,truth[cell>=2?1:0]);}catch(const std::exception& e){auto& a=answers[static_cast<std::size_t>(pos)];a.cell=cell;a.rep=rep;a.n=cell%2?1000:250;a.sparse=cell>=2;a.error=e.what();}const int done=completed.fetch_add(1)+1;if(done%500==0){std::lock_guard<std::mutex> guard(output_mutex);std::cout<<done<<"/"<<4*B<<" cohorts; "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<" seconds\n"<<std::flush;}}});
 for(auto& worker:threads){worker.join();}std::ofstream out(argv[1]);out<<std::setprecision(17)<<"cell,n,sparse,replicate,valid,transform_valid,score,iterations,joint_wald,joint_transform";for(int j=0;j<4;++j)out<<",estimate_"<<j<<",se_"<<j<<",point_coverage_"<<j<<",width_wald_"<<j<<",width_transform_"<<j;out<<",error\n";
 for(const auto& a:answers){out<<a.cell<<","<<a.n<<","<<a.sparse<<","<<a.rep<<","<<a.valid<<","<<a.transform_valid<<","<<a.score<<","<<a.iterations<<","<<a.joint_wald<<","<<a.joint_transform;for(std::size_t j=0;j<4;++j)out<<","<<a.estimate[j]<<","<<a.se[j]<<","<<a.point[j]<<","<<a.width_wald[j]<<","<<a.width_transform[j];out<<",\""<<a.error<<"\"\n";}
 std::cout<<"Completed "<<4*B<<" cohorts in "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<" seconds\n";return 0;
}
