script<-sub("^--file=","",grep("^--file=",commandArgs(FALSE),value=TRUE)[1])
base<-normalizePath(file.path(dirname(script),".."),winslash="/")
local_library<-Sys.getenv("COHERENT4CAST_LIBRARY","")
if(nzchar(local_library)).libPaths(c(local_library,.libPaths()))
library(coherent4cast);Sys.unsetenv('LC_ALL')
e<-new.env(parent=asNamespace('coherent4cast'));sys.source(file.path(base,'package/R/targeting_continuous.R'),e)
project<-e$.rc_target_projection
set.seed(2026112401);B<-5000L;n<-100L;tau<-1;truth<-c(1-exp(-.2),(1-exp(-.2))/.2)
rows<-vector('list',3*B);index<-0L
for(cell in c('complete','independent_censoring','informative_censoring'))for(rep in seq_len(B)) {
 T<-rexp(n,.2);C<-if(cell=='complete')rep(Inf,n) else rexp(n,.5)
 if(cell=='informative_censoring')C[T<.3]<-pmin(C[T<.3],T[T<.3]/2)
 stop<-pmin(T,C,tau);death<-as.numeric(T<=C&T<=tau);censored<-C<T&C<tau
 lo<-cbind(rep(0,n),rep(0,n),death,stop);hi<-lo;hi[,3]<-death+as.numeric(censored);hi[,4]<-ifelse(censored,tau,stop)
 object<-list(target_limits=rbind(c(0,0,0,0),c(Inf,Inf,1,1)),observation_bounds=list(lower=lo,upper=hi))
 ans<-project(object,.95)
 stopifnot(all(lo[,3]<=as.numeric(T<=tau)),all(as.numeric(T<=tau)<=hi[,3]),all(lo[,4]<=pmin(T,tau)),all(pmin(T,tau)<=hi[,4]),ans$lower[1]==0,is.infinite(ans$upper[1]))
 index<-index+1L;rows[[index]]<-data.frame(cell=cell,replicate=rep,covered=all(ans$lower[3:4]<=truth&ans$upper[3:4]>=truth),risk_width=ans$upper[3]-ans$lower[3],rmst_width=ans$upper[4]-ans$lower[4])
}
d<-do.call(rbind,rows);write.csv(d,file.path(base,'reviews/P2_envelope_replicates.csv'),row.names=FALSE)
s<-do.call(rbind,lapply(split(d,d$cell),function(g){p<-mean(g$covered);k<-sum(g$covered);data.frame(cell=g$cell[1],B=nrow(g),coverage=p,MCSE=sqrt(p*(1-p)/nrow(g)),coverage_MC_lower=if(k==0)0 else qbeta(.025,k,nrow(g)-k+1),risk_width_median=median(g$risk_width),rmst_width_median=median(g$rmst_width))}))
write.csv(s,file.path(base,'reviews/P2_envelope_summary.csv'),row.names=FALSE);print(s,row.names=FALSE)
stopifnot(all(s$coverage>=.94))
