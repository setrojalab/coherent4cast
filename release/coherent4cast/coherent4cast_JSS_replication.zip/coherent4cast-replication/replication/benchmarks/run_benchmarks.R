args <- commandArgs(trailingOnly=TRUE)
if(length(args)<2L) stop("Usage: Rscript run_benchmarks.R PROJECT_ROOT N [OUTDIR]")
root <- normalizePath(args[1],winslash="/",mustWork=TRUE)
n <- as.integer(args[2])
out <- if(length(args)>=3L) args[3] else file.path(root,"replication","results","benchmarks")
dir.create(out,recursive=TRUE,showWarnings=FALSE)
.libPaths(c(Sys.getenv("RC_BENCHMARK_LIBRARY",file.path(root,"build","Rlib")),file.path(root,"build","Rlib"),.libPaths()))
suppressPackageStartupMessages(library(coherent4cast))
Sys.unsetenv("LC_ALL")
Sys.setenv(OMP_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",MKL_NUM_THREADS="1")
if(!n %in% c(1000L,10000L,50000L,250000L)) stop("Unregistered sample size")

# Replication is a workload construction. It does not create independent evidence.
base <- rc_simulate(40,seed=20261122L,time_unit="years")
units <- split(seq_len(nrow(base)),base$id)
which_unit <- rep(seq_along(units),length.out=n)
index <- unlist(unname(units[which_unit]),use.names=FALSE)
d <- base[index,,drop=FALSE]
d$id <- rep(seq_len(n),lengths(units)[which_unit])
rownames(d)<-NULL
trajectory <- as_trajectory(d,event_types=c("1","2"),time_unit="years")
rows <- nrow(d)
design <- matrix(0,rows*3L,3L)
for(k in 1:3) design[(k-1L)*rows+seq_len(rows),k] <- 1
unit <- rep(as.integer(d$id),3L)
exposure <- rep(d$stop-d$start,3L)
event <- c(as.numeric(d$event_type==1),as.numeric(d$event_type==2),as.numeric(d$terminal))
theta <- log(c(.6,.25,.12,.45))
evaluate <- function(x,information=FALSE) rc_loglik(x,unit,exposure,design,event,information=information)
times <- data.frame()
record <- function(component,repeat_id,elapsed,convergence=NA_integer_,gradient=NA_real_,objective=NA_real_,valid=NA,parameters=length(theta)) {
  times <<- rbind(times,data.frame(n=n,interval_rows=rows,expanded_rows=length(unit),parameters=parameters,component=component,
    repeat_id=repeat_id,elapsed_seconds=elapsed,convergence=convergence,gradient=gradient,objective=objective,valid=valid))
  write.csv(times,file.path(out,paste0("timings_n",n,".csv")),row.names=FALSE)
}
# One untimed warm-up verifies the compiled kernel before repeated measurements.
initial <- evaluate(theta)
stopifnot(all(is.finite(initial$gradient)),length(initial$subject_loglik)==n)
cat("n=",n," rows=",rows," expanded=",length(unit),"\n",sep="")
flush.console()
for(b in 1:5) {
  gc()
  t <- proc.time()[["elapsed"]]
  h <- build_history(trajectory,cap=2L)
  elapsed <- proc.time()[["elapsed"]]-t
  stopifnot(identical(dim(h$counts),c(nrow(d),2L)))
  record("history_compilation",b,elapsed)
  rm(h)
  gc()
  t <- proc.time()[["elapsed"]]
  z <- evaluate(theta)
  elapsed <- proc.time()[["elapsed"]]-t
  record("likelihood_and_score",b,elapsed,gradient=max(abs(z$gradient)),objective=z$objective)
  gc()
  # Cache a shared function/gradient evaluation; both routes use the same cache.
  last_x <- NULL;last_z <- NULL
  value <- function(x) {
    if(is.null(last_x)||!identical(x,last_x)){last_x<<-x;last_z<<-evaluate(x)}
    last_z
  }
  t <- proc.time()[["elapsed"]]
  fitted <- optim(theta,function(x)value(x)$objective,function(x)value(x)$gradient,
    method="L-BFGS-B",lower=c(rep(-12,3),-5),upper=c(rep(8,3),2.5),
    control=list(maxit=100L,factr=1e7,pgtol=1e-8))
  final <- evaluate(fitted$par,TRUE)
  elapsed <- proc.time()[["elapsed"]]-t
  record("core_likelihood_fit",b,elapsed,fitted$convergence,max(abs(final$gradient)),final$objective)
  cat("repeat=",b," fit_seconds=",elapsed," convergence=",fitted$convergence,"\n",sep="")
  flush.console()
}
saveRDS(list(theta=fitted$par,objective=final$objective,gradient=final$gradient,
  n=n,rows=rows,counts=colSums(matrix(event,nrow=rows)),session=utils::sessionInfo()),
  file.path(out,paste0("fit_n",n,".rds")))
writeLines(c(capture.output(sessionInfo()),paste("workers",1),
  paste("workload","replicated forty-unit synthetic timing fixture; not new statistical evidence")),
  file.path(out,paste0("session_n",n,".txt")))
if(n==1000L) {
  # Independent R arithmetic uses the gamma integral directly, not C++ recurrences.
  reference <- function(x) {
    eta<-as.vector(design %*% x[1:3]);v<-exposure*exp(eta);a<-exp(-x[4])
    A<-as.numeric(rowsum(v,unit,reorder=FALSE));cnt<-as.numeric(rowsum(event,unit,reorder=FALSE))
    evt<-as.numeric(rowsum(event*eta,unit,reorder=FALSE))
    A1<-rowsum(design*v,unit,reorder=FALSE);ev1<-rowsum(design*event,unit,reorder=FALSE)
    ll<-evt+lgamma(a+cnt)-lgamma(a)+a*log(a)-(a+cnt)*log(a+A)
    s_beta<-ev1-A1*((a+cnt)/(a+A))
    s_phi<- -a*(digamma(a+cnt)-digamma(a)+log(a)+1-log(a+A)-(a+cnt)/(a+A))
    list(objective=-mean(ll),gradient=-colMeans(cbind(s_beta,s_phi)),subject_loglik=ll,scores=cbind(s_beta,s_phi))
  }
  r<-reference(theta);z<-evaluate(theta)
  comparison<-data.frame(check=c("subject_loglik","subject_score"),
    maximum_absolute_error=c(max(abs(r$subject_loglik-z$subject_loglik)),max(abs(r$scores-z$scores))))
  reference_times<-numeric(5)
  for(b in 1:5){t<-proc.time()[["elapsed"]];reference(theta);reference_times[b]<-proc.time()[["elapsed"]]-t}
  rt<-optim(theta,function(x)reference(x)$objective,function(x)reference(x)$gradient,
    method="L-BFGS-B",lower=c(rep(-12,3),-5),upper=c(rep(8,3),2.5),control=list(maxit=100L,factr=1e7,pgtol=1e-8))
  comparison<-rbind(comparison,data.frame(check="optimizer_parameters",maximum_absolute_error=max(abs(rt$par-fitted$par))))
  write.csv(comparison,file.path(out,"reference_parity.csv"),row.names=FALSE)
  write.csv(data.frame(repeat_id=1:5,elapsed_seconds=reference_times),file.path(out,"reference_r_timing.csv"),row.names=FALSE)
  for(b in 1:5) {
    gc();t<-proc.time()[["elapsed"]]
    hf<-suppressWarnings(coherent4cast(~x,d,event_types=c("1","2"),time_unit="years",
      control=coherent4cast_control(phi_fixed=.45,maxit=150L)))
    record("highlevel_fit_fixed_phi",b,proc.time()[["elapsed"]]-t,hf$convergence$optimizer,hf$convergence$gradient,-hf$loglik/n,hf$convergence$valid,length(coef(hf)))
  }
  newdata<-d[d$id %in% 1:4,,drop=FALSE]
  forecasts<-lapply(c(5,15,30),function(q)predict(hf,newdata,landmark=0,horizon=c(.5,1,2),type="all",quadrature=q))
  stability<-do.call(rbind,lapply(seq_along(forecasts),function(k){
    z<-forecasts[[k]];z$quadrature_nodes<-c(5,15,30)[k]
    z$difference_from_30<-z$estimate-forecasts[[3]]$estimate
    z
  }))
  write.csv(stability,file.path(out,"quadrature_stability.csv"),row.names=FALSE)
  saveRDS(hf,file.path(out,"highlevel_fit.rds"))
}
cat("DONE n=",n,"\n",sep="")
