param([string]$ProjectRoot=(Split-Path -Parent (Split-Path -Parent $PSScriptRoot)),[string]$OutputSubdirectory='benchmarks',[string]$LibrarySubdirectory='build\Rlib')
$ErrorActionPreference='Stop'
$ResultRoot=Join-Path $ProjectRoot ('replication\results\'+$OutputSubdirectory)
New-Item -ItemType Directory -Force -Path $ResultRoot | Out-Null
$env:LANG='en'; $env:LC_ALL='C'; $env:OMP_NUM_THREADS='1'; $env:OPENBLAS_NUM_THREADS='1'; $env:MKL_NUM_THREADS='1'
$env:RC_BENCHMARK_LIBRARY=Join-Path $ProjectRoot $LibrarySubdirectory
$Rscript=(Get-Command Rscript -ErrorAction Stop).Source
$ScriptPath=Join-Path $PSScriptRoot 'run_benchmarks.R'
$HashInputs=@((Join-Path $ProjectRoot 'planning\software_benchmark_prespec.json'),(Join-Path $ProjectRoot 'planning\benchmark_implementation_v1.json'),$ScriptPath,$PSCommandPath)
$HashInputs += (Get-ChildItem -LiteralPath (Join-Path $ProjectRoot 'package\R') -Filter '*.R').FullName
$HashInputs += (Get-ChildItem -LiteralPath (Join-Path $ProjectRoot 'package\inst\include\libcoherent4cast') -Filter '*.hpp').FullName
$InstalledPackage=Join-Path $env:RC_BENCHMARK_LIBRARY 'coherent4cast'
$HashInputs += (Get-ChildItem -LiteralPath $InstalledPackage -Recurse -File | Where-Object {$_.Extension -in @('.dll','.rdb','.rdx') -or $_.Name -eq 'DESCRIPTION'}).FullName
$HashInputs | ForEach-Object {Get-FileHash -LiteralPath $_ -Algorithm SHA256} | Select-Object Path,Hash | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $ResultRoot 'prerun_source_hashes.json') -Encoding utf8
$Cpu=Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors
$OperatingSystem=Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,TotalVisibleMemorySize
@{cpu=$Cpu;os=$OperatingSystem;threads=1;library=$env:RC_BENCHMARK_LIBRARY;timer='R proc.time elapsed';memory='Windows PeakWorkingSet64, complete fresh process including preparation'} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $ResultRoot 'host.json') -Encoding utf8
$Memory=@()
foreach($Size in @(1000,10000,50000,250000)) {
  $Stdout=Join-Path $ResultRoot "console_n$Size.txt"
  $Stderr=Join-Path $ResultRoot "stderr_n$Size.txt"
  $Arguments=@('--vanilla',('"'+$ScriptPath+'"'),('"'+$ProjectRoot+'"'),$Size,('"'+$ResultRoot+'"'))
  $Process=Start-Process -FilePath $Rscript -ArgumentList $Arguments -PassThru -WindowStyle Hidden -RedirectStandardOutput $Stdout -RedirectStandardError $Stderr
  $Peak=0L
  while(-not $Process.HasExited) {
    $Process.Refresh()
    if($Process.PeakWorkingSet64 -gt $Peak){$Peak=$Process.PeakWorkingSet64}
    Start-Sleep -Milliseconds 500
  }
  $Process.WaitForExit();$ExitCode=$Process.ExitCode
  $Memory += [pscustomobject]@{n=$Size;peak_working_set_bytes=$Peak;exit_code=$ExitCode;measurement='Windows PeakWorkingSet64'}
  $Memory | Export-Csv -LiteralPath (Join-Path $ResultRoot 'memory.csv') -NoTypeInformation
  Get-Content -LiteralPath $Stdout
  if($ExitCode -ne 0){Get-Content -LiteralPath $Stderr;throw "Benchmark failed at n=$Size"}
}
