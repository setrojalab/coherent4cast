args<-commandArgs(trailingOnly=TRUE)
root<-if(length(args))normalizePath(args[1],winslash="/")else normalizePath(getwd(),winslash="/")
.libPaths(c(file.path(root,"build","Rlib"),.libPaths()))
out<-file.path(root,"replication","results","benchmarks")
dir.create(out,recursive=TRUE,showWarnings=FALSE)
Sys.unsetenv("LC_ALL")
warnings<-character()
capture<-function(expr)withCallingHandlers(expr,warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart("muffleWarning")})
suppressPackageStartupMessages(capture(library(frailtypack)))
data("readmission",package="frailtypack",envir=environment())
fit<-capture(frailtyPenal(Surv(t.start,t.stop,event)~cluster(id)+chemo+terminal(death),
  formula.terminalEvent=~chemo,data=readmission,recurrentAG=TRUE,hazard="Weibull",
  Alpha="None",maxit=150L,print.times=FALSE))
cat("frailtypack version:",as.character(packageVersion("frailtypack")),"\n")
print(fit)
data("colon",package="survival",envir=environment())
death<-colon[colon$etype==2,,drop=FALSE]
cox<-survival::coxph(survival::Surv(time,status)~rx+age+node4,data=death,x=TRUE)
cat("survival version:",as.character(packageVersion("survival")),"\n")
print(summary(cox))
metrics<-data.frame(package=c("frailtypack","survival"),version=c(as.character(packageVersion("frailtypack")),as.character(packageVersion("survival"))),
  example=c("readmission: joint Weibull gamma recurrence/death fit","colon: terminal-only proportional hazards fit"),
  subjects=c(length(unique(readmission$id)),cox$n),
  recurrent_events=c(sum(readmission$event),NA),terminal_events=c(sum(readmission$death[!duplicated(readmission$id,fromLast=TRUE)]),cox$nevent),
  loglik=c(as.numeric(fit$logLik),tail(cox$loglik,1)),
  status=c(if(identical(as.integer(fit$istop),1L))"converged"else paste("istop",fit$istop),"completed"),
  equivalence=c("Not equivalent to capped-history piecewise-constant coherent4cast benchmark","Not equivalent: terminal-only partial likelihood"))
write.csv(metrics,file.path(out,"companion_examples.csv"),row.names=FALSE)
write.csv(data.frame(package="survival",term=names(coef(cox)),estimate=unname(coef(cox))),file.path(out,"companion_cox_coefficients.csv"),row.names=FALSE)
writeLines(unique(warnings),file.path(out,"companion_warnings.txt"))
writeLines(capture.output(sessionInfo()),file.path(out,"companion_session.txt"))
