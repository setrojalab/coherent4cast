args<-commandArgs(trailingOnly=TRUE)
root<-if(length(args))normalizePath(args[1],winslash="/")else normalizePath(getwd(),winslash="/")
.libPaths(c(file.path(root,"build","final_library"),file.path(root,"build","Rlib"),.libPaths()))
library(coherent4cast);Sys.unsetenv("LC_ALL")
out<-file.path(root,"replication","results","benchmarks_final")
base<-rc_simulate(40,seed=20261122L,time_unit="years")
units<-split(seq_len(nrow(base)),base$id)
tab<-data.frame()
for(n in c(1000L,10000L,50000L,250000L)) {
  w<-rep(seq_along(units),length.out=n)
  d<-base[unlist(unname(units[w]),use.names=FALSE),,drop=FALSE]
  d$id<-rep(seq_len(n),lengths(units)[w]);rownames(d)<-NULL
  trajectory<-as_trajectory(d,event_types=c("1","2"),time_unit="years")
  for(b in 1:5) {
    gc();t<-proc.time()[["elapsed"]]
    for(j in 1:100)z<-build_history(trajectory,cap=2L)
    elapsed<-proc.time()[["elapsed"]]-t
    stopifnot(nrow(z$counts)==nrow(d))
    tab<-rbind(tab,data.frame(n=n,batch=b,calls=100,batch_elapsed_seconds=elapsed,per_call_seconds=elapsed/100))
    write.csv(tab,file.path(out,"history_resolution.csv"),row.names=FALSE)
  }
}
s<-do.call(rbind,lapply(split(tab,tab$n),function(z)data.frame(n=z$n[1],median=median(z$per_call_seconds),
  q25=unname(quantile(z$per_call_seconds,.25)),q75=unname(quantile(z$per_call_seconds,.75)))))
write.csv(s,file.path(out,"history_resolution_summary.csv"),row.names=FALSE)
fit<-lm(log(median)~log(n),s)
write.csv(data.frame(slope=unname(coef(fit)[2]),r_squared=summary(fit)$r.squared,
  scope="Five 100-call batches per size; empirical throughput slope, not an algorithmic proof"),file.path(out,"history_resolution_slope.csv"),row.names=FALSE)
print(s)
