# Computational benchmark replication

The measured publication tables use `../results/benchmarks_final/`. Earlier results remain in `benchmarks/` and `benchmarks_memory_recheck/`; these record the initial R history implementation and the correction of a launcher-process memory measurement. They must not be silently merged with the final implementation.

From the project root on the measured Windows system:

```powershell
./replication/benchmarks/run_benchmarks.ps1 `
  -OutputSubdirectory benchmarks_reproduction `
  -LibrarySubdirectory build/final_library
```

The Windows wrapper uses the actual x64 R process to collect peak working set, one worker, and independent processes for each sample size. It hashes the protocols, source files and installed compiled package before measuring. The path to R in the wrapper is specific to the recorded host; update it when reproducing elsewhere and report that environment.

The R workload is portable. After installing the package, supply its library through `RC_BENCHMARK_LIBRARY`, then run one command per registered sample size:

```sh
Rscript --vanilla replication/benchmarks/run_benchmarks.R PROJECT_ROOT 1000 OUTPUT_DIRECTORY
Rscript --vanilla replication/benchmarks/run_benchmarks.R PROJECT_ROOT 10000 OUTPUT_DIRECTORY
Rscript --vanilla replication/benchmarks/run_benchmarks.R PROJECT_ROOT 50000 OUTPUT_DIRECTORY
Rscript --vanilla replication/benchmarks/run_benchmarks.R PROJECT_ROOT 250000 OUTPUT_DIRECTORY
```

`PROJECT_ROOT` and `OUTPUT_DIRECTORY` denote actual absolute paths. Each command carries out five repeats. Only the Windows wrapper supplies the executed memory metric; Linux or macOS memory measurements need their own explicit instrument and are not present in this report.

Generate the summary table and the standalone runtime and memory plots with:

```sh
Rscript --vanilla replication/benchmarks/summarize_benchmarks.R PROJECT_ROOT benchmarks_final benchmarks_final
```

The first folder argument selects timing results; the second selects the memory measurement folder. Use `benchmarks_reproduction` for both when summarizing a new Windows run.

`companion_examples.R` executes separate `frailtypack` and `survival` examples. They are functionality examples, not matched speed or accuracy comparisons. `highlevel_revision.R` records the intermediate optimizer correction; it is historical audit evidence, not a required replication step for the final package.

The timing workload deliberately repeats forty synthetic histories with new identifiers to hold its pattern fixed while changing size. It does not produce independent Monte Carlo samples, patient outcomes or a new coverage claim. The core model has four parameters; the separate high-level model has twelve. The outputs retain both dimensions and convergence diagnostics. No high-level 250,000-unit fitting time is implied by the core-kernel timing.
