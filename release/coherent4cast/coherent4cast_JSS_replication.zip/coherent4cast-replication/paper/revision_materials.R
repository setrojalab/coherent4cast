# Rebuild only revision tables/diagrams from saved, independently checked results.
# Run from the revision root. This script does not refit or overwrite predecessor experiments.
paper_output <- Sys.getenv("COHERENT4CAST_PAPER_OUTPUT", "paper")
generated_dir <- file.path(paper_output, "generated"); figure_dir <- file.path(paper_output, "figures")
dir.create(generated_dir,recursive=TRUE,showWarnings=FALSE)
dir.create(figure_dir,recursive=TRUE,showWarnings=FALSE)
if(!requireNamespace("jsonlite",quietly=TRUE))stop("Install jsonlite to read recorded verification results.")
js <- function(path)jsonlite::fromJSON(path)
dec <- function(x,k=3)formatC(x,format="f",digits=k)
e <- function(x){v<-strsplit(formatC(x,format="e",digits=2),"e",fixed=TRUE)[[1]];paste0("$",v[1],"\\times10^{",as.integer(v[2]),"}$")}
fibre <- read.csv("validation/results/fibre_colon_parity.csv")
sp <- js("reviews/P1/sparse_core_results.json")
hi <- js("reviews/P1/independent_highs_results.json")
ct <- read.csv("reviews/P2_continuous_oracle_parity.csv")
rows <- list(
 c("Automatic fibres",paste(fibre$subjects,"colon subjects; log likelihood vs specialized adapter"),e(fibre$max_subject_loglik_difference)),
 c("Louis information","Generated paths vs specialized adapter",e(fibre$max_Louis_information_difference)),
 c("Sparse bounds",paste(hi$cases,"independent HiGHS problems; maximum endpoint difference"),e(hi$max_endpoint_difference)),
 c("Large-support bounds","50,000 atoms; fractional certificate gap",e(sp$bounds_gap)),
 c("CSR propagation","50,000 states; probability series bound",e(sp$csr_probability_error_bound)),
 c("Continuous targeting","Individual EIF vs unchanged V5 oracle",e(ct$error[ct$metric=="EIF"]))
)
oracle_path <- "reviews/root_validation/ordered_covariate_oracle.csv"
if(file.exists(oracle_path)) {
 co<-read.csv(oracle_path); ln<-read.csv("reviews/root_validation/lognormal_quadrature.csv")
 rows[[length(rows)+1L]]<-c("Future schedule","Ordered forecast vs analytic oracle",e(co$absolute_error))
 rows[[length(rows)+1L]]<-c("Lognormal frailty","40-node log likelihood vs adaptive integration",e(ln$absolute_error[ln$nodes==40]))
}
extra <- "validation/results/root_revision_checks.csv"
if(file.exists(extra)) {
 z<-read.csv(extra,stringsAsFactors=FALSE)
 if(all(c("module","check","result")%in%names(z))) for(i in seq_len(nrow(z)))rows[[length(rows)+1L]]<-unname(unlist(z[i,c("module","check","result")]))
}
writeLines(c("\\begin{table}[tbp]\\centering\\small",
 "\\begin{tabular}{>{\\raggedright\\arraybackslash}p{.23\\textwidth}>{\\raggedright\\arraybackslash}p{.48\\textwidth}>{\\raggedright\\arraybackslash}p{.20\\textwidth}}\\toprule",
 "Module & Recorded comparison or diagnostic & Result \\\\ \\midrule",
 vapply(rows,function(r)paste0(paste(r,collapse=" & ")," \\\\"),character(1)),
 "\\bottomrule\\end{tabular}",
 "\\caption{New 0.10.0 verification. Differences measure numerical agreement; series bounds concern real-arithmetic truncation. They are distinct from empirical confidence coverage.}\\label{tab:revision}",
 "\\end{table}"),file.path(generated_dir,"revision_verification.tex"))
write.csv(do.call(rbind,rows),file.path(generated_dir,"revision_verification.csv"),row.names=FALSE)

families_path <- "reviews/root_validation/readmission_frailty_families.csv"
if(file.exists(families_path)) {
 ff<-read.csv(families_path)
 lines<-vapply(seq_len(nrow(ff)),function(i)paste0(paste(c(ff$family[i],dec(ff$logLik[i],2),dec(ff$AIC[i],2),dec(ff$variance[i]),if(ff$converged[i])"yes" else "no"),collapse=" & ")," \\\\"),character(1))
 writeLines(c("\\begin{table}[tbp]\\centering\\small","\\begin{tabular}{lrrrl}\\toprule","Frailty & Log likelihood & AIC & Variance & Regular fit \\\\ \\midrule",lines,"\\bottomrule\\end{tabular}",
 "\\caption{Revision readmission sensitivity analysis on 403 subjects under a common design and observation scheme. The discrete model has two estimated mass points. AIC compares the fitted working distributions descriptively; no nonnested chi-square test is used.}\\label{tab:frailty}","\\end{table}"),file.path(generated_dir,"frailty_comparison.tex"))
}

validation <- "reviews/P2_continuous_validation_summary.csv"
if(!file.exists(validation)) {
 writeLines("The separately registered continuous-targeting simulation is being completed; numerical oracle agreement alone is not reported as empirical confidence coverage.",file.path(generated_dir,"continuous_validation_text.tex"))
} else {
 vv<-read.csv(validation); cells<-sort(unique(vv$cell))
 rr<-vapply(cells,function(cell){z<-vv[vv$cell==cell,];w<-z[z$method=="Wald",];g<-z[z$method=="Transformed Gaussian",]
  paste0(paste(c(if(w$sparse)"Sparse" else "Ordinary",w$n,paste0(dec(w$coverage,4)," (",dec(w$MCSE,4),")"),paste0(dec(g$coverage,4)," (",dec(g$MCSE,4),")"),paste0(w$numerical_successes,"/",w$B)),collapse=" & ")," \\\\")},character(1))
 writeLines(c(
 "The separately registered targeting experiment generated 5,000 cohorts in each of four cells: sample sizes 250 and 1,000 crossed with ordinary and sparse event rates. Histories were generated by a history-dependent finite-state law without latent frailty; the fitted event nuisance was pooled and censoring nuisance estimated by baseline stratum. The four simultaneous targets were two recurrent burdens, terminal risk and restricted survival. All 20,000 generated cohorts remain in the denominators, including unsuccessful score or positive-variance checks. No execution exception occurred.",
 "",
 "\\begin{table}[tbp]\\centering\\small",
 "\\begin{tabular}{lrrrr}\\toprule",
 "Regime & Subjects & Raw Wald & Transformed Gaussian & Numerical success \\\\ \\midrule",rr,
 "\\bottomrule\\end{tabular}",
 "\\caption{Simultaneous coverage in the registered 0.10.0 validation. Parentheses give binomial Monte Carlo standard errors. Raw comparisons precede the public zero-event regularity guard; all 5,000 cohorts per cell are retained.}\\label{tab:continuous_validation}","\\end{table}",
 "",
 "Transformed intervals approached nominal coverage in the ordinary cells but did not repair the sparse-event failures (Table~\\ref{tab:continuous_validation} and Figure~\\ref{fig:continuous_validation}). At 250 sparse subjects, simultaneous coverage was 0.5942 rather than 0.95; at 1,000 it was 0.9254. The simulation therefore supports a qualified regular-regime interface, not universal sparse-cell validity. The public API now withholds regular Gaussian limits when a target has an observed zero-event boundary. This diagnostic is additional to the preserved raw comparison and is not retrospectively scored as improved coverage.",
 "",
 "The public fallback uses observed lower and upper reward envelopes under censoring. For a target with known support, Hoeffding inequalities and a union bound give a simultaneous conservative outer confidence set; this argument requires independent identically distributed units but does not require independent censoring. Terminal-event indicators and restricted survival have such bounds. Uncapped burdens receive the uninformative outer support $[0,\\infty)$, rather than a fabricated finite upper limit. The output is labelled \\code{bounded\\_coarsening\\_projection}; it is distinct from the sharp finite-support sensitivity solver and does not recover point identification. Explicit Gaussian requests at a zero-event boundary remain unavailable. For the stated finite-sample guarantee, request \\code{interval = \"projection\"} uniformly. Data-dependent automatic switching between approximate Gaussian and projection intervals has neither the unconditional guarantee of the projection-only procedure nor a selection-conditional guarantee from this argument. Numerical integration tolerances, MCSE and confidence coverage remain separate diagnostics.",
 "A separately registered envelope experiment generated 5,000 cohorts under each of complete observation, independent censoring and informative censoring. Joint coverage of the bounded coordinates was 0.9992, 1.0000 and 1.0000, respectively. The first estimate has MCSE 0.00040; the two all-covered cells have binomial Monte Carlo lower limits 0.99926, rather than evidence of literal certainty. Median risk widths were 0.2960, 0.6380 and 0.6480, and restricted-survival widths were 0.2406, 0.4291 and 0.4329. These conservative sets trade precision for weaker observation assumptions. The 15,000-cohort check does not replace or retrospectively repair the separate 20,000-cohort Gaussian experiment.",
 "\\begin{figure}[tbp]\\centering\\includegraphics[width=\\textwidth]{figures/continuous_coverage.pdf}",
 "\\caption{Registered simultaneous-coverage comparison. Error bars are 1.96 Monte Carlo standard errors; the dashed line is the 0.95 nominal level. Sparse failures remain visible.}\\label{fig:continuous_validation}\\end{figure}"
 ),file.path(generated_dir,"continuous_validation_text.tex"))
}
checks <- if(file.exists("paper/final_check_statement.tex"))"paper/final_check_statement.tex" else "reviews/P6_revision_check_summary.txt"
writeLines(if(file.exists(checks))readLines(checks,warn=FALSE) else
 "The revision package checks are recorded separately from the predecessor's coverage and platform results. Current checks must be read from the 0.10.0 release register; no earlier passing result is reassigned to new source.",file.path(generated_dir,"revision_checks.tex"))

draw_architecture <- function(){
 par(mar=c(.3,.3,.3,.3),family="sans");plot.new();plot.window(xlim=c(0,10),ylim=c(0,10.5))
 rect(.8,9.55,9.2,10.35,col="#EDF1F4",border="#758899")
 text(5,9.95,"Declared event histories, observation model and target query",cex=.95,font=2)
 ys<-c(8.5,6.95,5.4,3.85,2.3)
 titles<-c("1  Automatic observation fibres","2  Frailty estimation and diagnostics","3  Targeting in the primary API","4  Future covariate evolution","5  Sparse propagation and sensitivity bounds")
 details<-c("Legal orders and time windows; quadrature or labelled importance sampling",
 "Gamma, lognormal or estimated mass points; likelihood, score and Louis information",
 "Finite-path MAR or finite-state right censoring; EIFs and qualified intervals",
 "Freeze, explicit schedules or Gaussian longitudinal draws; ordered generators",
 "CSR probability/reward updates; structural fractional optimization and certificates")
 colors<-c("#DCEAF0","#E5E9DD","#E5E4EF","#F2E7D9","#DFEAE5")
 segments(.45,1.1,.45,9.4);segments(9.55,1.1,9.55,9.4)
 arrows(2,9.55,.45,9.15,length=.07,col="#738491")
 for(i in seq_along(ys)){
  rect(.9,ys[i]-.58,9.1,ys[i]+.58,col=colors[i],border="#80909C")
  text(1.15,ys[i]+.19,titles[i],adj=0,cex=.98,font=2)
  text(1.15,ys[i]-.20,details[i],adj=0,cex=.78)
  arrows(.45,ys[i],.9,ys[i],length=.07,col="#738491")
  arrows(9.1,ys[i],9.55,ys[i],length=.07,col="#738491")
 }
 rect(.8,.1,9.2,1.05,col="#EDF1F4",border="#758899")
 arrows(9.55,1.1,8.9,1.05,length=.07,col="#738491")
 text(5,.72,"Typed results: risk, burden, time alive, intervals, bounds and diagnostics",cex=.91,font=2)
 text(5,.35,"Each query uses its eligible modules; their observation assumptions remain explicit.",cex=.78)
}
pdf(file.path(figure_dir,"architecture.pdf"),width=8,height=7,useDingbats=FALSE);draw_architecture();dev.off()
png(file.path(figure_dir,"architecture.png"),width=8,height=7,units="in",res=300);draw_architecture();dev.off()
if(file.exists(validation)) {
 draw_coverage<-function(){
  par(mar=c(4.2,4.6,.7,.8),family="sans")
  plot(NA,xlim=c(.7,4.3),ylim=c(.48,1),xaxt="n",xlab="",ylab="Simultaneous coverage")
  axis(1,at=1:4,labels=c("Ordinary\nn = 250","Ordinary\nn = 1,000","Sparse\nn = 250","Sparse\nn = 1,000"),tick=FALSE)
  abline(h=.95,lty=2,col="gray50")
  for(j in 1:2){z<-vv[vv$method==c("Wald","Transformed Gaussian")[j],];z<-z[order(z$cell),];x<-seq_len(nrow(z))+c(-.08,.08)[j];col<-c("#303030","#0072B2")[j]
   arrows(x,z$coverage-1.96*z$MCSE,x,z$coverage+1.96*z$MCSE,angle=90,code=3,length=.055,col=col)
   points(x,z$coverage,pch=c(16,15)[j],col=col,cex=1.2)
  }
  legend("bottomleft",c("Nominal 0.95","Raw Wald","Transformed Gaussian"),lty=c(2,NA,NA),pch=c(NA,16,15),col=c("gray50","#303030","#0072B2"),bty="n",cex=.9)
 }
 pdf(file.path(figure_dir,"continuous_coverage.pdf"),width=7,height=4.5,useDingbats=FALSE);draw_coverage();dev.off()
 png(file.path(figure_dir,"continuous_coverage.png"),width=7,height=4.5,units="in",res=300);draw_coverage();dev.off()
}
cat("Revision materials generated from completed recorded evidence.\n")
