## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse=TRUE,comment="#>")
library("coherent4cast")

## ----metrics------------------------------------------------------------------
risk <- c(.08,.12,.18,.25,.32,.48,.63,.77)
time <- c(5,4,1,6,2,4,1.5,3)
status <- c(0,1,1,0,1,0,1,1)
v <- validate(risk,time,status,horizon=3,threshold=.3)
v$metrics
v$confusion
v$assumptions

## ----conditional--------------------------------------------------------------
validate(risk,time,status,3,
  censor_survival=list(case=rep(.9,8),horizon=rep(.8,8)))$metrics

## ----conformal----------------------------------------------------------------
scores <- c(.05,.1,.12,.2,.22,.31,.35,.5,.6,.8)
candidates <- seq(.1,.9,by=.1)
sets <- rc_conformal(scores,candidates,alpha=.2)
sets$candidates
sets$coverage_guarantee

## ----certified----------------------------------------------------------------
certified <- rc_conformal(scores,candidates,alpha=.2,
   weight_status="certified",weight_lower=rep(.8,10),
   weight_upper=rep(1.2,10),candidate_weight_upper=rep(1.2,9),
   band_error=.02)
certified$candidates

## ----bands--------------------------------------------------------------------
b <- rc_band(theta=c(-2,.2),covariance=diag(c(.04,.01)),
   forecast=function(theta)plogis(theta[1]+theta[2]*c(0,1)),
   draws=1000,seed=21)
data.frame(estimate=b$estimate,lower=b$lower,upper=b$upper)
b$method

