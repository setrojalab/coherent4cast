# recurcast 0.10.1: private review bundle

This is an unpublished candidate. The repository remains private pending
author review. No CRAN or journal acceptance is implied.

Start with package/README.md and package/API.md. The complete R package source,
native source, tests, fixtures, four vignettes and generated help are supplied
under package/. Install release/recurcast_0.10.1.tar.gz from source, or use
the Windows binary built with R 4.6.2. The reference manual has 54 pages.
replication/README.md gives the independent commands for the eight portable
research scripts. No prior workstation or unbundled V5 oracle is required.

Current manuscripts are paper/01_RecurCast_JSS_Software_Paper and
paper/07_Targeted_API_And_Audit_Addendum, in PDF and editable Word format.
The 05 verification supplement and 06 usability guide are explicitly retained
0.10.0 companions; their older benchmark figures are not new 0.10.1 runs.
They remain useful scientific background to the additive R interfaces.

Six hosted R-release/devel package checks on Linux, macOS and Windows passed
with 1107 assertions each. All four GCC/Clang strict and ASAN/UBSAN jobs passed.
The tested source commit is fbf6429e37aa91e159d878a8228d62803b287056.
All 23 native-source hashes remain identical to 0.10.0. Local combined R/C++
line coverage is 95.46236%, without excluded files. These checks concern
software, examples and vignettes, not full cross-platform clinical study
replication, causal effects, clinical effectiveness or regulatory approval.

The evidence is under reviews/; all ten final hosted job logs are included so
verification survives hosted-artifact expiry. Two resolved macOS dependency/
setup events are summarized; their original failed/stalled logs remain in
the separate internal archive.
Detailed workstation logs, internal planning notes, cover letters, fitted
patient objects, private clinical records and incomplete oracle trees are
excluded from this distribution. The complete internal archive is separate.

The included snapshots are synthetic examples or aggregate public-data
metrics, not universal performance guarantees. Full public clinical records
are loaded by the scripts from the documented source R packages. Fixed
simulation seeds allow numerical comparison; runtime, session information,
audit timestamps, paths and graphics metadata may differ between machines.

REVIEW_BUNDLE_CONTENTS.json records every included file hash and provenance.
The later GitHub distribution commit may add this ZIP and documents; the
tested source commit above remains the reference for executed CI evidence.
