---
name: Reproducible bug report
about: Report a computational or documentation defect using synthetic data
---

## Expected result

## Observed result and full error message

## Minimal synthetic example

## sessionInfo and package version

Do not include patient-level data, credentials or private institutional data.
