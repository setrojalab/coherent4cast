"""Independent study implementation: finite-basis multitype gamma joint model.

Exact gamma marginal likelihood; no software package or general efficiency claim.
Rows describe observed (start, stop] intervals with predictable covariates.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import numpy as np
from scipy.optimize import minimize
from scipy.special import gammaln,digamma,polygamma
from scipy.optimize._numdiff import approx_derivative
from numba import njit

@njit(cache=True)
def simulate(n,seed,scenario=0,tau=2.0,phi=.6,censor_rate=.16):
    np.random.seed(seed)
    out=np.zeros((n*150,8));r=0
    beta=np.array([-.25,-.35,-.30]);gam=np.array([.25,.45,.55])
    base=np.array([.65,.30,.16])
    if scenario==1:gam=np.array([.6,.8,.9])
    for i in range(n):
        x=1.0 if np.random.random()<.5 else 0.0
        if scenario==2:z=np.exp(np.sqrt(np.log(1+phi))*np.random.normal()-.5*np.log(1+phi))
        elif scenario==5:z=1.0
        else:z=np.random.gamma(1/phi,phi)
        t=0.;c1=0;c2=0
        while t<tau:
            h1=min(c1,2);h2=min(c2,2)
            hh=np.array([h2,h1,(h1+h2)/2.])
            rates=base*np.exp(beta*x+gam*hh)*z
            if t>=1:rates*=1.25
            cr=censor_rate
            if scenario==3:cr=.24*np.exp(.3*x+.55*(h1+h2))
            rate=rates.sum()+cr
            delta=np.random.exponential(1/rate)
            boundary=min(tau,1.0 if t<1 else tau)
            stop=min(t+delta,boundary);typ=-1
            if t+delta<boundary:
                u=np.random.random()*rate
                if u<rates[0]:typ=0
                elif u<rates[0]+rates[1]:typ=1
                elif u<rates.sum():typ=2
                else:typ=3
            if r>=len(out):raise ValueError('Simulation allocation exceeded; no truncation allowed')
            out[r]=np.array([i,t,stop,typ,x,h1,h2,z]);r+=1
            t=stop
            if typ==0:c1+=1
            if typ==1:c2+=1
            if typ in (2,3):break
    return out[:r]

def simulation_design(raw,scenario=0):
    # Calendar-rounded data retain all original event order for a deliberately
    # labelled oracle-order approximation; this is not an exact tie likelihood.
    dat=raw.copy()
    if scenario==4:
        dat[:,1:3]=np.round(dat[:,1:3]/.05)*.05
    ids=dat[:,0].astype(int);dt=dat[:,2]-dat[:,1]
    features=[dat[:,6],dat[:,5],(dat[:,5]+dat[:,6])/2]
    m=len(dat);X=np.zeros((3*m,12));e=np.zeros(3*m)
    for k in range(3):
        sl=slice(k*m,(k+1)*m)
        X[sl,k*4]=(dat[:,1]<1)
        X[sl,k*4+1]=(dat[:,1]>=1)
        X[sl,k*4+2]=dat[:,4];X[sl,k*4+3]=features[k]
        e[sl]=(dat[:,3]==k)
    return np.tile(ids,3),np.tile(dt,3),X,e

class JointGamma:
    def __init__(self,ids,exposure,X,event,phi_fixed=None):
        self.ids=np.asarray(ids,dtype=int);self.dt=np.asarray(exposure);self.X=np.asarray(X);self.y=np.asarray(event)
        self.n=int(self.ids.max()+1);self.p=self.X.shape[1];self.phi_fixed=phi_fixed
        if np.any(self.dt<0):raise ValueError('Negative exposure')
        self.d=np.bincount(self.ids,weights=self.y,minlength=self.n)
        self.eventscore=np.zeros((self.n,self.p))
        for j in range(self.p):self.eventscore[:,j]=np.bincount(self.ids,weights=self.y*self.X[:,j],minlength=self.n)
    def evaluate(self,theta,individual=False):
        b=theta[:self.p];eta=self.X@b
        a=1/(np.exp(theta[-1]) if self.phi_fixed is None else self.phi_fixed) if self.phi_fixed!=0 else np.inf
        v=self.dt*np.exp(eta)
        A=np.bincount(self.ids,weights=v,minlength=self.n)
        A1=np.empty((self.n,self.p))
        for j in range(self.p):A1[:,j]=np.bincount(self.ids,weights=v*self.X[:,j],minlength=self.n)
        evt=self.eventscore@b
        if self.phi_fixed==0:
            ll=evt-A;s=self.eventscore-A1
        else:
            w=(a+self.d)/(a+A)
            ll=evt+gammaln(a+self.d)-gammaln(a)+a*np.log(a)-(a+self.d)*np.log(a+A)
            s=self.eventscore-w[:,None]*A1
            if self.phi_fixed is None:
                ga=digamma(a+self.d)-digamma(a)+np.log(a)+1-np.log(a+A)-(a+self.d)/(a+A)
                s=np.column_stack([s,-a*ga])
        if individual:return ll,s
        return -ll.sum()/self.n,-s.sum(axis=0)/self.n
    def information(self,theta):
        """Analytic observed information, summed over independent subjects."""
        v=self.dt*np.exp(self.X@theta[:self.p])
        A=np.bincount(self.ids,weights=v,minlength=self.n)
        A1=np.column_stack([np.bincount(self.ids,weights=v*self.X[:,j],minlength=self.n) for j in range(self.p)])
        if self.phi_fixed==0:return self.X.T@(v[:,None]*self.X)
        a=1/(np.exp(theta[-1]) if self.phi_fixed is None else self.phi_fixed)
        w=(a+self.d)/(a+A)
        bb=self.X.T@((v*w[self.ids])[:,None]*self.X)-A1.T@((w/(a+A))[:,None]*A1)
        if self.phi_fixed is not None:return (bb+bb.T)/2
        ua=digamma(a+self.d)-digamma(a)+np.log(a)+1-np.log(a+A)-(a+self.d)/(a+A)
        uaa=polygamma(1,a+self.d)-polygamma(1,a)+1/a-1/(a+A)+(self.d-A)/(a+A)**2
        cross=np.sum((-a*(A-self.d)/(a+A)**2)[:,None]*A1,axis=0)
        H=np.zeros((self.p+1,self.p+1));H[:self.p,:self.p]=bb
        H[:self.p,-1]=cross;H[-1,:self.p]=cross;H[-1,-1]=np.sum(-a*ua-a*a*uaa)
        return (H+H.T)/2
    def fit(self,start=None):
        if start is None:
            start=np.zeros(self.p+(self.phi_fixed is None))
            if self.phi_fixed is None:start[-1]=np.log(.5)
        bounds=[(-12,8)]*self.p+([(-5,2.5)] if self.phi_fixed is None else [])
        fit=minimize(self.evaluate,start,jac=True,method='L-BFGS-B',bounds=bounds,options={'maxiter':250,'ftol':1e-12,'gtol':2e-7,'maxls':30})
        theta=fit.x
        H=self.information(theta)
        eig=np.linalg.eigvalsh(H)
        inv=np.linalg.pinv(H,rcond=1e-10)
        _,scores=self.evaluate(theta,individual=True)
        sand=inv@scores.T@scores@inv
        self.theta=theta;self.phi=np.exp(theta[-1]) if self.phi_fixed is None else self.phi_fixed
        self.info=H;self.cov=inv;self.sandwich=sand;self.scores=scores
        self.ok=bool(fit.success and eig.min()>1e-7 and np.max(np.abs(self.evaluate(theta)[1]))<1e-4)
        self.status=dict(success=bool(fit.success),valid=self.ok,message=str(fit.message),min_information_eigenvalue=float(eig.min()),condition_number=float(np.linalg.cond(H)),at_parameter_boundary=bool(any(abs(theta[j]-a)<1e-4 or abs(theta[j]-b)<1e-4 for j,(a,b) in enumerate(bounds))),gradient_max=float(np.max(np.abs(self.evaluate(theta)[1]))),iterations=int(fit.nit))
        return self

def truth(scenario=0):
    rates=[.65,.30,.16];beta=[-.25,-.35,-.3];gamma=[.25,.45,.55] if scenario!=1 else [.6,.8,.9]
    return np.array([v for k in range(3) for v in [np.log(rates[k]),np.log(rates[k]*1.25),beta[k],gamma[k]]]+[np.log(.6)])

def check_derivatives():
    from scipy.optimize._numdiff import approx_derivative
    raw=simulate(50,123);m=JointGamma(*simulation_design(raw));b=truth()
    numerical=approx_derivative(lambda v:np.array([m.evaluate(v)[0]]),b).ravel()
    err=np.max(np.abs(numerical-m.evaluate(b)[1]));assert err<1e-6
    assert np.all(raw[:,2]>raw[:,1]);assert len(np.unique(raw[raw[:,3]==2,0]))==np.sum(raw[:,3]==2)
    fitted=m.fit();return dict(gradient_error=float(err),fit=fitted.status)

if __name__=='__main__':
    import json,time
    t=time.time();print(json.dumps(check_derivatives(),indent=2));print('seconds',time.time()-t)
