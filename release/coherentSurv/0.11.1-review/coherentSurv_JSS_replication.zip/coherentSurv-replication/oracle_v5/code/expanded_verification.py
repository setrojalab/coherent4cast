"""New numerical and inferential experiments with fixed seeds and retained failures."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import numpy as np,pandas as pd,json,itertools,argparse,time
from scipy.optimize import linprog
from scipy.stats import beta,nbinom
from concurrent.futures import ProcessPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parents[1]
P=json.loads((ROOT/'protocol/prespec.json').read_text())
def lp(p,kappa,outer=None,conditional=True):
    J=len(p);rho=.7;d=np.r_[np.arange(J)>0,np.arange(J)>0].astype(float) if conditional else np.ones(2*J)
    c=np.r_[np.arange(J)==J-1,np.arange(J)==J-1].astype(float)
    # Charnes-Cooper variables (r*t,u*t,t). Positive denominator guaranteed
    # by nonzero recorded probability of the conditioning event.
    A=[];b=[]
    low=.3/(.7*kappa);high=.3*kappa/.7
    for j in range(J):
        v=np.zeros(2*J+1);v[J+j]=1;v[j]=-high;A.append(v);b.append(0)
        v=np.zeros(2*J+1);v[j]=low;v[J+j]=-1;A.append(v);b.append(0)
        l,u=(rho*p[j],rho*p[j]) if outer is None else outer[j]
        v=np.zeros(2*J+1);v[j]=1;v[-1]=-u;A.append(v);b.append(0)
        v=np.zeros(2*J+1);v[j]=-1;v[-1]=l;A.append(v);b.append(0)
    eq=np.zeros((3,2*J+1));eq[0,:J]=1;eq[0,-1]=-.7;eq[1,J:2*J]=1;eq[1,-1]=-.3;eq[2,:2*J]=d
    obj=np.r_[c,0.];args=dict(A_ub=A,b_ub=b,A_eq=eq,b_eq=[0,0,1],bounds=[(0,None)]*(2*J+1),method='highs')
    a=linprog(obj,**args);z=linprog(-obj,**args)
    return (a.fun,-z.fun) if a.success and z.success else (np.nan,np.nan)
def vertices(p,kappa):
    J=len(p);lo=.3*p/kappa;hi=.3*p*kappa;vals=[]
    for free in range(J):
        other=[j for j in range(J) if j!=free]
        for bits in itertools.product([0,1],repeat=J-1):
            u=np.zeros(J)
            for j,b in zip(other,bits):u[j]=hi[j] if b else lo[j]
            u[free]=.3-u.sum()
            if lo[free]-1e-12<=u[free]<=hi[free]+1e-12:
                q=.7*p+u;vals.append(q[-1]/q[1:].sum())
    return min(vals),max(vals)
def bounds_batch(job):
    c,J,n,k,lo,hi=job;rng=np.random.default_rng(P['base_seed']+400000000+c*100000+lo);p=np.linspace(J,1,J);p=p/p.sum();L0,U0=lp(p,k);rows=[]
    for b in range(lo,hi):
        ct=rng.multinomial(n,p);ph=ct/n;lb=np.array([0 if v==0 else beta.ppf(.05/(2*J),v,n-v+1) for v in ct])*.7;ub=np.array([1 if v==n else beta.ppf(1-.05/(2*J),v+1,n-v) for v in ct])*.7
        L,U=lp(ph,k,list(zip(lb,ub)));a,z=lp(ph,k);valid=np.isfinite(L+U+a+z)
        rows.append(dict(cell=c,J=J,n=n,kappa=k,replicate=b,valid=valid,oracle_lower=L0,oracle_upper=U0,plugin_lower=a,plugin_upper=z,outer_lower=L,outer_upper=U,region_covered=bool(valid and L<=L0+1e-10 and U>=U0-1e-10)))
    return rows
def bounds(B,workers):
    checks=[]
    for J in [3,5]:
        p=np.arange(J,0,-1,dtype=float);p/=p.sum()
        for k in [1,1.5,2,3]:
            a=lp(p,k);v=vertices(p,k);checks.append(dict(J=J,kappa=k,LP_lower=a[0],LP_upper=a[1],vertex_lower=v[0],vertex_upper=v[1],error=max(abs(np.array(a)-v))))
    pd.DataFrame(checks).to_csv(ROOT/'results/conditional_LP_vertex_checks.csv',index=False)
    jobs=[]
    for c,(J,n,k) in enumerate(itertools.product([3,5],[250,1000],[1,1.5,2,3])):
        jobs.extend((c,J,n,k,a,min(B,a+50)) for a in range(0,B,50))
    rows=[];start=time.time()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for f in as_completed([pool.submit(bounds_batch,j) for j in jobs]):
            rows.extend(f.result())
            if len(rows)%2000==0:print('conditional LP',len(rows),'/',16*B,'seconds',round(time.time()-start,1),flush=True)
    d=pd.DataFrame(rows).sort_values(['cell','replicate']);d.to_csv(ROOT/'results/conditional_LP_replicates.csv',index=False)
    d['outer_width']=d.outer_upper-d.outer_lower;d['plugin_width']=d.plugin_upper-d.plugin_lower;d['oracle_width']=d.oracle_upper-d.oracle_lower;d['width_slack']=abs(d.plugin_width-d.oracle_width)
    s=d.groupby(['cell','J','n','kappa']).agg(B=('replicate','size'),valid=('valid','sum'),coverage=('region_covered','mean'),mean_outer_width=('outer_width','mean'),mean_id_width=('plugin_width','mean'),mean_oracle_slack=('width_slack','mean')).reset_index();s['MCSE']=np.sqrt(s.coverage*(1-s.coverage)/s.B);s.to_csv(ROOT/'results/conditional_LP_summary.csv',index=False)
    # Population tipping point for a conditional-risk threshold .60.
    p=np.array([.5,1/3,1/6]);a=1.;b=20.
    for _ in range(70):
        mid=(a+b)/2
        if lp(p,mid)[1]>=.6:b=mid
        else:a=mid
    (ROOT/'results/conditional_LP_breakdown.json').write_text(json.dumps(dict(threshold=.6,kappa_star=b,upper_at_star=lp(p,b)[1],scope='population conditional risk; fixed known recording fraction'),indent=2))
def conformal(B):
    rng=np.random.default_rng(P['base_seed']+500000000);rows=[];horizons=np.array([.25,.5,1.,2.]);tau=2.
    for regime in ['moderate','heavy']:
        for rep in range(B):
            ntr=500;nc=250;N=ntr+nc+1;x=rng.binomial(1,.5,N);z=rng.gamma(1/.6,.6,N);T=rng.exponential(1/(.22*z*np.exp(-.3*x)))
            rate=(.25+.5*x) if regime=='moderate' else (.8+1.1*x);C=rng.exponential(1/rate)
            stop=np.minimum(np.minimum(T,C),tau);censored=(C<T)&(C<tau);R=(T<=C)&(T<=tau)|(stop>=tau)
            Y=T[:,None]<=horizons;pred=1-np.exp(-.18*np.exp(-.15*x[:,None])*horizons);score=np.max(abs(Y-pred),axis=1)
            for model in ['known','estimated_X','estimated_pooled']:
                rates=np.zeros(N)
                for xx in [0,1]:
                    ix=np.arange(N)<ntr
                    if model=='estimated_X':ix&=x==xx
                    rc=(censored[ix].sum()+.5)/(stop[ix].sum()+.5)
                    rates[x==xx]=rc
                if model=='known':rates=rate.copy()
                for floor in [.01,.05,.1]:
                    cal=(np.arange(N)>=ntr)&(np.arange(N)<ntr+nc)&R;sc=score[cal];w=1/np.maximum(np.exp(-rates[cal]*np.minimum(T[cal],tau)),floor)
                    # Conservative upper bound on unknown test-outcome weight.
                    winf=1/max(np.exp(-rates[-1]*tau),floor);order=np.argsort(sc);cum=np.cumsum(w[order]);level=.95*(w.sum()+winf)
                    q=np.inf if not len(cum) or level>cum[-1] else sc[order[np.searchsorted(cum,level)]]
                    rows.append(dict(regime=regime,replicate=rep,model=model,floor=floor,complete_calibration=int(cal.sum()),covered=bool(score[-1]<=q),threshold=q,uninformative=bool(np.isinf(q)),max_calibration_weight=float(w.max()) if len(w) else np.nan))
    d=pd.DataFrame(rows);d.to_csv(ROOT/'results/censored_conformal_replicates.csv',index=False)
    s=d.groupby(['regime','model','floor']).agg(B=('replicate','size'),coverage=('covered','mean'),uninformative_fraction=('uninformative','mean'),mean_complete_calibration=('complete_calibration','mean'),mean_threshold=('threshold',lambda v:v[np.isfinite(v)].mean())).reset_index();s['MCSE']=np.sqrt(s.coverage*(1-s.coverage)/s.B);s.to_csv(ROOT/'results/censored_conformal_summary.csv',index=False)
def robustness(B):
    from additional_checks import crossfit
    crossfit(B=B,n=1000)
def main():
    a=argparse.ArgumentParser();a.add_argument('mode',choices=['bounds','conformal','robustness']);a.add_argument('--B',type=int,default=5000);a.add_argument('--workers',type=int,default=4);a=a.parse_args()
    if a.mode=='bounds':bounds(a.B,a.workers)
    elif a.mode=='conformal':conformal(a.B)
    else:robustness(a.B)
if __name__=='__main__':main()
