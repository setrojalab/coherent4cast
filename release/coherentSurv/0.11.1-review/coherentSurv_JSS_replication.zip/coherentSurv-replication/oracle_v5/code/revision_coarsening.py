"""Day-coarsened illness-death likelihood for all 929 colon-trial subjects.

Integrates times over (reported_day-1, reported_day], not an invented within-day
order. A recorded recurrence preceding death is the only legal order; post-death
recurrence is excluded by the model. Genuine compound jumps require another model.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,time
import numpy as np,pandas as pd
from scipy.special import logsumexp
from scipy.optimize import minimize
from scipy.optimize._numdiff import approx_derivative
from numpy.polynomial.legendre import leggauss
from joint_model import JointGamma
from applications import design,load_data
ROOT=Path(__file__).resolve().parents[1]
class CoarsenedColon:
    def __init__(self,nodes=4,selected=None,covariate='node4',node_median=None):
        data=pd.read_csv(ROOT/'data/raw/colon_trial.csv')
        if selected is not None:data=data[data.id.isin(selected)]
        if node_median is None:node_median=float(data.nodes.median())
        q,w=leggauss(nodes);q=(q+1)/2;w=w/2
        def integrate_nodes(lo,hi):
            # Split at every baseline discontinuity before Gaussian integration.
            cuts=sorted([lo,hi]+[v for v in [365.25,1095.75] if lo<v<hi])
            return [(l+(u-l)*v,(u-l)*wv) for l,u in zip(cuts[:-1],cuts[1:]) for v,wv in zip(q,w)]
        segments=[];owners=[];weights=[];source_ids=[];ties=[]
        for owner,(ident,g) in enumerate(data.groupby('id',sort=True)):
            r=g[g.etype==1].iloc[0];d=g[g.etype==2].iloc[0]
            x=np.array([r.rx=='Lev',r.rx=='Lev+5FU',r.sex,(r.age-60)/10,r.node4],float) if covariate=='node4' else np.array([r.rx=='Lev',r.rx=='Lev+5FU',r.sex,(r.age-60)/10,(node_median if pd.isna(r.nodes) else r.nodes)/5,pd.isna(r.nodes)],float)
            end=float(d.time);dead=int(d.status);re=int(r.status)
            if re==0 and r.time<end:end=float(r.time);dead=0
            if re and r.time>end:raise ValueError('Recurrence after terminal followup')
            paths=[]
            if re and dead and r.time==d.time:
                ties.append(int(ident))
                for rt,wu in integrate_nodes(r.time-1,r.time):
                    for dt,wv in integrate_nodes(rt,d.time):paths.append((rt,dt,wu*wv/(365.25**2)))
            else:
                rs=[(u,wu/365.25) for u,wu in integrate_nodes(r.time-1,r.time)] if re else [(None,1)]
                ds=[(u,wu/365.25) for u,wu in integrate_nodes(end-1,end)] if dead else [(end,1)]
                for rt,wr in rs:
                    for dt,wd in ds:paths.append((rt,dt,wr*wd))
            for rt,dt,weight in paths:
                pid=len(owners);owners.append(owner);weights.append(weight)
                if rt is not None:
                    segments.append((pid,0.,rt/365.25,1,0,0,x))
                    segments.append((pid,rt/365.25,dt/365.25,0,dead,1,x))
                else:segments.append((pid,0.,dt/365.25,0,dead,0,x))
            source_ids.append(int(ident))
        args,active,p0=design(segments,'colon');self.model=JointGamma(*args);self.owner=np.array(owners);self.logweight=np.log(weights)
        self.groups=np.r_[0,np.flatnonzero(np.diff(self.owner))+1];self.n=len(source_ids);self.ids=source_ids;self.ties=ties;self.nodes=nodes;self.active=active
    def evaluate(self,b,individual=False):
        ll,sc=self.model.evaluate(b,True);z=ll+self.logweight
        maxima=np.maximum.reduceat(z,self.groups);e=np.exp(z-maxima[self.owner]);den=np.add.reduceat(e,self.groups)
        loglik=maxima+np.log(den);post=e/den[self.owner]
        scores=np.add.reduceat(post[:,None]*sc,self.groups,axis=0)
        if individual:return loglik,scores
        return -loglik.mean(),-scores.mean(axis=0)
    def fit(self,start):
        p=len(start);fit=minimize(self.evaluate,start,jac=True,method='L-BFGS-B',bounds=[(-12,8)]*(p-1)+[(-5,2.5)],options=dict(maxiter=400,ftol=1e-12,gtol=2e-7))
        self.theta=fit.x;H=approx_derivative(lambda b:self.evaluate(b)[1],fit.x)*self.n;H=(H+H.T)/2;inv=np.linalg.pinv(H)
        ll,s=self.evaluate(fit.x,True);self.sandwich=inv@s.T@s@inv
        self.status=dict(success=bool(fit.success),gradient_max=float(max(abs(self.evaluate(fit.x)[1]))),min_information_eigenvalue=float(min(np.linalg.eigvalsh(H))),loglik=float(ll.sum()),iterations=int(fit.nit),nodes=self.nodes,subjects=self.n,latent_paths=self.model.n)
        return self
def main():
    pts,segs,names,_=load_data('colon');args,active,p0=design(segs,'colon');old=JointGamma(*args).fit()
    begin=time.time();model=CoarsenedColon(4).fit(old.theta);higher=CoarsenedColon(8)
    ll,_=model.evaluate(model.theta,True);ll8,_=higher.evaluate(model.theta,True)
    err=float(max(abs(ll-ll8)));assert err<1e-7,err
    labels=np.array([f'{k}_{v}' for k in ['recurrence','death'] for v in ['baseline_0_1','baseline_1_3','baseline_3_10']+names+['prior_count_capped_3']])[active].tolist()+['log_frailty_variance']
    pd.DataFrame(dict(parameter=labels,old_exact_order_924=old.theta,day_coarsened_929=model.theta,change=model.theta-old.theta,coarsened_robust_se=np.sqrt(np.maximum(0,np.diag(model.sandwich))))).to_csv(ROOT/'results/revision_colon_coarsening_coefficients.csv',index=False)
    pd.DataFrame(dict(id=model.ids,loglik_4_nodes=ll,loglik_8_nodes=ll8,abs_difference=abs(ll-ll8),same_day=[i in model.ties for i in model.ids])).to_csv(ROOT/'results/revision_colon_coarsening_subjects.csv',index=False)
    info=dict(fit=model.status,old_fit=old.status,same_day_ids=model.ties,legal_order='recurrence before death, integrated over its within-day triangle',coarsening='event at day d lies in (d-1,d]; censor times retained as observed endpoints',max_subject_loglik_difference_4_vs_8=err,seconds=time.time()-begin,death_ascertainment='unchanged source assumption; recurrence follow-up truncation retained',scope='illness-death submodel; numerical quadrature of exact coarsened likelihood, not general multitype coarsening')
    (ROOT/'results/revision_colon_coarsening.json').write_text(json.dumps(info,indent=2));print(json.dumps(info,indent=2),flush=True)
if __name__=='__main__':main()
