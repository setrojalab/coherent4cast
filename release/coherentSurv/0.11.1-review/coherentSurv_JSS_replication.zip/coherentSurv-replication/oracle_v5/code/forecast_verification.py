"""Coherent finite-state forecasting, with independent numerical checks."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import numpy as np,pandas as pd,json
from scipy.linalg import expm
from scipy.special import roots_genlaguerre,roots_hermitenorm,gammaln,softmax
from numba import njit
from joint_model import truth
ROOT=Path(__file__).resolve().parents[1]

@njit(cache=True)
def generator(theta,x):
    Q=np.zeros((10,10))
    for h1 in range(3):
        for h2 in range(3):
            j=3*h1+h2;hh=np.array([h2,h1,(h1+h2)/2.])
            for k in range(3):
                rate=np.exp(theta[4*k+1]+theta[4*k+2]*x+theta[4*k+3]*hh[k])
                target=3*min(h1+1,2)+h2 if k==0 else (3*h1+min(h2+1,2) if k==1 else 9)
                if target!=j:Q[j,target]+=rate;Q[j,j]-=rate
    return Q

@njit(cache=True)
def gamma_transition(Q,shape,rate,delta,state):
    # Gamma-mixture uniformization. NB weights integrate Poisson probabilities.
    nu=np.max(-np.diag(Q));P=np.eye(len(Q))+Q/nu
    row=np.zeros(len(Q));row[state]=1
    ratio=nu*delta/(rate+nu*delta)
    weight=np.exp(shape*np.log(1-ratio));total=weight;ans=weight*row
    for m in range(1,10000):
        row=row@P
        weight*=((shape+m-1)/m)*ratio
        ans+=weight*row;total+=weight
        if 1-total<1e-12:return ans,1-total
    raise ValueError('Uniformization tail did not converge')

def past_exposure(theta,x,counts):
    # A prespecified history observed over (0,1], not a generated future path.
    types=[0]*counts[0]+[1]*counts[1]
    types=sorted(types,key=lambda k:k)
    times=np.linspace(.2,.8,len(types)) if types else []
    c=[0,0];start=0.;A=0.
    for t,k in list(zip(times,types))+[(1.,-1)]:
        hh=[min(c[1],2),min(c[0],2),(min(c[0],2)+min(c[1],2))/2]
        A+=(t-start)*sum(np.exp(theta[4*j]+theta[4*j+2]*x+theta[4*j+3]*hh[j]) for j in range(3))
        start=t
        if k>=0:c[k]+=1
    return A

def risk(theta,x,counts,delta):
    a=np.exp(-theta[-1]);A=past_exposure(theta,x,counts)
    return gamma_transition(generator(theta,x),a+sum(counts),a+A,delta,3*counts[0]+counts[1])[0][9]

def checks():
    theta=truth();Q=generator(theta,1);a=np.exp(-theta[-1]);A=past_exposure(theta,1,(1,1))
    assert np.max(np.abs(Q.sum(axis=1)))<1e-12
    exact,tail=gamma_transition(Q,a+2,a+A,1,4)
    tables=[]
    for nodes in [5,15,30,60]:
        zz,ww=roots_genlaguerre(nodes,a+2-1);ww/=np.exp(gammaln(a+2))
        chk=sum(w*expm(Q*z/(a+A))[4] for z,w in zip(zz,ww))
        tables.append(dict(nodes=nodes,max_abs_error=float(np.max(np.abs(exact-chk))),mass_error=abs(float(chk.sum()-1))))
    assert tables[-1]['max_abs_error']<1e-9
    # Scalar K=0 reduction, using exactly the same cumulative hazard.
    h=.37;expected=1-np.exp(-h);actual=-np.expm1(-h);k0=abs(expected-actual)
    assert k0<1e-12
    # Product-law tower: propagate the posterior component, not an independently
    # refitted mixture at the second time.
    zz,ww=roots_genlaguerre(30,a-1);ww/=np.exp(gammaln(a))
    left=sum(w*(expm(Q*z/a*.4)@expm(Q*z/a*.6)) for z,w in zip(zz,ww))
    right=sum(w*expm(Q*z/a) for z,w in zip(zz,ww))
    pd.DataFrame(tables).to_csv(ROOT/'results/quadrature_checks.csv',index=False)
    result=dict(probability_mass_error=float(abs(exact.sum()-1)),uniformization_tail=float(tail),K0_algebra_error=k0,tower_error=float(np.max(np.abs(left-right))))
    (ROOT/'results/forecast_checks.json').write_text(json.dumps(result,indent=2))
    return result

def benchmarks():
    d=pd.read_csv(ROOT/'results/simulation_replicates.csv');d=d[d.valid==True]
    rows=[];profiles=[(x,c) for x in [0,1] for c in [(0,0),(1,0),(1,1),(2,2)]]
    for (s,n),g in d.groupby(['scenario','n']):
        oracle=truth(1 if s=='strong_feedback' else 0)
        oracle_profiles={}
        for h in [.5,1.]:
            vals=[]
            for x,c in profiles:
                if s=='lognormal_frailty':
                    nodes,w=roots_hermitenorm(80);zz=np.exp(np.sqrt(np.log(1.6))*nodes-.5*np.log(1.6))
                    A=past_exposure(oracle,x,c);weights=softmax(np.log(w)+sum(c)*np.log(zz)-A*zz)
                    Q=generator(oracle,x);val=sum(v*expm(Q*z*h)[3*c[0]+c[1],9] for z,v in zip(zz,weights))
                else:val=risk(oracle,x,c,h)
                vals.append(val)
            oracle_profiles[h]=np.array(vals)
        for _,r in g.iterrows():
            b=np.array([r[f'est_{j}'] for j in range(13)])
            for h in [.5,1.]:
                ph=np.array([risk(b,x,c,h) for x,c in profiles]);pt=oracle_profiles[h]
                low=np.array([risk(b,x,c,h/2) for x,c in profiles])
                # Expected Bernoulli Brier score evaluated against a common oracle.
                bs=np.mean(pt*(1-ph)**2+(1-pt)*ph**2)
                constant=np.mean(pt);null=np.mean(pt*(1-constant)**2+(1-pt)*constant**2)
                weight=pt[:,None]*(1-pt)[None,:]
                auc=np.sum(weight*((ph[:,None]>ph[None,:])+.5*(ph[:,None]==ph[None,:])))/weight.sum()
                rows.append(dict(scenario=s,n=int(n),replicate=int(r.replicate),horizon=h,Brier=bs,constant_Brier=null,oracle_Brier=np.mean(pt*(1-pt)),AUC=auc,oracle_ICI=np.mean(abs(ph-pt)),monotonicity=np.mean(ph>=low-1e-12),reference='generating_lognormal_law' if s=='lognormal_frailty' else 'generating_gamma_law'))
    out=pd.DataFrame(rows);out.to_csv(ROOT/'results/forecast_replicates.csv',index=False)
    summary=out.groupby(['scenario','n','horizon']).agg(B=('replicate','size'),Brier=('Brier','mean'),Brier_MCSE=('Brier',lambda x:x.std()/np.sqrt(len(x))),constant_Brier=('constant_Brier','mean'),AUC=('AUC','mean'),AUC_MCSE=('AUC',lambda x:x.std()/np.sqrt(len(x))),oracle_ICI=('oracle_ICI','mean'),ICI_MCSE=('oracle_ICI',lambda x:x.std()/np.sqrt(len(x))),monotonicity=('monotonicity','mean')).reset_index()
    summary.to_csv(ROOT/'results/forecast_summary.csv',index=False)

if __name__=='__main__':
    print(checks(),flush=True);benchmarks();print('Forecast benchmark complete.',flush=True)
