"""Cross-fitted exponential targeting of a coherent 13-path law.

The experiment observes X on everyone and the two-window path when R=1.
MAR identifies population means. MNAR is a deliberate unsupported stress arm.
This is not an unrestricted continuous-time hidden-history TMLE.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import numpy as np,pandas as pd,json,argparse,time
from scipy.special import roots_genlaguerre,roots_hermitenorm,gammaln,softmax
from concurrent.futures import ProcessPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parents[1]
PRESPEC=json.loads((ROOT/'protocol/prespec.json').read_text())
PATHS=[(a,b) for a in [0,1,2] for b in range(4)]+[(3,)]
F=np.array([[p.count(1),p.count(2),int(3 in p),1+int(p[0]!=3)] for p in PATHS],float)
MECH=PRESPEC['targeted_law']['mechanisms']
NORMAL=np.random.default_rng(778012).normal(size=(4096,4))
def path_prob(z,x,strong=False):
    out=[]
    for path in PATHS:
        v=np.ones_like(z);c1=c2=0
        for k in path:
            rates=np.array([.7,.16,.10])*np.exp(-.25*x+np.array([.5*c2,.5*c1,.4*(c1+c2)])*(2 if strong else 1))
            total=rates.sum();stay=np.exp(-z*total)
            v*=stay if k==0 else (rates[k-1]/total)*(1-stay)
            c1+=k==1;c2+=k==2
        out.append(v)
    return np.array(out).T
def oracle(mech,nodes=90):
    if mech=='lognormal_MAR':
        z,w=roots_hermitenorm(nodes);z=np.exp(np.sqrt(np.log(1.6))*z-.5*np.log(1.6));w/=np.sqrt(2*np.pi)
    else:
        a=1/.6;z,w=roots_genlaguerre(nodes,a-1);z/=a;w/=np.exp(gammaln(a))
    q=np.array([w@path_prob(z,x,mech=='strong_feedback_MAR') for x in [0,1]])
    assert np.max(abs(q.sum(axis=1)-1))<1e-12
    return q
ORACLES={m:oracle(m) for m in MECH}
def make_data(n,seed,mech):
    rng=np.random.default_rng(seed);x=rng.binomial(1,.5,n);q=ORACLES[mech]
    path=np.array([rng.choice(13,p=q[xx]) for xx in x]);pi=.8-.35*x
    if mech=='low_recording_MAR':pi=.3-.15*x
    if mech=='MNAR':pi*=np.where(F[path,2]==1,.25,1.)
    r=rng.binomial(1,pi);fold=rng.permutation(n)%5
    return x,path,r,fold
def fit_law(x,path,r,fold,good_m=True,good_r=True,initial_laws=None):
    n=len(x);G=10;N=np.zeros(G);K=np.zeros((G,13));q0=np.zeros((G,13));pi=np.zeros(G)
    for f in range(5):
        tr=fold!=f
        for xx in [0,1]:
            g=2*f+xx;va=(fold==f)&(x==xx);N[g]=va.sum();K[g]=np.bincount(path[va&(r==1)],minlength=13)
            ix=tr&((x==xx) if good_m else np.ones(n,bool))&(r==1)
            q0[g]=(np.bincount(path[ix],minlength=13)+.5/13)/(ix.sum()+.5)
            ix=tr&((x==xx) if good_r else np.ones(n,bool))
            pi[g]=np.clip((r[ix].sum()+.5)/(ix.sum()+1),.05,.99)
    if initial_laws is not None:q0=np.asarray(initial_laws).copy()
    C=1/pi;nr=K.sum(axis=1);target=K@F;eps=np.zeros(4)
    def eval_e(e):
        q=softmax(np.log(q0)+C[:,None]*(F@e)[None,:],axis=1);mu=q@F
        loss=-np.sum(K*np.log(np.maximum(q,1e-300)))/n
        grad=np.sum(C[:,None]*(nr[:,None]*mu-target),axis=0)/n
        H=np.zeros((4,4))
        for g in range(G):
            v=F-mu[g];H+=nr[g]*C[g]**2*(v.T@(q[g,:,None]*v))/n
        return loss,grad,H,q,mu
    it=0
    for it in range(60):
        loss,grad,H,q,mu=eval_e(eps)
        if max(abs(grad))<1e-6/np.sqrt(n):break
        step=np.linalg.pinv(H,rcond=1e-12)@grad;scale=1.
        while scale>1e-10:
            candidate=np.clip(eps-scale*step,-30,30)
            if eval_e(candidate)[0]<=loss-1e-4*scale*(grad@step):break
            scale*=.5
        eps=candidate
    loss,grad,H,q,mu=eval_e(eps);psi=N@mu/n;groups=2*fold+x
    D=mu[groups]-psi+r[:,None]*C[groups,None]*(F[path]-mu[groups])
    V=D.T@D/(n*(n-1));se=np.sqrt(np.maximum(0,np.diag(V)))
    mixed=np.zeros((2,13))
    for xx in [0,1]:
        ix=np.arange(xx,G,2);mixed[xx]=N[ix]@q[ix]/N[ix].sum()
    # This same mixture law generates every reported population query.
    direct=np.bincount(x,minlength=2)/n@mixed@F
    assert max(abs(psi-direct))<1e-12
    trace=pd.DataFrame(dict(subject=np.arange(n),x=x,fold=fold,recorded=r,path_observed=np.where(r,path,-1),recording_probability=pi[groups]))
    for j in range(4):trace[f'prediction_{j}']=mu[groups,j];trace[f'EIF_{j}']=D[:,j]
    valid=bool(max(abs(D.mean(axis=0)))<1e-6/np.sqrt(n) and np.all(se>0))
    return dict(psi=psi,se=se,V=V,D=D,q=mixed,valid=valid,score=max(abs(D.mean(axis=0))),iterations=it,trace=trace,initial=np.bincount(groups, minlength=G)@q0@F/n)
def coherence(q):
    # Tower for death by window 2; partition by complete first-window mark.
    p1=sum(q[j] for j,p in enumerate(PATHS) if p[0]==3);p2=q@F[:,2];rhs=p1
    for a in [0,1,2]:
        ids=[j for j,p in enumerate(PATHS) if p[0]==a];mass=q[ids].sum()
        rhs+=mass*(q[ids]@F[ids,2]/mass)
    return abs(rhs-p2)
def batch(job):
    cell,n,mech,lo,hi=job;out=[];qtrue=ORACLES[mech];truth=qtrue.mean(axis=0)@F
    for rep in range(lo,hi):
        seed=PRESPEC['base_seed']+100000000+cell*100000+rep
        row=dict(cell=cell,n=n,mechanism=mech,replicate=rep,seed=seed,valid=False,joint_cover=False)
        try:
            x,p,r,f=make_data(n,seed,mech);fit=fit_law(x,p,r,f)
            se=fit['se'];corr=fit['V']/np.outer(se,se);ev,vec=np.linalg.eigh((corr+corr.T)/2)
            draws=NORMAL@(vec*np.sqrt(np.maximum(ev,0))).T;crit=np.quantile(np.max(abs(draws),axis=1),.95)
            row.update(valid=fit['valid'],joint_cover=bool(fit['valid'] and np.all(abs(fit['psi']-truth)<=crit*se)),critical=crit,score_max=fit['score'],iterations=fit['iterations'],recorded=int(r.sum()),tower_error=max(coherence(v) for v in fit['q']),law_mass_error=max(abs(fit['q'].sum(axis=1)-1)),minimum_probability=float(fit['q'].min()))
            for j in range(4):row.update({f'est_{j}':fit['psi'][j],f'truth_{j}':truth[j],f'se_{j}':se[j],f'cover_{j}':bool(fit['valid'] and abs(fit['psi'][j]-truth[j])<=1.95996398454*se[j]),f'initial_{j}':fit['initial'][j]})
        except Exception as e:row['error']=repr(e)
        out.append(row)
    return out
def main(B,workers):
    path=ROOT/'results/targeted_law_replicates.csv'
    if path.exists():raise FileExistsError(path)
    specs=[(c,n,m) for c,(n,m) in enumerate((n,m) for n in [250,500,1000,2500] for m in MECH)]
    jobs=[(c,n,m,a,min(B,a+25)) for c,n,m in specs for a in range(0,B,25)];rows=[];start=time.time()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for f in as_completed([pool.submit(batch,j) for j in jobs]):
            rows.extend(f.result())
            if len(rows)%1000==0:print(f'targeted law {len(rows)}/{20*B}; {time.time()-start:.1f} seconds',flush=True)
    d=pd.DataFrame(rows).sort_values(['cell','replicate']);d.to_csv(path,index=False);summary=[]
    for (c,n,m),g in d.groupby(['cell','n','mechanism']):
        valid=g[g.valid];p=g.joint_cover.mean();qt=ORACLES[m];mu=qt@F;truth=mu.mean(axis=0);pr=np.array([.3,.15]) if m=='low_recording_MAR' else np.array([.8,.45]);bound=np.mean((mu-truth)**2,axis=0)+sum(np.sum(qt[x,:,None]*(F-mu[x])**2,axis=0)/pr[x] for x in [0,1])/2
        for j in range(4):
            v=valid[f'est_{j}'];bias=v.mean()-truth[j];cp=g[f'cover_{j}'].fillna(False).mean()
            summary.append(dict(cell=c,n=n,mechanism=m,query=j,B=len(g),valid=len(valid),failure_rate=1-len(valid)/len(g),truth=truth[j],mean=v.mean(),bias=bias,relative_bias=bias/abs(truth[j]),bias_MCSE=v.std()/np.sqrt(len(v)),coverage=cp,coverage_MCSE=np.sqrt(cp*(1-cp)/len(g)),joint_coverage=p,joint_MCSE=np.sqrt(p*(1-p)/len(g)),ESE=v.std(),ASE=valid[f'se_{j}'].mean(),efficiency_ratio=n*v.var()/bound[j] if m!='MNAR' else np.nan,score_max=valid.score_max.max(),tower_max=g.tower_error.max(),median_width=(2*valid.critical*valid[f'se_{j}']).median()))
    pd.DataFrame(summary).to_csv(ROOT/'results/targeted_law_summary.csv',index=False)
    ex=fit_law(*make_data(1000,PRESPEC['base_seed']+99000000,'MAR'));ex['trace'].to_csv(ROOT/'data/derived/targeted_law_EIF_example.csv',index=False)
    pd.DataFrame(ex['q'],columns=[str(p) for p in PATHS]).to_csv(ROOT/'results/targeted_law_example_probabilities.csv',index=False)
    (ROOT/'results/targeted_law_run.json').write_text(json.dumps(dict(B=B,cells=20,replications=len(d),seconds=time.time()-start,scope=PRESPEC['targeted_law']['scope']),indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--B',type=int,default=5000);ap.add_argument('--workers',type=int,default=4);a=ap.parse_args();main(a.B,a.workers)
