# Reproduce version 0.10.0 validation

Run from the project root with the supplied R package installed. An optional
`coherentSurv_LIBRARY` environment variable selects its local library. Public data
are obtained through installed `frailtypack` and `survival`, not from hidden
patient files. `nlme` supports the longitudinal example.

```sh
Rscript --vanilla replication/run_case_studies.R
Rscript --vanilla paper/replication_script.R
Rscript --vanilla package/inst/benchmarks/sparse_scaling.R
Rscript --vanilla package/inst/benchmarks/frailty_future.R
Rscript --vanilla package/inst/benchmarks/frailty_boundary.R
Rscript --vanilla replication/check_observed_reward_envelope.R
```

Use `coherentSurv_CASE_OUTPUT`, `coherentSurv_CASE_CACHE` and
`coherentSurv_BENCHMARK_OUT` to choose new output directories. The benchmark scripts
do not overwrite the frozen primary research manifest. The envelope script
writes its separately registered 15,000-cohort results under `reviews/`.

Python is needed only for the independent reference calculations and summaries.
The pinned validation environment used Python 3.11; use a separate environment
for these archived versions:

```sh
python -m pip install -r replication/requirements-validation.txt
python replication/generate_continuous_fixture.py
python replication/continuous_API_fixtures.py
Rscript --vanilla replication/check_continuous_primary_API.R
python replication/continuous_validation_truth.py
```

The native 20,000-cohort experiment uses the actual continuous-targeting header.
With a C++17 compiler (for example GCC), compile and run:

```sh
g++ -std=c++17 -O3 -pthread -Ipackage/inst/include replication/continuous_target_validation.cpp -o ct_validation
./ct_validation reviews/P2_continuous_validation_replicates.csv replication/continuous_validation_truth.csv 5000 4
python replication/summarize_continuous_validation.py
```

On Windows use `ct_validation.exe` and the Rtools compiler environment. The last
two arguments are replications per cell and worker count. All four cells and
unsuccessful fits are retained. The raw Gaussian comparison predates the public
boundary fallback and remains an experiment about those Gaussian procedures;
it is not reclassified as a successful envelope experiment.

The original measured runtime is retained in its completed run log. On a rerun,
set `coherentSurv_VALIDATION_SECONDS` to the actual completed runtime before the
summary command if a runtime field is wanted; otherwise the new summary leaves
that field empty. It never copies an earlier machine's runtime into a new run.

The 15,000-cohort envelope check invokes the actual projection function and
verifies individual lower/upper reward containment before aggregating coverage.
Using `interval="projection"` consistently invokes its unconditional theorem.
Data-dependent automatic Gaussian/projection selection has a different scope.
