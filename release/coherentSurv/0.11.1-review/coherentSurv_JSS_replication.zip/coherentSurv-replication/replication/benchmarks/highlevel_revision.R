# Rerun the same high-level workload after the explicitly documented optimizer fix.
args<-commandArgs(trailingOnly=TRUE)
root<-if(length(args))normalizePath(args[1],winslash="/")else normalizePath(getwd(),winslash="/")
.libPaths(c(file.path(root,"build","qa_library"),file.path(root,"build","Rlib"),.libPaths()))
library(coherentSurv);Sys.unsetenv("LC_ALL")
out<-file.path(root,"replication","results","benchmarks")
base<-cs_simulate(40,seed=20261122L,time_unit="years")
units<-split(seq_len(nrow(base)),base$id);w<-rep(seq_along(units),length.out=1000)
d<-base[unlist(unname(units[w]),use.names=FALSE),,drop=FALSE]
d$id<-rep(seq_len(1000),lengths(units)[w]);rownames(d)<-NULL
tab<-data.frame()
for(b in 1:5) {
  gc();t<-proc.time()[["elapsed"]]
  fit<-cs_fit(~x,d,event_types=c("1","2"),time_unit="years",control=cs_control(phi_fixed=.45,maxit=150L))
  tab<-rbind(tab,data.frame(repeat_id=b,n=1000,parameters=length(coef(fit)),elapsed_seconds=proc.time()[["elapsed"]]-t,
    gradient=fit$convergence$gradient,optimizer_code=fit$convergence$optimizer,valid=fit$convergence$valid,
    convergence_code=fit$convergence$code,loglik=fit$loglik))
}
write.csv(tab,file.path(out,"highlevel_revision.csv"),row.names=FALSE)
writeLines(c("The original highlevel_fit_fixed_phi timing rows are preserved.",
  "This rerun uses the same workload and settings after the package reduced the L-BFGS-B factr stopping threshold.",
  "The source change was prompted by a visible gradient failure; it is not an alternative seed or selected successful sample.",
  paste("Loaded package",find.package("coherentSurv"))),file.path(out,"highlevel_revision_scope.txt"))
forecasts<-lapply(c(5,15,30),function(q)predict(fit,d[d$id %in% 1:4,,drop=FALSE],landmark=0,horizon=c(.5,1,2),type="all",quadrature=q))
stability<-do.call(rbind,lapply(seq_along(forecasts),function(k){z<-forecasts[[k]];z$quadrature_nodes<-c(5,15,30)[k];z$difference_from_30<-z$estimate-forecasts[[3]]$estimate;z}))
write.csv(stability,file.path(out,"quadrature_stability_revision.csv"),row.names=FALSE)
saveRDS(fit,file.path(out,"highlevel_fit_revision.rds"))
print(tab)
