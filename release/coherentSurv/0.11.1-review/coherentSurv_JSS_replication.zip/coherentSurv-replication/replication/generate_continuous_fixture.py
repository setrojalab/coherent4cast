from pathlib import Path
import numpy as np,pandas as pd,json
import continuous_reference_v5 as ref
root=Path(__file__).resolve().parents[1]
out=root/'package/tests/testthat/fixtures';out.mkdir(exist_ok=True,parents=True)
rows,x,fold=ref.simulate(500,1702611220)
fit=ref.estimate(rows,x,fold,False,L=64)
d=pd.DataFrame(dict(id=rows[:,0].astype(int)+1,x=rows[:,1].astype(int),fold=rows[:,2].astype(int)+1,start=rows[:,4],stop=rows[:,5],event_type=np.where(rows[:,6]==0,'recurrent1',np.where(rows[:,6]==1,'recurrent2','none')),terminal=(rows[:,6]==2).astype(int),censored=(rows[:,6]==3).astype(int)))
d.to_csv(out/'continuous_target_subjects.csv',index=False)
pd.DataFrame(dict(estimate=fit['estimate'],se=fit['se'],initial=fit['initial'])).to_csv(out/'continuous_target_expected.csv',index=False)
pd.DataFrame(fit['EIF']).to_csv(out/'continuous_target_eif.csv',index=False)
pd.DataFrame(dict(rate=fit['lam'].ravel())).to_csv(out/'continuous_target_rates.csv',index=False)
(out/'continuous_target_provenance.json').write_text(json.dumps(dict(n=500,seed=1702611220,grid=64,valid=bool(fit['valid']),score=float(fit['score']),iterations=int(fit['iterations']),reference='Copied V5 F2 continuous-targeting oracle; original unchanged'),indent=2))
print(dict(valid=fit['valid'],score=fit['score'],iterations=fit['iterations'],estimate=fit['estimate'].tolist()))
