"""Compare regenerated scientific manuscript material, excluding session metadata."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]
a = root / "replication/fresh_runs/run1/paper/generated"
b = root / "replication/fresh_runs/run2/paper/generated"
submitted = root / "paper/generated"
original = {"benchmark_interpretation.tex", "benchmark_table.tex", "case_forecasts_table.tex",
            "case_table.tex", "numbers.tex", "parity_table.tex", "quickstart.csv",
            "quickstart_table.tex", "related_table.tex", "sensitivity.csv", "validation_table.tex"}
files = {p.name for p in a.iterdir() if p.suffix in {".tex", ".csv"}}
assert original.issubset(files)
assert files == {p.name for p in b.iterdir() if p.suffix in {".tex", ".csv"}}
records = []
for name in sorted(files):
    first = (a/name).read_bytes().replace(b"\r\n", b"\n")
    second = (b/name).read_bytes().replace(b"\r\n", b"\n")
    assert first == second, name
    current = (submitted/name).read_bytes().replace(b"\r\n", b"\n") if (submitted/name).exists() else b""
    records.append({"file": name, "original_eleven": name in original,
                    "identical_between_fresh_runs": True, "matches_paper": current == first,
                    "sha256": hashlib.sha256(first).hexdigest()})
result = {"version": "0.10.0", "original_files": len(original), "all_scientific_files": len(records),
          "all_fresh_runs_identical": True,
          "different_from_paper_materialization": [x["file"] for x in records if not x["matches_paper"]],
          "generated_tables": records,
          "installed_library": "build/p6_binary_20261123_091843/installed_binary",
          "input_script_sha256": {p: hashlib.sha256((root/p).read_bytes()).hexdigest() for p in
                                    ["paper/replication_script.R", "paper/revision_materials.R"]}}
(root/"reviews/fresh_paper_replication.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))

