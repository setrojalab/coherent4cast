script<-sub("^--file=","",grep("^--file=",commandArgs(FALSE),value=TRUE)[1])
base<-normalizePath(file.path(dirname(script),".."),winslash="/")
local_library<-Sys.getenv("COHERENTSURV_LIBRARY","")
if(nzchar(local_library)).libPaths(c(local_library,.libPaths()))
library(coherentSurv);Sys.unsetenv('LC_ALL')
output<-list()
for(cell in 0:3)for(working in c('pooled','loglinear')) {
 d<-read.csv(file.path(base,paste0('build/continuous_API_cell',cell,'.csv')))
 captured<-character();fit<-withCallingHandlers(cs_fit(~x,d,time_unit='year',targeting='continuous',event_types=c('recurrent1','recurrent2'),targeting_spec=list(horizon=1,censor='censored',strata='x',folds='fold',grid=64,working=working)),warning=function(w){captured<<-c(captured,conditionMessage(w));invokeRestart('muffleWarning')})
 for(method in c('multiplier','logit_gaussian')) {
  p<-predict(fit,interval=method,draws=1000,seed=20261123)
  p$cell<-cell;p$n<-fit$n;p$working<-working;p$valid<-fit$convergence$valid;p$EIF_mean_max<-max(abs(fit$EIF_mean));p$interpolation_audit<-fit$interpolation_error;p$warnings<-paste(captured,collapse='; ')
  output[[length(output)+1L]]<-p
 }
}
out<-do.call(rbind,output);write.csv(out,file.path(base,'reviews/P2_primary_API_cells.csv'),row.names=FALSE)
print(out[,c('cell','working','interval','target','estimate','lower','upper','valid')],row.names=FALSE)
