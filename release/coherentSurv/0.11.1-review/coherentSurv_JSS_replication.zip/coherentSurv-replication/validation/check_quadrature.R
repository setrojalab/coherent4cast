if(nzchar(Sys.getenv("COHERENTSURV_LIBRARY"))) .libPaths(c(Sys.getenv("COHERENTSURV_LIBRARY"),.libPaths()))
library(coherentSurv)
e<-new.env(parent=asNamespace("coherentSurv"));sys.source("package/R/frailty.R",e)
f<-readRDS("reviews/root_validation/readmission_frailty_fits.rds")$lognormal
d<-f$design
z<-do.call(rbind,lapply(c(20,40,80,160,320,640),function(q){x<-e$cs_frailty_loglik(coef(f),d$unit,d$exposure,d$design,d$event,"lognormal",quadrature=q);data.frame(nodes=q,logLik=sum(x$subject_loglik),max_gradient=max(abs(colMeans(x$scores))))}))
write.csv(z,"reviews/root_validation/readmission_quadrature_refinement.csv",row.names=FALSE);print(z)
