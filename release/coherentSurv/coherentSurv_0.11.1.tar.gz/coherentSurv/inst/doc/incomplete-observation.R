## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse=TRUE,comment="#>")
library("coherentSurv")

## ----support------------------------------------------------------------------
paths <- as.matrix(expand.grid(second=0:3, first=0:2)[,c("first","second")])
paths <- rbind(paths,c(3,NA))
features <- cbind(count1=rowSums(paths==1,na.rm=TRUE),
                  count2=rowSums(paths==2,na.rm=TRUE),
                  terminal=as.numeric(rowSums(paths==3,na.rm=TRUE)>0),
                  grid_alive=1+as.numeric(paths[,1]!=3))
features

## ----targeting----------------------------------------------------------------
set.seed(104)
n <- 800
strata <- rep(0:1,length.out=n)
path <- sample(seq_len(nrow(features)),n,replace=TRUE)
recorded <- rbinom(n,1,.8-.3*strata)
path[recorded==0] <- NA
folds <- sample(rep(1:5,length.out=n))
target <- cs_target(path,recorded,strata,features,folds=folds)
data.frame(target=names(target$estimate),estimate=target$estimate,
           se=target$se,EIF_mean=target$EIF_mean,
           EIF_variance=target$EIF_variance)
target$convergence

## ----bounds-------------------------------------------------------------------
counts <- c(50,30,20)
results <- lapply(c(1,2,4),function(k) {
  b <- cs_bounds(counts/sum(counts),c(0,0,1),kappa=k,
                 recording_fraction=.7,counts=counts)
  data.frame(kappa=k,lower=b$lower,upper=b$upper,
             confidence_lower=b$outer$lower,
             confidence_upper=b$outer$upper)
})
do.call(rbind,results)

## ----colon, eval=FALSE--------------------------------------------------------
# a <- cs_colon(nodes=4,covariate="node4")
# fit <- cs_fit(a$formula,a$data,event_types=a$event_types,
#                  nonrecurrent=a$nonrecurrent,time_unit="years",
#                  breaks=c(0,1,3,Inf),observation="coarsened",
#                  coarsening=a$coarsening)

