## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(coherentSurv)

## ----adam---------------------------------------------------------------------
adtte <- data.frame(USUBJID = c("001", "1", "003"), PARAMCD = "OS",
                    AVAL = c(5, 8, 10), CNSR = c(0L, 1L, 2L))
adsl <- data.frame(USUBJID = c("001", "1", "003"), age = c(51, 62, 47))
history <- cs_from_adam(adtte, paramcd = "OS", event_codes = 0,
  censor_codes = c(1, 2), time_unit = "days",
  duration_definition = "Constructed elapsed follow-up in days",
  ascertainment = "Complete endpoint follow-up by construction",
  provenance = "Synthetic tutorial; no patient records",
  adsl = adsl, covariates = "age")
history[, c("id", "start", "stop", "terminal", "age")]
stopifnot(identical(history$id, c("001", "1", "003")),
          identical(history$terminal, c(1L, 0L, 0L)))

## ----omop---------------------------------------------------------------------
origin <- as.Date("2020-01-01")
person <- data.frame(person_id = c("001", "1"))
period <- data.frame(person_id = person$person_id,
  observation_period_start_date = origin,
  observation_period_end_date = origin + 10)
events <- data.frame(person_id = c("001", "1"),
  condition_concept_id = c("EXAMPLE_A", "EXAMPLE_A"),
  condition_start_date = origin + c(3, 4))
death <- data.frame(person_id = "001", death_date = origin + 8)
mapped <- cs_from_omop(person, period, events,
  concept_map = c(EXAMPLE_A = "episode"), origin = rep(origin, 2),
  time_unit = "days", timing = "exact_day_boundaries",
  ascertainment = "Continuous complete ascertainment by construction",
  provenance = "Artificial source labels; not real standard OMOP concepts",
  death = death)
mapped[, c("id", "start", "stop", "event_type", "terminal")]
stopifnot(sum(mapped$.cs_mark > 0) == 2, sum(mapped$terminal) == 1)

## ----audit--------------------------------------------------------------------
audit <- cs_audit_report(history, include_session = FALSE)
audit$model$mapping_provenance$adapter
audit$export$data_fingerprint$algorithm

## ----environment--------------------------------------------------------------
diagnostic <- cs_validate_env()
diagnostic$checks[, c("check", "status", "maximum_absolute_error")]
stopifnot(identical(diagnostic$operational_status, "passed"))

