## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(coherentSurv)

## ----credit-generator---------------------------------------------------------
sim_credit_portfolio <- function(n = 120L, max_years = 4, seed = 808L) {
  d <- cs_simulate(
    n = n, horizon = max_years,
    rates = c(0.50, 0.30, 0.18),
    beta = c(0.25, 0.15, 0.35),
    history = c(0.12, 0.10, 0.20),
    dispersion = 0.40, censor_rate = 0.04,
    history_cap = 1L, seed = seed, time_unit = "years"
  )
  d$account_id <- sprintf("ACCT-%04d", d$id)
  d$id <- NULL
  names(d)[names(d) == "x"] <- "leverage_group"
  labels <- c("0", "delinquency", "covenant_breach")
  d$event_type <- labels[d$event_type + 1L]
  d
}

credit <- sim_credit_portfolio()
head(credit, 6)
attr(credit, "truth")

## ----credit-fit---------------------------------------------------------------
account_ids <- unique(credit$account_id)
training_ids <- account_ids[seq_len(90L)]
evaluation_ids <- account_ids[-seq_len(90L)]
training <- credit[credit$account_id %in% training_ids, , drop = FALSE]

training_trajectory <- cs_as_trajectory(
  training, unit = "account_id", start = "start", stop = "stop",
  event_type = "event_type", terminal = "terminal", observed = "observed",
  event_types = c("delinquency", "covenant_breach"), time_unit = "years"
)
fit_credit <- cs_fit(
  ~ leverage_group, data = training_trajectory, unit = "account_id",
  observed = "observed", event_types = c("delinquency", "covenant_breach"),
  time_unit = "years", frailty = "gamma",
  control = cs_control(phi_fixed = 0.40, history_cap = 1L, maxit = 200L)
)
fit_credit$convergence

## ----credit-landmark----------------------------------------------------------
landmark <- 1
evaluation <- credit[credit$account_id %in% evaluation_ids, , drop = FALSE]
by_account <- split(evaluation, evaluation$account_id)
eligible <- vapply(by_account, function(g) {
  max(g$stop) >= landmark &&
    !any(g$terminal == 1L & g$stop <= landmark)
}, logical(1))
eligible_ids <- names(eligible)[eligible]
stopifnot(length(eligible_ids) >= 3L)

history_at_landmark <- evaluation[
  evaluation$account_id %in% eligible_ids & evaluation$start < landmark,
  , drop = FALSE
]
crosses_landmark <- history_at_landmark$stop > landmark
history_at_landmark$stop[crosses_landmark] <- landmark
history_at_landmark$event_type[crosses_landmark] <- "0"
history_at_landmark$terminal[crosses_landmark] <- 0L
stopifnot(
  all(history_at_landmark$stop <= landmark),
  all(history_at_landmark$terminal == 0L),
  all(tapply(history_at_landmark$stop,
             history_at_landmark$account_id, max) == landmark)
)

# Display three accounts selected by identifier, not forecast or later outcome.
forecast_history <- history_at_landmark[
  history_at_landmark$account_id %in% head(eligible_ids, 3L), , drop = FALSE
]
forecast <- predict(
  fit_credit, newdata = forecast_history, landmark = landmark,
  horizon = c(0.5, 1, 2), type = "all", covariate_evolution = "freeze"
)
forecast[forecast$unit == forecast$unit[1L],
         c("unit", "landmark", "horizon", "target", "estimate", "time_unit")]

## ----credit-coherence---------------------------------------------------------
keys <- c("unit", "landmark", "horizon")
risk <- forecast[forecast$target == "risk", c(keys, "estimate")]
survival <- forecast[forecast$target == "survival", c(keys, "estimate")]
paired <- merge(risk, survival, by = keys, suffixes = c("_risk", "_survival"))
restricted_life <- forecast[forecast$target == "rmst", ]
stopifnot(
  max(abs(paired$estimate_risk + paired$estimate_survival - 1)) < 1e-8,
  all(forecast$estimate >= -1e-10),
  all(restricted_life$estimate <= restricted_life$horizon + 1e-8)
)

## ----credit-loss--------------------------------------------------------------
one_year <- risk[risk$horizon == 1, c("unit", "estimate")]
names(one_year)[2L] <- "default_probability"
one_year$exposure_at_default <- 100000
one_year$loss_given_default <- 0.40
one_year$expected_default_loss <- with(
  one_year, default_probability * exposure_at_default * loss_given_default
)
one_year

## ----credit-recording-law-----------------------------------------------------
support <- data.frame(
  complete_history = c("no episodes; no default", "delinquency; no default",
                       "covenant breach; default", "two distress episodes; default"),
  default = c(0, 0, 1, 1),
  recorded_count = c(50L, 30L, 15L, 5L)
)
p_recorded <- support$recorded_count / sum(support$recorded_count)
support

bounded <- cs_bounds(
  p = p_recorded, numerator = support$default,
  kappa = 1.75, recording_fraction = 0.80,
  counts = support$recorded_count, alpha = 0.05
)
stopifnot(is.list(bounded$outer))
data.frame(
  layer = c("Identification bounds at recorded empirical law",
            "Outer projection including recorded-count uncertainty"),
  lower = c(bounded$lower, bounded$outer$lower),
  upper = c(bounded$upper, bounded$outer$upper)
)

# The structural solver targets the same declared finite problem.
sparse_bounded <- cs_bounds_sparse(
  p = p_recorded, numerator = support$default,
  kappa = 1.75, recording_fraction = 0.80,
  counts = support$recorded_count, alpha = 0.05
)
stopifnot(max(abs(c(bounded$lower, bounded$upper) -
                    c(sparse_bounded$lower, sparse_bounded$upper))) < 1e-8)
bounded$assumptions

