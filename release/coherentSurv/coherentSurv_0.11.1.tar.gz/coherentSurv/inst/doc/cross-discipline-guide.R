## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(coherentSurv)

## ----relabel------------------------------------------------------------------
raw <- cs_simulate(30, horizon = 1, rates = c(.8, .4, .3), seed = 1126,
                   censor_rate = 0, time_unit = "years")
clinical <- raw
clinical$event_type <- c("0", "admission", "toxicity")[raw$event_type + 1L]
engineering <- raw
engineering$event_type <- c("0", "repair", "fault")[raw$event_type + 1L]
a <- cs_as_trajectory(clinical, event_types = c("admission", "toxicity"),
                       time_unit = "years")
b <- cs_as_trajectory(engineering, event_types = c("repair", "fault"),
                       time_unit = "years")
stopifnot(identical(a$.cs_mark, b$.cs_mark),
          identical(a$.cs_terminal, b$.cs_terminal),
          identical(unname(cs_build_history(a)$counts), unname(cs_build_history(b)$counts)))
data.frame(records = nrow(a), units = length(unique(a$id)),
           terminal_events = sum(a$terminal))

