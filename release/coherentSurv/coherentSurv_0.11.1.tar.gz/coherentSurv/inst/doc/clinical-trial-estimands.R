## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(coherentSurv)

## ----estimand-----------------------------------------------------------------
trial_estimand <- list(
  population = "All synthetic participants eligible at randomization",
  treatment = "Baseline assignment 1 versus 0, maintained through two years",
  endpoint = c(
    "Hospitalization count before death or year two",
    "Adverse-event episode count before death or year two",
    "All-cause death by year two",
    "Restricted mean time alive through year two"
  ),
  intercurrent_events = paste(
    "Death ends recurrent-event accumulation.",
    "Independent loss to follow-up is right censoring.",
    "Switching and treatment discontinuation are not generated."
  ),
  population_summary = "Arm-one minus arm-zero standardized mean for each outcome"
)
trial_estimand

## ----generator----------------------------------------------------------------
simulate_trial <- function(n = 120L, horizon = 2, seed = 20261126L) {
  d <- cs_simulate(
    n = n, horizon = horizon,
    rates = c(.65, .40, .30),
    beta = c(-.25, -.20, -.15),
    history = c(.10, .10, .12),
    dispersion = 0, censor_rate = .08,
    history_cap = 1L, seed = seed, time_unit = "years"
  )
  d$assigned <- d$x
  d$x <- NULL
  d$event_type <- c("none", "hospitalization", "adverse_event")[d$event_type + 1L]
  d$censored <- as.integer(
    d$event_type == "none" & d$terminal == 0L & d$stop < horizon
  )
  d
}

trial <- simulate_trial()
head(trial, 6)

# One endpoint row per participant, used only for the cohort summary and OS extract.
endpoint <- trial[!duplicated(trial$id, fromLast = TRUE), ]
cohort_summary <- aggregate(
  cbind(participants = rep(1L, nrow(endpoint)),
        deaths = endpoint$terminal, early_censoring = endpoint$censored),
  by = list(assigned = endpoint$assigned), FUN = sum
)
cohort_summary

## ----causal-fit---------------------------------------------------------------
fit <- cs_causal(
  formula = ~1, data = trial,
  treatment = "assigned", horizon = 2, censor = "censored",
  unit = "id", start = "start", stop = "stop",
  event_type = "event_type", terminal = "terminal",
  event_types = c("hospitalization", "adverse_event"),
  time_unit = "years", propensity = .5,
  spec = list(nfolds = 3L, history_cap = 1L,
              working = "loglinear", grid = 32L),
  seed = 41L, estimand = trial_estimand
)

contrasts <- cs_causal_contrast(fit, contrast = "difference", interval = "wald")
knitr::kable(contrasts, digits = 3)

## ----simultaneous-intervals---------------------------------------------------
simultaneous <- cs_causal_contrast(
  fit, contrast = "difference", interval = "multiplier", draws = 300L, seed = 7L
)
knitr::kable(simultaneous[c("target", "estimate", "lower", "upper",
                           "inference_status")], digits = 3)
fit$convergence
fit$diagnostics

## ----adam-mapping-------------------------------------------------------------
adtte <- data.frame(
  USUBJID = sprintf("S%03d", endpoint$id),
  PARAMCD = "OS", AVAL = endpoint$stop, AVALU = "years",
  CNSR = ifelse(endpoint$terminal == 1L, 0L,
                ifelse(endpoint$censored == 1L, 2L, 1L))
)
adsl <- data.frame(USUBJID = adtte$USUBJID, assigned = endpoint$assigned)

os_history <- cs_from_adam(
  adtte = adtte, paramcd = "OS", event_codes = 0L, censor_codes = c(1L, 2L),
  time_unit = "years",
  duration_definition = "Exact elapsed years from randomization to death or observation end",
  ascertainment = "Complete synthetic death ascertainment until the recorded observation end",
  provenance = "Synthetic OS extract derived from simulate_trial(), seed 20261126",
  adsl = adsl, covariates = "assigned"
)
stopifnot(identical(os_history$terminal, as.integer(endpoint$terminal)))
table(CNSR = adtte$CNSR, terminal = os_history$terminal)
head(os_history[c("id", "start", "stop", "terminal", "assigned")])

## ----audit--------------------------------------------------------------------
report <- cs_audit_report(fit, include_session = FALSE)
stopifnot(identical(report$model$estimand_declaration, trial_estimand))
report$model$estimand_declaration
report$fit_context$data_fingerprint$algorithm
report$convergence

audit_json <- cs_audit_report(fit, format = "json", include_session = FALSE)
stopifnot(jsonlite::validate(audit_json))
attr(os_history, "cs_mapping")[c("paramcd", "event_codes", "censor_codes", "scope")]

