## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(coherentSurv)

## ----fit----------------------------------------------------------------------
d <- cs_simulate(200, horizon = 1, rates = c(.9, .5, .4),
                 dispersion = 0, censor_rate = .1, seed = 701)
d$treatment <- as.integer(d$id %% 2)
d$censored <- as.integer(d$event_type == 0 & d$terminal == 0 & d$stop < 1)
fit <- cs_causal(~x, d, treatment = "treatment", horizon = 1,
  censor = "censored", time_unit = "years", propensity = .5,
  spec = list(history_cap = 2L, working = "loglinear"))
predict(fit)

## ----diagnostics--------------------------------------------------------------
fit$diagnostics
lapply(fit$arms, function(a) a$EIF_mean)
glance(fit)
cs_causal_contrast(fit, "ratio", interval = "multiplier", draws = 1000, seed = 4)

## ----audit--------------------------------------------------------------------
report <- cs_audit_report(fit, include_session = FALSE)
report$model$targeting
report$convergence

