coherentSurv 0.11.0 computational replication

Install the source archive in software/, then run:
Rscript --vanilla code.R

The runner reaggregates saved Monte Carlo rows, reconstructs manuscript tables and figures, and reruns quickstart, sensitivity and causal examples. Use --fresh-cases to refit the five case studies. Historical experiments retain their numeric results; displayed method labels use the current package name. Earlier check transcripts are excluded. Fresh checks accompany the current release.

The package/ directory is the complete source; software/ contains the built source archive. Rtools or another C++17 toolchain is required for source installation. See package/DESCRIPTION for dependencies.
