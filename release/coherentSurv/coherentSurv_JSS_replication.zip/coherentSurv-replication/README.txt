coherentSurv 0.11.1 computational replication

Install the source archive in software/, then run:
Rscript --vanilla code.R

The runner reaggregates saved Monte Carlo rows, reconstructs manuscript tables and figures, and reruns quickstart, sensitivity and causal examples. Use --fresh-cases to refit the five case studies. Historical experiments retain their numeric results; displayed method labels use the current package name. Earlier check transcripts are excluded. Fresh checks accompany the current release.

The package/ directory is the complete source; software/ contains the built source archive. Rtools or another C++17 toolchain is required for source installation. See package/DESCRIPTION for dependencies.

The 0.11.1 revision adds guarded reporting, explicit mappings and ten executable vignettes. Original simulations are retained, not represented as rerun. The archive contains the source package, examples and current article sources.
Run Rscript --vanilla replication/check_research_metrics.R for the companion reporting formulas. The 40-item review register distinguishes implemented and future work.

Release 0.11.1 metadata reconciliation: installation instructions and citation metadata use the final coherentSurv title. The paper sources match the submitted arXiv replacement; statistical source and historical experiments are unchanged.
